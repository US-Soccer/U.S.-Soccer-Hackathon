import pandas as pd
from sklearn.preprocessing import Imputer
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn import svm
from sklearn.model_selection import KFold
from sklearn.externals import joblib

import csv

recordList= []

dictClub = {}
dictevent = {}

dataset = pd.read_csv("MLS 2018-2019.csv", low_memory=False)

dataExtract = dataset.loc[:, ['team']]
dataUniq = dataExtract["team"].unique()

dataExtract2 = dataset.loc[:, ['event_type']]
dataUniq2 = dataExtract2["event_type"].unique()

data_req = dataset.copy()

i = 0

for teamname in dataUniq:
    
    j = 0
   
    req_data1 = dataset[(dataset['team']==teamname)]
    data_1= req_data1[['team', 'x','y','outcome','event_type']].dropna()
    
    for event in dataUniq2:
        dictevent = {}    
        #Right Back
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']==event) & (data_1['x']>=0) & (data_1['x']<=35.0) & (data_1['y']>0.0) & (data_1['y']<17.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,0] = 0
        for m in x["outcome"]:
            dictevent[event,0] = m
            
        #Center Back
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>=0) & (data_1['x']<=35.0) & (data_1['y']>17.0) & (data_1['y']<78.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,1] = 0
        for m in x["outcome"]:
            dictevent[event,1] = m
            
        #Left Back
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>=0) & (data_1['x']<=35.0) & (data_1['y']>78.0) & (data_1['y']<100.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,2] = 0
        for m in x["outcome"]:
            dictevent[event,2] = m
        
         #Right DM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>35.0) & (data_1['x']<=50.0) & (data_1['y']>0.0) & (data_1['y']<17.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,3] = 0
        for m in x["outcome"]:
            dictevent[event,3] = m
            
        #Center DM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>35.0) & (data_1['x']<=50.0) & (data_1['y']>17.0) & (data_1['y']<78.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,4] = 0
        for m in x["outcome"]:
            dictevent[event,4] = m
            
        #Left DM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>35) & (data_1['x']<=50.0) & (data_1['y']>78.0) & (data_1['y']<100.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,5] = 0
        for m in x["outcome"]:
            dictevent[event,5] = m
            
         #Right AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>50.0) & (data_1['x']<=65.0) & (data_1['y']>0.0) & (data_1['y']<17.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,6] = 0
        for m in x["outcome"]:
            dictevent[event,6] = m
            
        #Center AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>50.0) & (data_1['x']<=65.0) & (data_1['y']>17.0) & (data_1['y']<78.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,7] = 0
        for m in x["outcome"]:
            dictevent[event,7] = m
            
        #Left AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>50.0) & (data_1['x']<=65.0) & (data_1['y']>78.0) & (data_1['y']<100.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,8] = 0
        for m in x["outcome"]:
            dictevent[event,8] = m
            
         #Right AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>65.0) & (data_1['x']<=100.0) & (data_1['y']>0.0) & (data_1['y']<17.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,9] = 0
        for m in x["outcome"]:
            dictevent[event,9] = m
            
        #Center AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>65.0) & (data_1['x']<=100.0) & (data_1['y']>17.0) & (data_1['y']<78.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,10] = 0
        for m in x["outcome"]:
            dictevent[event,10] = m
            
        #Left AM
        req_data = data_1[(data_1['team']==teamname)& (data_1['event_type']== event) & (data_1['x']>65.0) & (data_1['x']<=100.0) & (data_1['y']>78.0) & (data_1['y']<100.0)]
    
        x = req_data.groupby('team').mean().loc[:, ['outcome']]
        dictevent[event,11] = 0
        for m in x["outcome"]:
            dictevent[event,11] = m
            
        dictClub[teamname,event] = dictevent
        
    
    i = i + 1

joblib.dump(dictClub, 'dictClub.pkl')

        



