# -*- coding: utf-8 -*-
"""
Created on Sun Jul 15 06:16:20 2018

@author: Hp
"""

import pandas as pd
from sklearn.preprocessing import Imputer
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn import svm
from sklearn.model_selection import KFold
from sklearn.externals import joblib

import matplotlib.pyplot as plt
import numpy as np

import csv

dictNewQuad = {}
dictNewTeam = {}
arraySum=[]
for i in range(12):
    arraySum.append(0)

dataset = pd.read_csv("MLS 2018-2019.csv")

dataExtract = dataset.loc[:, ['team']]
dataUniq = dataExtract["team"].unique()

dataExtract2 = dataset.loc[:, ['event_type']]
dataUniq2 = dataExtract2["event_type"].unique()

data_req = dataset.copy()

dictClub = joblib.load('dictClub.pkl')

for teamname in dataUniq:
    arraySum = []
    for i in range(12):
        arraySum.append(0)
    for i in range(12):
        for event in dataUniq2:
            
            if(i == 0 or i == 2):
                if(event == "Pass"):
                    arraySum[i] += (1 - dictClub[teamname,event][event,i]) * 100
                if(event == "Clearance"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 90
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 120
                if(event == "Blocked pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Foul"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 90
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                
            
            if(i == 1):
                if(event == "Pass"):
                    #print(dictClub[teamname,event][event,i]))
                    arraySum[i] += ((1 - dictClub[teamname,event][event,i])) * 110
                if(event == "Clearance"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Corner awarded"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Aerial"):
                    arraySum[i] += (1-(dictClub[teamname,event][event,i])) * 20
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Blocked pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Attempt saved"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Save"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Keeper pick-up"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Foul"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) *20
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 20
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 20
                if(event == "Cross not claimed"):
                    arraySum[i] +=((dictClub[teamname,event][event,i])) * 40
                if(event == "Claim"):
                    arraySum[i] +=((dictClub[teamname,event][event,i])) * 40
                if(event == "Punch"):
                    arraySum[i] +=((dictClub[teamname,event][event,i])) * 20
                if(event == "Take on"):
                    arraySum[i] +=((dictClub[teamname,event][event,i])) * 20
                    
                    
            if(i == 3 or i ==4 or i ==5 ):
                if(event == "Pass"):
                    arraySum[i] += ((1 - dictClub[teamname,event][event,i])) * 70
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) *110
                if(event == "Clearance"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 100
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 110
                if(event == "Blocked pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Foul"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 90
                if(event == "Take on"):
                    arraySum[i] +=((dictClub[teamname,event][event,i])) * 40
            
            if(i == 6 or i ==7 or i ==8):
                if(event == "Pass"):
                    arraySum[i] += ((1 - dictClub[teamname,event][event,i])) * 50
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) *110
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 80
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 50
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 20
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 90
                if(event == "Blocked pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Foul"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 10
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 100
                if(event == "Take on"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 110
                if(event == "Offside pass"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 60
                if(event == "Goal"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 150
                if(event == "Miss"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 40
                if(event == "Chance missed"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 10
                    
                
                    
            if(i == 9  or i ==11):
                if(event == "Pass"):
                    arraySum[i] += (1 - dictClub[teamname,event][event,i]) * 130
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) *40
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 60
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 100
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 40
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 110
                if(event == "Take on"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 120
                if(event == "Offside pass"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 40
                if(event == "Goal"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 140
                if(event == "Miss"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 100
                if(event == "Chance missed"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 20
                    
            if(i ==10):
                if(event == "Pass"):
                    arraySum[i] += (1 - dictClub[teamname,event][event,i]) * 10
                if(event == "Pass"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) *120
                if(event == "Dispossesed"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 20
                if(event == "Tackle"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 70
                if(event == "Aerial"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 95
                if(event == "Interception"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 90
                if(event == "Error"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 30
                if(event == "Shield ball opp"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 10
                if(event == "Challenge"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 10
                if(event == "Good skill"):
                    arraySum[i] += (dictClub[teamname,event][event,i]) * 125
                if(event == "Take on"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 30
                if(event == "Offside pass"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 50
                if(event == "Goal"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 170
                if(event == "Miss"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 80
                if(event == "Chance missed"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 30
                if(event == "Blocked pass"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 40
                if(event == "Foul"):
                    arraySum[i] += ((dictClub[teamname,event][event,i])) * 20
                
            
    #for i in range(12):
        dictNewTeam[teamname,i] =  arraySum[i]/10
        #print()
        
#print(dictNewTeam)
joblib.dump(dictNewTeam, 'dictNewTeam.pkl')
        
        
        