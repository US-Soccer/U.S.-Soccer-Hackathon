Please follow the order of filenames below while Execution:

1) SoccerHackath0n.py

2) AlgorithmApplication.py

3) HeatmapGeneration.py

Please use MLS Season Stats from the data provided - MLS 2018-2019.csv