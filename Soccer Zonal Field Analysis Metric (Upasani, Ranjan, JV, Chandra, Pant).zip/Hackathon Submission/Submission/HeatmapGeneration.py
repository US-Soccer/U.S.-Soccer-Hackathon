# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# add alpha (transparency) to a colormap
#import matplotlib.cm from matplotlib.colors 
#import LinearSegmentedColormap 
#wd = matplotlib.cm.winter._segmentdata # only has r,g,b  
#wd['alpha'] =  ((0.0, 0.0, 0.3), 
 #              (0.3, 0.3, 1.0),
#             (1.0, 1.0, 1.0))

# modified colormap with changing alpha
#al_winter = LinearSegmentedColormap('AlphaWinter', wd) 

# get the map image as an array so we can plot it 
import matplotlib.image as mpimg
import pandas as pd
import numpy as np
from sklearn.externals import joblib

map_img = mpimg.imread('football_pitch_new.png') 

# making and plotting heatmap 
import numpy.random as random 
heatmap_data = random.rand(8,9) 

import seaborn as sns; sns.set()

dataset = pd.read_csv("MLS 2018-2019.csv")

dataExtract = dataset.loc[:, ['team']]
dataUniq = dataExtract["team"].unique()

dataExtract2 = dataset.loc[:, ['event_type']]
dataUniq2 = dataExtract2["event_type"].unique()

data_req = dataset.copy()

dictClub = joblib.load('dictClub.pkl')
dictNewTeam = joblib.load('dictNewTeam.pkl')

for teamname in dataUniq:
    
    ##for event in dataUniq2:
        
        ##if event == "Pass" or event == "Aerial":
        
    print("Heat Map for "+ teamname )
            ##heatmap_data=np.array([[dictClub[teamname,event][event,2], dictClub[teamname,event][event,5], dictClub[teamname,event][event,8], dictClub[teamname,event][event,11]],[dictClub[teamname,event][event,1],dictClub[teamname,event][event,4], dictClub[teamname,event][event,7], dictClub[teamname,event][event,10]], [dictClub[teamname,event][event,0],dictClub[teamname,event][event,3], dictClub[teamname,event][event,6], dictClub[teamname,event][event,9]]])
    heatmap_data=np.array([[dictNewTeam[teamname,2], dictNewTeam[teamname,5], dictNewTeam[teamname,8], dictNewTeam[teamname,11]],[dictNewTeam[teamname,1],dictNewTeam[teamname,4], dictNewTeam[teamname,7], dictNewTeam[teamname,10]], [dictNewTeam[teamname,0],dictNewTeam[teamname,3], dictNewTeam[teamname,6], dictNewTeam[teamname,9]]])


    hmax = sns.heatmap(heatmap_data,
                #cmap = al_winter, # this worked but I didn't like it
                cmap = 'binary',
                alpha = 0.5, # whole heatmap is translucent
                annot = True,
                zorder = 2,
                )

# heatmap uses pcolormesh instead of imshow, so we can't pass through 
# extent as a kwarg, so we can't mmatch the heatmap to the map. Instead, 
# match the map to the heatmap:

    hmax.imshow(map_img,
              aspect = hmax.get_aspect(),
              extent = hmax.get_xlim() + hmax.get_ylim(),
              zorder = 1) #put the map under the heatmap
    
    #from matplotlib.pyplot import show
    import matplotlib.pyplot as plt
    plt.show()
    f = plt.figure()
    plt.savefig("plots.pdf", bbox_inches='tight')

