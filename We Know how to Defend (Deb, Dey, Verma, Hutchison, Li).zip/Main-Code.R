setwd("~/Desktop/Porashuno/OtherProjects/Sports-related/Hackathon/Codes/")

library(quadprog)
library(plyr)
library(prodlim)
library(changepoint)

source("Functions.R")

# ---- Import already prepared files ----

D1 <- read.csv("D1.csv")
dd <- read.csv("USMNT trimmed.csv")
positions = read.csv("positions.csv")
variables <- read.csv("weights.csv")

USplayers = subset(D1,team == "USA")

# ----- Find ratings for all players, across different matches and time points -----

allrates = rate_finder(data = USplayers,variables)

MD = allrates$matchlevel
gd = unique(dd[,c("game_date","game_id","fixture")])
gd$game_date = substr(gd$game_date,1,10)
MD$game_date = as.character(nrow(MD))
MD$fixture = as.character(nrow(MD))
for (i in 1:nrow(gd)){
  idx = which(MD$game_id==gd$game_id[i])
  MD$game_date[idx] = as.character(gd$game_date[i])
  MD$fixture[idx] = as.character(gd$fixture[i])
}
posdata = unique(subset(positions,team=="USA")[,c("player_id","player","position_id")])
MD$position = rep(0,nrow(MD))
for (i in 1:nrow(posdata)){
  idx = which(MD$player_id == posdata$player_id[i])
  MD$position[idx] = posdata$position_id[i]
}

#  Save the matchlevel data for ratings -----

write.csv(MD,"matchlevel.csv",row.names = F)



# Make plots of matchwise (and minute-level) ratings for different players 

playername = "Michael Bradley"
varname = "overall"
id.p = which(MD$player == playername)
Z = MD[id.p,]
Z = Z[order(as.Date(Z$game_date,format = "%Y-%m-%d")),]

col.code = as.numeric(Z$competition)
comp.name = sort(as.character(unique(Z$competition)))
year = substr(Z$game_date,1,4)
ids = as.numeric(lapply(split(seq_along(year), year),function(x) x[1]))

plot(c(0,nrow(Z)),range(Z$overall),type = "n",xlab = "Date/Year",ylab = "Overall rating",xaxt = "n")
axis(1,at = ids,labels = year[ids],tick = F)
lines(Z$overall,type = "b",lty = 2)
points(Z$overall,col = col.code,pch = 19)
legend("bottomleft",legend = comp.name,col = sort(unique(col.code)),pch = 19)

gameid = 312095
playername = "Michael Bradley"
idx = which(MD$player == playername & MD$game_id == gameid)
Z = allrates$playerlevel[[idx]]
plot.new()
plot(c(0,90),range(Z$overall),type = "n",xlab = "Minute",ylab = "Rating",
     main = "Michael Bradley vs England")
lines(Z$overall)
legend("bottomright",legend = c("Overall","Passing"),col = c(1,2),lty = 1)



# Prepare necessary data to analyze substitutions

sub.ind = which(D1$event_type=="Player off" & D1$team=="USA")
Data.sub = D1[sub.ind,]

for(i in c(1:length(sub.ind))){
  game.ind = D1[sub.ind[i],]$game_id
  goal.temp = subset(D1[D1$game_id==game.ind,],event_type=="Goal")
  Data.sub$goal.diff.prev[i] = sum(goal.temp[goal.temp$timestamp < Data.sub$timestamp[i],]$team=="USA") - 
    sum(goal.temp[goal.temp$timestamp < Data.sub$timestamp[i],]$team!="USA")
  Data.sub$goal.diff.end[i] = sum(goal.temp$team=="USA")-sum(goal.temp$team!="USA")
  Data.sub$goal.diff.change[i] = Data.sub$goal.diff.end[i]-Data.sub$goal.diff.prev[i]
  
  rating.ts <- allrates$playerlevel[[which(MD$game_id==game.ind
                                           & MD$player_id==Data.sub$player_id[i])]]
  Data.sub$final[i] = rating.ts$overall[length(rating.ts$overall)]
  Data.sub$defensive[i] = rating.ts$defending[length(rating.ts$defending)]
  Data.sub$passing[i] = rating.ts$passing[length(rating.ts$passing)]
  
  xx = rating.ts$overall
  tt = rating.ts$timestamp
  H <- numeric(90)
  for(k in 1:90){
    H[k] = xx[max(which(tt<(k*60)))]
  }
  H[is.na(H)==T] = 0
  
  cp <- cpt.mean(ts(H),method="BinSeg",penalty="Manual",pen.value="sqrt(n)",Q=10,class=F)
  cp <- cp[-length(cp)]
  cq <- which(H[cp+1] < H[cp])[1]
  if (is.na(cq)==T) {
    cq = 90
  }
  Data.sub$cp1[i] = (Data.sub$timestamp[i]/60 - ifelse(is.na(cp[cq]),90,cp[cq]))
  Data.sub$ncp[i] = length(which(H[cp][-length(cp)] > H[cp+1][-length(cp)]))
  Data.sub$red_card_prev[i] = sum(subset(D1[D1$game_id==game.ind,], timestamp <= Data.sub$timestamp[i])$red_card, na.rm=TRUE) + 
    sum(subset(D1[D1$game_id==game.ind,], timestamp <= Data.sub$timestamp[i])$second_yellow, na.rm=TRUE)
  Data.sub$yellow_card_prev[i] = sum(subset(D1[D1$game_id==game.ind & D1$player == as.character(Data.sub$player[i]),], timestamp <= Data.sub$timestamp[i])$yellow_card, na.rm=TRUE)
}
Data.sub$goal.diff.change = 0*(Data.sub$goal.diff.change <= 0) + 1*(Data.sub$goal.diff.change > 0) 

# Fit an appropriate GLM to analyze the effects

fit <- glm(goal.diff.change ~ cp1 + ncp + final + defensive + passing, data = Data.sub, family = binomial)
summary(fit)

gameid = sample(unique(MD$game_id),1)
defid = c(2,3,4,5)
defenders = which(MD$game_id == gameid & MD$position %in% defid)
probs <- matrix(0,nrow = 90,ncol = length(defenders))
for (i in 1:length(defenders)){
  xx = allrates$playerlevel[[defenders[i]]]$overall
  tt = allrates$playerlevel[[defenders[i]]]$timestamp
  H <- numeric(90)
  for(k in 1:90){
    H[k] = xx[max(which(tt<(k*60)))]
  }
  H[is.na(H)==T] = 0
  final = H
  
  cp <- cpt.mean(ts(H),method="BinSeg",penalty="Manual",pen.value="sqrt(n)",Q=10,class=F)
  cp <- cp[-length(cp)]
  cq <- which(H[cp+1] < H[cp])[1]
  if (is.na(cq)==T) {
    cq = 90
  }
  
  ncp = rep(length(cp),90)
  cptemp = c(1,cp)
  for (k in 2:length(cptemp)){
    ncp[(cptemp[k-1]):(cptemp[k]-1)] = k - 2
  }
  
  xx = allrates$playerlevel[[defenders[i]]]$defending
  H <- numeric(90)
  for(k in 1:90){
    H[k] = xx[max(which(tt<(k*60)))]
  }
  H[is.na(H)==T] = 0
  defensive = H
  
  xx = allrates$playerlevel[[defenders[i]]]$passing
  H <- numeric(90)
  for(k in 1:90){
    H[k] = xx[max(which(tt<(k*60)))]
  }
  H[is.na(H)==T] = 0
  passing = H
  
  test = data.frame(ncp,final,defensive,passing,cp1 = (c(1:90) - ifelse(is.na(cp[cq]),90,cp[cq])))
  probs[,i] = predict(fit,type = "response",newdata = test)
}

# Produce plot of probabilities of game improvement chance if 
# a defender is substituted at time t

plot.new()
plot(c(0,90),c(0,1),type = "n",xlab = "Minute",ylab = "Improvement probability")
for (i in 1:ncol(probs)) {
  lines(probs[,i],col = i)
}
legend("bottomright",as.character(MD$player[defenders]),col = 1:ncol(probs),lty = 1)


