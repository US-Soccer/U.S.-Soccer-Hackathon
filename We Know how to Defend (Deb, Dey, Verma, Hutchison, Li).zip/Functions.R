rate_finder <- function(data = USplayers,variables,playername = "all"){
  
  vv = variables[,c(1,4,5)]
  vnames = variables$attribute
  
  if (playername != "all"){
    d = subset(data,player == playername)
    matches = split(d,f = d$game_id)
    md1 = data.frame(matches[[1]][1,1:4],stringsAsFactors = FALSE)
    md2 = c()
    out = list()
    for (j in 1:length(matches)){
      md1[j,] = matches[[j]][1,1:4]
      out[[j]] = matrix(0,nrow = nrow(matches[[j]]),ncol = (3+length(vnames)))
      for (k in 1:nrow(out[[j]])){
        xx = as.numeric(matches[[j]][k,c(6,11,23)])
        out[[j]][k,1:3] = as.numeric(matches[[j]][k,c("x","y","timestamp")])
        vid = 3 + which(rowSums(t(t(variables[,c(1,4,5)]) - xx)^2) == 0)
        out[[j]][k,vid] = out[[j]][k,vid] + matches[[j]]$event_rating[k]
      }
      out[[j]][,4:24] = apply(out[[j]][,4:24],2,cumsum)
      out[[j]] = data.frame(out[[j]])
      colnames(out[[j]]) = c("x","y","timestamp",vnames)
      out[[j]]$defending = rowSums(out[[j]][,4:8])
      out[[j]]$duel = rowSums(out[[j]][,9:11])
      out[[j]]$other = rowSums(out[[j]][,12:17])
      out[[j]]$passing = rowSums(out[[j]][,18:21])
      out[[j]]$possession = rowSums(out[[j]][,22:24])
      out[[j]]$overall = rowSums(out[[j]][,4:24])
      md2 = rbind(md2,out[[j]][nrow(out[[j]]),25:30])
    }
    md = data.frame(md1,md2)
  }
  else{
    allp = split(data,f = data$player_id,drop = T)
    count = 0
    out = list()
    md1 = data.frame(allp[[1]][1,c(1:4,14,15)],stringsAsFactors = F)
    md2 = c()
    for (i in 1:length(allp)){
      matches = split(allp[[i]],f = allp[[i]]$game_id)
      for (j in 1:length(matches)){
        count = count + 1
        md1[count,] = matches[[j]][1,c(1:4,14,15)]
        out[[count]] = matrix(0,nrow = nrow(matches[[j]]),ncol = (3+length(vnames)))
        for (k in 1:nrow(out[[count]])){
          xx = as.numeric(matches[[j]][k,c(6,11,23)])
          out[[count]][k,1:3] = as.numeric(matches[[j]][k,c("x","y","timestamp")])
          vid = 3 + which(rowSums(t(t(variables[,c(1,4,5)]) - xx)^2) == 0)
          out[[count]][k,vid] = out[[count]][k,vid] + matches[[j]]$event_rating[k]
        }
        if (nrow(out[[count]])>1){
          out[[count]][,4:24] = apply(out[[count]][,4:24],2,cumsum)
        }
        out[[count]] = data.frame(out[[count]])
        colnames(out[[count]]) = c("x","y","timestamp",vnames)
        out[[count]]$defending = rowSums(out[[count]][,4:8])
        out[[count]]$duel = rowSums(out[[count]][,9:11])
        out[[count]]$other = rowSums(out[[count]][,12:17])
        out[[count]]$passing = rowSums(out[[count]][,18:21])
        out[[count]]$possession = rowSums(out[[count]][,22:24])
        out[[count]]$overall = rowSums(out[[count]][,4:24])
        md2 = rbind(md2,out[[count]][nrow(out[[count]]),25:30])
      }
    }
    md = data.frame(md1,md2)
  }
  return(list(matchlevel = md,playerlevel = out))
}


player.data <- function(data=D1,p=5075){
  
  P <- list()
  data <- data.frame(data)
  
  for(k in eventids){
    
    D2=data[data$event_type_id==k,]
    T = table(D2$outcome)
    
    if(k==1){
      D2$Forward_pass=as.factor(D2$pass_end_x > D2$x)
      D2$Length=sqrt((D2$pass_end_x-D2$x)^2+(D2$pass_end_y-D2$y)^2)
      
      D4=D2[D2$player_id==p,]
      D5=ddply(D4,.(game_id,outcome,Forward_pass),summarise,Avg.Length=mean(Length),.drop=FALSE)
      #aggregate(length ~ outcome + Forward_pass+player_id,data=D2,mean)
      g=length(unique(D5$game_id))
      D6=matrix(ncol=4,nrow=g)
      
      for(i in 1:g){
        D6[i,]=D5$Avg.Length[(4*i-3):(4*i)]
        
      }
      A1 <- aggregate((outcome==1)~game_id, data=D4, mean)
      
      
      P[[k]]=cbind(U_Back=D6[,1],U_for=D6[,2],S_Back=D6[,3],S_For=D6[,4],Prop_pass=A1[,2])
      rownames(P[[k]])=unique(D5$game_id)
    }
    
    if(k!=1 & length(T)==2){
      
      A1 <- aggregate((outcome==1)~game_id+player_id, data=D2, sum)
      A2 <- aggregate((outcome==0)~game_id+player_id, data=D2, sum)
      var1 <- paste0(k,"_1")
      var2 <- paste0(k,"_0")
      P[[k]] <- data.frame(var1=subset(A1, player_id == p)[,3],var2=subset(A2, player_id == p)[,3])
      
      colnames(P[[k]]) <- c(var1, var2)
      rownames(P[[k]]) <- subset(A1, player_id == p)[,1]
    }
    
    if(length(T)==1){
      A1 <- aggregate((outcome==1)~game_id+player_id, data=D2, sum)
      var1 <- paste0(k,"_1")
      P[[k]] <- data.frame(var1=subset(A1, player_id == p)[,3])
      
      colnames(P[[k]]) <- var1
      rownames(P[[k]]) <- subset(A1, player_id == p)[,1]
    }
    
  }
  
  X <- merge(P[[1]], P[[3]], by="row.names",all.x=TRUE)[,-1]
  rownames(X) <- rownames(P[[1]])
  
  for(i in 3:(length(eventids)-1)){
    
    X <- merge(X,P[[eventids[i]]], by="row.names",all.x=TRUE)[,-1]
    rownames(X) <- rownames(P[[1]])
    
  }
  
  return(X)
  
}
