setwd("~/Desktop/Porashuno/OtherProjects/Sports-related/Hackathon/Codes/")

library(quadprog)
library(plyr)
library(prodlim)
library(changepoint)

source("Functions.R")

dd <- read.csv("~/Desktop/Porashuno/OtherProjects/Sports-related/Hackathon/Hackathon Raw Files/Trimmed Columns - Opta/USMNT/USMNT trimmed.csv")
dim(dd)
names(dd)

eventids = c(1,3:8,12:18,44,45,49,50,55,51,61,67)
colids = c(2,6,9,11,13:25,36,37,44,45)
D1 = subset(dd,event_type_id  %in% eventids & is.na(player_id)==F)[,colids]

D1$timestamp = numeric(nrow(D1))
for (i in 1:length(unique(D1$game_id))){
  k=unique(D1$game_id)[i]
  D3=D1[D1$game_id==k,]
  pid1 = which(D1$game_id==k & D1$period_id==1)
  D1$timestamp[pid1] = D1$period_min[pid1]*60 + D1$period_second[pid1]
  pid2 = which(D1$game_id==k & D1$period_id==2)
  D1$timestamp[pid2] = max(D1$timestamp[pid1]) - 2700 + (D1$period_min[pid2])*60 + D1$period_second[pid2]
  pid3 = which(D1$game_id==k & D1$period_id==3)
  D1$timestamp[pid3] = max(D1$timestamp[pid2]) - 5400 + (D1$period_min[pid3])*60 + D1$period_second[pid3]
  pid4 = which(D1$game_id==k & D1$period_id==4)
  D1$timestamp[pid4] =  max(D1$timestamp[pid3]) - 6300 + (D1$period_min[pid4])*60 + D1$period_second[pid4]
}
D1$forward = (-1)^(D1$x > D1$pass_end_x)

dim(D1)
head(D1)


# RATE SKILL: For tackles, passing, other, duel, possession

uspl = split(D1,f = D1$player_id)
idx = which(as.numeric(lapply(uspl,FUN = function(x) length(unique(x$game_id))))>5)

tid = c(8,14:17)
tname = c("foul","s_tackle","u_tackle","interception","clearance")
tam = diag(c(-1,1,-1,1,1))
tdm = matrix(0,length(tid),length(tid))

pid = 1:4
pname = c("u_back_pass","u_for_pass","s_back_pass","s_for_pass")
pam = diag(c(-1,-1,1,1))
pdm = matrix(0,4,4)

did = c(24,25,28)
dname = c("s_aerial","u_aerial","dispossess")
dam = diag(c(1,-1,1))
ddm = matrix(0,3,3)

oid = c(6,7,9,29,30,32)
oname = c("s_takeon","u_takeon","fouled","offside_provoked","error","ball_touch")
oam = diag(c(1,-1,1,1,-1,-1))
odm = matrix(0,6,6)

posid = c(10,11,27)
posname = c("out_gain","out_lose","ball_recovery")
posam = diag(c(1,-1,1))
posdm = matrix(0,3,3)

for (i in 1:length(idx)){
  
  pl1 = player.data(D1,p = uspl[[idx[i]]]$player_id[1])
  pl1[is.na(pl1)==T] = 0
  
  temp = pl1[,tid]
  temp = t(t(temp)*diag(tam))
  tdm = tdm + cov(temp)
  
  temp = pl1[,pid]
  temp = t(t(temp)*diag(pam))
  pdm = pdm + cov(temp)
  
  temp = pl1[,did]
  temp = t(t(temp)*diag(dam))
  ddm = ddm + cov(temp)
  
  temp = pl1[,oid]
  temp = t(t(temp)*diag(oam))
  odm = odm + cov(temp)
  
  temp = pl1[,posid]
  temp = t(t(temp)*diag(posam))
  posdm = posdm + cov(temp)
}
tdm = tdm/length(idx)
pdm = pdm/length(idx)
ddm = ddm/length(idx)
odm = odm/length(idx)
posdm = posdm/length(idx)

tsoln = solve.QP(Dmat = tdm,dvec = rep(1,length(tid)),Amat = diag(length(tid)))
tw = round(tsoln$solution,3)*diag(tam)

psoln = solve.QP(Dmat = pdm,dvec = rep(1,length(pid)),Amat = diag(length(pid)))
pw = round(psoln$solution,3)*diag(pam)

dsoln = solve.QP(Dmat = ddm,dvec = rep(1,length(did)),Amat = diag(length(did)))
dw = round(dsoln$solution,3)*diag(dam)

osoln = solve.QP(Dmat = odm,dvec = rep(1,length(oid)),Amat = diag(length(oid)))
ow = round(osoln$solution,3)*diag(oam)

possoln = solve.QP(Dmat = posdm,dvec = rep(1,length(posid)),Amat = diag(length(posid)))
posw = round(possoln$solution,3)*diag(posam)


variables = read.csv("~/Desktop/Porashuno/OtherProjects/Sports-related/Hackathon/variables.csv")
variables$attribute = c(tname,dname,oname,pname,posname)
variables$weight = c(tw,dw,ow,pw,posw)
variables
write.csv(variables,"weights.csv",row.names = F)


D1$event_rating = numeric(nrow(D1))
D1[is.na(D1)==T] = 0
variables[is.na(variables)==T] = 0
for (i in 1:nrow(variables)){
  if (i %in% c(15:18)){
    xx = as.numeric(variables[i,c(1,4,5)])
    event.id = which(rowSums(t(t(D1[,c(6,11,23)]) - xx)^2) == 0)
    ll = sqrt(((D1$x-D1$pass_end_x)^2+(D1$pass_end_y-D1$y)^2))[event.id]
    D1$event_rating[event.id] = ll*variables$weight[i]
  }else{
    xx = as.numeric(variables[i,c(1,4)])
    event.id = which(rowSums(t(t(D1[,c(6,11)]) - xx)^2) == 0)
    D1$event_rating[event.id] = variables$weight[i]
  } 
}
head(D1,10)
write.csv(D1,"D1.csv",row.names = F)
