class TwitterController < ApplicationController
  def index
  end 
end
