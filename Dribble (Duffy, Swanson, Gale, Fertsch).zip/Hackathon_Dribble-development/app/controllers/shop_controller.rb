class ShopController < ApplicationController
  def index
  end
end
