$(document).ready(function() {
	$('#fullpage').fullpage({
		licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
		slideSelector: '.slide',
		scrollOverflow: true
		// scrollOverflow: true
			// parallaxKey: ‘YmFja2NvdXJ0ZHJpYmJsZS5jb21fanh6Y0dGeVlXeHNZWGc9ZDYx’,
    	// parallax: true,
      // parallaxOptions: {type: ‘reveal’, percentage: 62, property: ‘translate’},
      // sectionsColor: [‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’,‘black’, ‘#707070’,‘black’, ‘#707070’, ‘black’, ‘#707070’]
	});
});
