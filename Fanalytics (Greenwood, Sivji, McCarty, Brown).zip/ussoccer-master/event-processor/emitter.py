import csv
import time

import sqlalchemy as sa
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

engine = sa.create_engine("sqlite:///../game.db", echo=True)
Base = declarative_base()


# Model
class ShotEvent(Base):
    __tablename__ = 'shot_event'

    id = sa.Column(sa.Integer, primary_key=True)
    shot_type = sa.Column(sa.String)
    team = sa.Column(sa.String)
    event_time = sa.Column(sa.Integer)
    x = sa.Column(sa.Float)
    y = sa.Column(sa.Float)


Session = sessionmaker(bind=engine)
session = Session()


# Functions
def event_stream(game, speed=100):
    with open(game) as csvfile:
        reader = csv.DictReader(csvfile)

        current_game_time_seconds = 0
        for row in reader:
            event_time_seconds = (
                int(row["period_min"]) * 60 +
                int(row["period_second"])
            )
            row["event_time_seconds"] = event_time_seconds

            emit_event = False
            while not emit_event:
                if event_time_seconds == current_game_time_seconds:
                    emit_event = True
                    yield row
                else:
                    current_game_time_seconds += 1
                    time.sleep(1/speed)


def process_shot_details(record):
    """
    Based on what the event is, figure out how to process to send event
    to send to front-end.

    IF event_type_id = 16
    THEN
        Green
    If event_type = 14
    THEN
        Yellow
    If event_type = 15 or 13
    THEN
        IF 1 in left, high, right THEN Red Else Yellow
    """
    if record["event_type_id"] == "16":
        return "green"
    elif record["event_type_id"] == "14":
        return "yellow"
    elif record["event_type_id"] == "15" or record["event_type_id"] == "13":
        if record["left"] == "1" or record["right"] == "1" or record["right"] == "1":
            return "red"
        else:
            return "yellow"

    return None


def is_shot_event(event):
    return event["event_type_id"] in ["13", "14", "15", "16"]


def process_event(record):
    """
    This is where we will process all of our event types
    """
    # parse shot information
    if is_shot_event(record):
        x = float(record["x"])
        y = float(record["y"])
        transformed_x = (100 - y)
        transformed_y = (100 - x) * 2

        shot_details = {
            "shot_type": process_shot_details(record),
            "event_time": record["event_time_seconds"],
            "team": record["team"],
            "x": transformed_x,
            "y": transformed_y
        }

        item = ShotEvent(
            shot_type=shot_details["shot_type"],
            team=shot_details["team"],
            event_time=shot_details["event_time"],
            x=shot_details["x"],
            y=shot_details["y"],
        )

        session.add(item)
        session.commit()


if __name__ == "__main__":
    game_file = 'usa-japan.csv'

    for event in event_stream(game_file, speed=50):
        process_event(event)
