import os

from flask import Flask, jsonify
from flask_marshmallow import Marshmallow
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

# Flask Configuration
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URI", "sqlite:///../game.db"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
ma = Marshmallow(app)
CORS(app)


# Database Models
class ShotEvent(db.Model):
    __tablename__ = 'shot_event'

    id = db.Column(db.Integer, primary_key=True)
    shot_type = db.Column(db.String(20))
    team = db.Column(db.String(255))
    event_time = db.Column(db.Integer())
    x = db.Column(db.Float())  # TODO neeed to convert
    y = db.Column(db.Float())  # TODO neeed to convert

    def __repr__(self):
        return f"<ShotEvent ({self.team}, {self.x}, {self.y}, {self.shot_type} @ {self.event_time})>"


# Schema
class ShotEventSchema(ma.Schema):
    class Meta:
        # Fields to expose
        fields = ('shot_type', 'team', 'event_time', 'x', 'y')


shot_events_schema = ShotEventSchema(many=True)


@app.shell_context_processor
def make_shell_context():
    return {"app": app, "db": db, "ShotEvent": ShotEvent}


# Routes
@app.route("/health-check")
def health_check():
    return jsonify({"health": "check"})


@app.route("/shot/<team_id>")
def webpage_top_word(team_id):
    team_to_search = "USA Women" if int(team_id) == 1 else "Japan Women"
    team_shots = ShotEvent.query.filter(ShotEvent.team == team_to_search).all()

    result = shot_events_schema.dump(team_shots)

    return jsonify(result[0])


if __name__ == "__main__":
    app.run(
        port=5000,
        debug=True,
    )
