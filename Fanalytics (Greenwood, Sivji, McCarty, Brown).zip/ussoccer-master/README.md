# [Fanalytics]

## Installation Instructions

1. Create `python` virtual environment
2. `pip install -r requirements.txt`

## Setting up Streaming Database

1. Delete `game.db`
1. `flask shell`
1. `db.create_all()`
1. `cd` into `event-processor`
1. `python emitter.py`
1. Change `speed` parameter in `event_stream(game_file, speed=50)`

## Start Flask App

`python backend/app.py`

## Start Front

1. `cd` into `ussoccer`
1. `ng serve --open`
