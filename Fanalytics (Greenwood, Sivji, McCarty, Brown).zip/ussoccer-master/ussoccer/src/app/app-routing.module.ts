import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlayerComponent } from './player/player.component';
import { ShotChartComponent } from './shot-chart/shot-chart.component';
import { TeamListComponent } from './team-list/team-list.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { TeamComponent } from './team/team.component';

const routes: Routes = [
  { path: '', redirectTo: '/teams', pathMatch: 'full' },
  { path: 'teams', component: TeamListComponent} ,
  {path: 'teams/:id', component: TeamComponent},
  { path: 'shotChart', component: ShotChartComponent },
  { path: 'players', component: PlayerListComponent, children: [
    {
      path: ':id',
      component: PlayerComponent
    },
  ]}
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes,
     // { enableTracing: true } // <-- debugging purposes only
    )
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
