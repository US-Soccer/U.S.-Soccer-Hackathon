import { Team } from './team';

export const TEAMS: Team[] = [
  { id: 1, name: 'USA' },
  { id: 2, name: 'Japan' },
];
