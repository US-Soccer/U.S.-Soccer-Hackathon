import { Component, OnInit, ViewChild, ElementRef, Input, Directive, AfterContentInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-shot-chart',
  templateUrl: './shot-chart.component.html',
  styleUrls: ['./shot-chart.component.css']
})
export class ShotChartComponent implements OnInit {
  @ViewChild('canvasRef') canvasRef: ElementRef;
  cw = 265;
  ch = 200;

  public shotStats = [];

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.getStats('home');
  }

  addShot(element): void {
    const ctx: CanvasRenderingContext2D = this.canvasRef.nativeElement.getContext('2d');
    ctx.moveTo(0, 10);
    ctx.beginPath();
    ctx.arc((element.x / 100) * this.cw, (element.y / 100) * this.ch, 5, 0, 2 * Math.PI, false);
    ctx.stroke();
    if (element.shot_type === 'green') {
      ctx.fillStyle = 'green';
    } else if (element.shot_type === 'yellow') {
      ctx.fillStyle = 'yellow';
    } else {
      ctx.fillStyle = 'red';
    }
    ctx.fill();
  }

  getStats(team) {
    if (team === 'home') {
      this.dataService.getHomeShots()
        .subscribe(data => this.shotStats = data);
    } else {
      this.dataService.getAwayShots()
        .subscribe(data => this.shotStats = data);
    }
    this.shotStats.forEach(element => {
      this.addShot(element);
    });
  }

}
