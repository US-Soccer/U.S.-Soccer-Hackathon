import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HttpClientModule } from '@angular/common/http';
import { VideoComponent } from './video/video.component';
import { DataService } from './data.service';
import { PlayerComponent } from './player/player.component';
import { ShotChartComponent } from './shot-chart/shot-chart.component';
import { AppRoutingModule } from './app-routing.module';
import { TeamListComponent } from './team-list/team-list.component';
import { TeamComponent } from './team/team.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { MatCardModule, MatButtonModule, MatListModule } from '@angular/material';
import { TwitterComponent } from './twitter/twitter.component';

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    VideoComponent,
    PlayerComponent,
    ShotChartComponent,
    TeamListComponent,
    TeamComponent,
    PlayerListComponent,
    TwitterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatListModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
