import { Player } from './player';

export const JAPANPLAYERS: Player[] = [
    {id: 18, name: 'Ayumi Kaihori'},
    {id: 19, name: 'Saori Ariyoshi'},
    {id: 3, name: 'Azusa Iwashimizu'},
    {id: 4, name: 'Saki Kumagai'},
    {id: 5, name: 'Aya Sameshima'},
    {id: 9, name: 'Nahomi Kawasumi'},
    {id: 6, name: 'Mizuho Sakaguchi'},
    {id: 13, name: 'Rumi Utsugi'},
    {id: 8, name: 'Aya Miyama'},
    {id: 11, name: 'Shinobu Ohno'},
    {id: 17, name: 'Yūki Ōgimi'}
];
