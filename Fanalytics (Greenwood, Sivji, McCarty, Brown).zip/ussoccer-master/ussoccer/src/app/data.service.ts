import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { IShotStats } from './shotStats';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  protected usaURL = 'http://localhost:5000/shot/1';  // URL to web api
  protected japanURL = 'http://localhost:5000/shot/2';  // URL to web api

  constructor(private http: HttpClient) {}

  // Rest Items Service: Read all REST Items
  getHomeShots(): Observable<IShotStats[]> {
    return this.http.get<IShotStats[]>(this.usaURL);
  }

  getAwayShots(): Observable<IShotStats[]> {
    return this.http.get<IShotStats[]>(this.japanURL);
  }
}
