import { Component, OnInit } from '@angular/core';
import { USAPLAYERS } from '../mock-usa-players';
import { JAPANPLAYERS } from '../mock-japan-players';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.css']
})
export class PlayerListComponent implements OnInit {
  homePlayers = USAPLAYERS;
  awayPlayers = JAPANPLAYERS;

  constructor() { }

  ngOnInit() {
  }

}
