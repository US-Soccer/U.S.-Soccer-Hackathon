export interface IShotStats {
    event_time: number;
    shot_type: string;
    team: string;
    x: number;
    y: number;
}
