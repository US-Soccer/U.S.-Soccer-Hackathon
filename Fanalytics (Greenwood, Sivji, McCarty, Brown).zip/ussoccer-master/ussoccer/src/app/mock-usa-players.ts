import { Player } from './player';

export const USAPLAYERS: Player[] = [
    {id: 1, name: 'Hope Solo'},
    {id: 11, name: 'Ali Krieger'},
    {id: 19, name: 'Julie Johnston'},
    {id: 4, name: 'Becky Sauerbrunn'},
    {id: 22, name: 'Meghan Klingenberg'},
    {id: 17, name: 'Tobin Heath'},
    {id: 12, name: 'Lauren Holiday'},
    {id: 14, name: 'Morgan Brian'},
    {id: 15, name: 'Megan Rapinoe'},
    {id: 13, name: 'Alex Morgan'},
    {id: 10, name: 'Carli Lloyd'}
];
