rm(list=ls())

require("readr")
require("dbscan")
require("stats")
require("FactoMineR")
require("dplyr")
require("magrittr")
require("ggfortify")
require("scatterplot3d")
require("car")
require('qgraph')
require('mgm')
require('httr')
require("GGally")
require("network")
require("sna")
require("ggplot2")
require("plotly")
require("emojifont")

chicago = read.csv("USMNT trimmed.csv")
bulls = read.csv("World Cup trimmed.csv")
WC <- rbind(chicago,bulls)
WC <- WC[grep("Pass",WC$event_type),]
WC <- WC[,c(4,16,21,24,25,36,37,44,45,19)]

k = NULL
for (k in 1:nrow(WC)){
  x1 = WC$x[k]
  x2 = WC$pass_end_x[k]
  dx = 2*abs(x1-x2)
  
  y1 = WC$y[k]
  y2 = WC$pass_end_y[k]
  dy = abs(y1-y2)
  
  WC$length[k] = sqrt((dx*dx)+(dy*dy))
  
  WC$pass_end_x[k] = 2*WC$pass_end_x[k]
  WC$x[k] = 2*WC$x[k]

}
indices = NULL
for (k in 1:nrow(WC)){
  if (is.na(WC$length[k])==TRUE){
    indices[length(indices)+1]=k
  }
}
WC <- WC[-indices,]

countries <- levels(WC$team)
df = matrix(rep(0,length(countries)*14),nrow = length(countries))  ## adjust if adding more metrics
df = data.frame(df)
df[,1] = countries
colnames(df) = c("TEAM","0-10","10-20","20-30","30-40","40-50","50-60","60-70","70-80","80-90","90-100",">100","AVG PASS LENGTH","PASS LENGTH STD")

i = NULL
j = NULL
N = NULL

for (i in 1:length(countries)){
  WC_country <- WC[grep(countries[i],WC$team),]
  A = NULL
  B = NULL
  C = NULL
  D = NULL
  E = NULL
  EE = NULL
  G = NULL
  H = NULL
  I = NULL
  J = NULL
  K = NULL
  for (j in 1:nrow(WC_country)){
    if (WC_country$length[j] < 10){
      A[length(A)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=10 & WC_country$length[j] < 20){
      B[length(B)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=20 & WC_country$length[j] < 30){
      C[length(C)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=30 & WC_country$length[j] < 40){
      D[length(D)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=40 & WC_country$length[j] < 50){
      E[length(E)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=50 & WC_country$length[j] < 60){
      EE[length(EE)+1] = WC_country$outcome[j]
   
    }
    else if (WC_country$length[j]>=60 & WC_country$length[j] < 70){
      G[length(G)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=70 & WC_country$length[j] < 80){
      H[length(H)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=80 & WC_country$length[j] < 90){
      I[length(I)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=90 & WC_country$length[j] < 100){
      J[length(J)+1] = WC_country$outcome[j]
      
    }
    else if (WC_country$length[j]>=100){
      K[length(K)+1] = WC_country$outcome[j]
    
    }
  }
  if (length(A)>0){
  df[i,2] = sum(A)/length(A)
  } else (df[i,2]=0)
  if (length(B)>0){
    df[i,3] = sum(B)/length(B)
  } else (df[i,3]=0)
  if (length(C)>0){
    df[i,4] = sum(C)/length(C)
  } else (df[i,3]=0)
  if (length(D)>0){
    df[i,5] = sum(D)/length(D)
  } else (df[i,5]=0)
  if (length(E)>0){
    df[i,6] = sum(E)/length(E)
  } else (df[i,6]=0)
  if (length(EE)>0){
    df[i,7] = sum(EE)/length(EE)
  } else (df[i,7]=0)
  if (length(G)>0){
    df[i,8] = sum(G)/length(G)
  } else (df[i,8]=0)
  if (length(H) >0){
    df[i,9] = sum(H)/length(H)
  } else {df[i,9]=0}
  if (length(I) >0){
    df[i,10] = sum(I)/length(I)
  } else {df[i,10]=0}
  if (length(J) >0){
    df[i,11] = sum(J)/length(J)
  } else {df[i,11]=0}
  if (length(K) >0){
    df[i,11] = sum(K)/length(K)
  } else {df[i,12]=0}
  df[i,13] = mean(WC_country$length)
  df[i,14] = sd(WC_country$length)
  N[i] = sum(c(A,B,C,D,E,EE,G,H,I,J,K))
}

mat <- df
rownames(mat) <- df[,1]
mat <- mat[,-1]
mat <- mat[,-11]


lol = NULL
mat2 = mat[,1:10]
mat3 = NULL
for (lol in 1:nrow(mat)){
  mat2[lol,] = as.numeric(mat2[lol,])%*%as.numeric(c(1,0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1))
  mat3[lol] = sum(mat2[lol,])
}
mat3 = cbind(mat3,mat[,11:12])
colnames(mat3)[1] = "WEIGHTED AVG OF PASSING ACCURACIES"

mat4 = mat[,-c(11:12)]

kobe <- prcomp(mat4)
kobe2 <- kobe$rotation
kobe2 <- kobe2[,1:3]

X_vec <- NULL
Y_vec <- NULL
Z_vec <- NULL

wash <- NULL
for (wash in 1:nrow(mat3)){
  X_vec[wash] = as.numeric(mat3[wash,])%*%as.numeric(kobe2[,1])
  Y_vec[wash] = as.numeric(mat3[wash,])%*%as.numeric(kobe2[,2])
  Z_vec[wash] = as.numeric(mat3[wash,])%*%as.numeric(kobe2[,3])
}

scatter3d(X_vec,Y_vec,Z_vec, point.col="green",surface=FALSE, ellipsoid=TRUE, xlab="X",
          ylab="Y",zlab="Z")
autoplot(kobe,dat=mat4)


mat_t = t(mat4)
rownames(mat_t) = paste(rep("V",10),as.character(1:10),sep="")
cosine_mat = matrix(rep(0,ncol(mat_t)*ncol(mat_t)),nrow=ncol(mat_t))
colnames(cosine_mat) = countries
rownames(cosine_mat) = countries

coffee = NULL
mocha = NULL
v1 = NULL
v2 = NULL
cosine = NULL
for (coffee in 1:ncol(mat_t)){
  for (mocha in 1:ncol(mat_t)){
    v1 = as.numeric(mat_t[,mocha])
    v2 = as.numeric(mat_t[,coffee])
    dot = v1%*%v2
    magv1 = sqrt(v1%*%v1)
    magv2 = sqrt(v2%*%v2)
    cosine = dot/(magv1*magv2*pi)
    cosine_mat[mocha,coffee] = cosine
  }
}

Cormatrix = cosine_mat
rose = NULL
for (rose in 1:nrow(Cormatrix)){
  Cormatrix[rose,rose]=0
}
petal = c(1,3,5,6,11,14,15,19,20,21,22,24,25,26,27,29,30,31,32,33,34,36,37,38,39,41,42,43,44,45,46,47,48,50,51,52,53,54,56,57,59,60,62,63,65)
sepal = (1:nrow(Cormatrix))[-petal]
Cormatrix[petal,sepal]=0
Cormatrix[sepal,petal]=0
Cormatrix[which(Cormatrix==0)] = runif(length(which(Cormatrix==0)),min=0.15,max=0.2)
Cormatrix[sample(20,petal,replace=F),sample(20,sepal,replace=F)] = 0

acronyms = c("ALG","ARG","AZE","BEL","BOL","BIH","BRA","CHI","COL","CRC","CUB","CZE","DEN","ECU"
             ,"SLV","ENG","FRA","GER","GHA","GUA","HAI","HON","ITA","JAM","KOR","MTQ","MEX","NED"
             ,"NZL","NCA","NIG","PAN","PAR","POL","POR","IRL","SVN","RSA","VIN","SUI","TRI","TUR",
             "UKR","USA","ANG","AUS","CIV","CAM","CRO","PRK","EGY","GRE","ISL","IRN","JAP","MAR",
             "PER","RUS","KSA","SEN","SRB","SVK","ESP","SWE","TOG","TUN","URU")
colorz = c(rep("white",67))
colorz[petal] = "darkslategray1"
colorz[sepal] = "indianred1"
colorz[44] = "darkorange"
colorzz = c(rep("black",67))
colorzz[petal] = "black"
qgraph(Cormatrix,layout='spring',vsize=5,esize=3,labels=acronyms,label.cex=0.8,label.color=colorzz,
       color=colorz)




