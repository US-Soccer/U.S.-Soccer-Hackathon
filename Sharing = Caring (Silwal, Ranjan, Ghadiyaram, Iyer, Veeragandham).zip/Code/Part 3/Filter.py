import pandas as pd
import csv
import pdb

DATA_DIR = "/Users/Vinit/Documents/USSoccerHackathon/Data/Hackathon Raw Files"
goalies = { "USA": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
                "USMNTFilter": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
                "USMNTFilter2": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
                "USMNTFilterNG": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
                "France": ["Hugo Lloris", "Steve Mandanda", "Florian Thauvin"],
                "Croatia": ["Lovre Kalinic", "Danijel Subasic"]
    }

def write_to_csv(data, target_file):
    with open(target_file, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(["Player", "Score"])
        writer.writerows(data)
    print("Written to "+target_file)


# To filter USMNT
df = pd.read_csv(DATA_DIR + "/Full Datasets - Opta/USMNT/USMNT.csv")
new_df = df[df["competition"] != "Internationals"]
new_df = new_df[new_df["competition"] != "World Cup"]
new_df = new_df[new_df["fixture"] != "Guatemala v USA"]
new_df = new_df[new_df["fixture"] != "USA v Guatemala"]
new_df = new_df[new_df["fixture"] != "St. Vincent and the Grenadines v USA"]
new_df = new_df[new_df["fixture"] != "USA v St. Vincent and the Grenadines"]
# pdb.set_trace()
new_df = new_df[new_df["event_id"] != 10]
new_df = new_df[new_df["event_id"] != 11]
new_df = new_df[new_df["event_id"] != 12]
new_df = new_df[new_df["game_id"] != 835464]
new_df = new_df[new_df["game_id"] != 835488]

stem = "USMNTFilter"
for g in goalies[stem]:
    new_df = new_df[new_df["player"] != g]

print(new_df)
new_df.to_csv(DATA_DIR + "/Full Datasets - Opta/USMNT/"+stem+".csv")

# Test group by
df = pd.read_csv("output/test.csv")
print(df.groupby("Player").mean().sort_values(by="Score", ascending=False))
