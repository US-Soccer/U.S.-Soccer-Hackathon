import pandas as pd
import numpy as np
from tqdm import tqdm, trange
import csv
import pdb

DATA_DIR = "/Users/Vinit/Documents/USSoccerHackathon/Data/Hackathon Raw Files"  # change root directory for data
goalies = { "USA": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
            "USMNTFilter": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
            "USMNTFilter2": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
            "USMNTFilterNG": ["Michael Orozco", "Tim Howard", "Brad Guzan", "Kasey Keller", "Bill Hamid"],
            "France": ["Hugo Lloris", "Steve Mandanda", "Florian Thauvin"],
            "Croatia": ["Lovre Kalinic", "Danijel Subasic"],
            "Belgium": ["Thibaut Courtois", "Simon Mignolet", "Koen Casteels"],
            "England": ["Jordan Pickford", "Jack Butland", "Nick Pope"],
            "Brazil": ["Alisson", "Cassio", "Ederson", "Philippe Coutinho Correia", "Alisson Ramses Becker"],
            "US Women": ["Ashlyn Harris", "Alyssa Naeher", "Hope Solo"]
}


def generate_averages_by_player(target_file_start, countries):
    for c in countries:
        try:
            df = pd.read_csv(target_file_start + c + ".csv")
            # counts = df.groupby(["Player"], as_index=False).count()
            # # pdb.set_trace()
            # for index, row in counts.iterrows():
            #     p = row['Player']
            #     print(p)
            new_df = df.groupby("Player", as_index=False).mean().sort_values(by="Score", ascending=False)
            # pdb.set_trace()
            for g in goalies[c]:
                new_df = new_df[new_df["Player"] != g]
            # pdb.set_trace()
            new_df.to_csv(target_file_start + c + "players.csv")
        except pd.core.base.DataError:
            print("None")


def generate_pass_metric(fname, target_file, filterc=None, wc_filter=None):
    df = pd.read_csv(fname)
    if filterc is not None:
        df = get_country(df, filterc)
    if wc_filter is not None:
        df = get_world_cup(df, wc_filter)
    data = pass_metric(df)
    write_array_to_csv(data, target_file)
    # write_many_to_csv(outs, "output/test2.csv")
    # pdb.set_trace()


def generate_pass_metric_by_country(fname, target_file_start, countries, wc_filter=None, goalie=True):
    df = pd.read_csv(fname)
    for c in countries:
        dfc = get_country(df, c)
        if wc_filter is not None:
            dfc = get_world_cup(dfc, wc_filter)
        if not goalie:
            for g in goalies[c]:
                dfc = dfc[dfc["player"] != g]
        datac = pass_metric(dfc)
        write_array_to_csv(datac, target_file_start + c + ".csv")


def avg_stv(target_file):
    df = pd.read_csv(target_file)
    print("Reading from " + target_file)
    print("Mean: " + str(df["Score"].mean()))
    print("Stdev: " + str(df["Score"].std()) + "\n")


def read_averages(target_file_start, countries):
    for c in countries:
        fname = target_file_start + c + ".csv"
        df = pd.read_csv(fname)
        # pdb.set_trace()
        print(fname)
        print(c + " Mean: " + str(df["Score"].mean()))
        print(c + " Stdev: " + str(df["Score"].std()) + "\n")


def get_country(df, country):
    return df[df['team'] == country]


def get_world_cup(df, wc):
    return df[df['season'] == wc]


def get_no_goalie(df):
    out = df[df["event_id"] != 10]
    out = out[out["event_id"] != 11]
    out = out[out["event_id"] != 12]
    return out


def write_array_to_csv(data, target_file):
    with open(target_file, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(["Player", "Score"])
        writer.writerows(data)
    print("Written to "+target_file)


def get_scale(start_zone, zoneSR):
    return 1


def get_zone(x, y):
    x_s = x / 2  # scale x back to its square
    if 0 <= x_s <= 33.3:
        return 1
    elif 33.3 < x_s <= 66.6:
        return 2
    elif not 21.1 <= y <= 78.9:
        return 3
    else:
        return 4


def pass_metric(df):
    success = len(df[df['outcome'] == 1])
    fail = len(df[df['outcome'] != 1])
    # pdb.set_trace()
    if success > 0 and fail > 0:
        success_rate = success / (success+fail)
    else:
        success_rate = 1
    # print(success, fail)
    allpasses = df.index[df['event_type'] == 'Pass']
    zoneS = [0] * 4
    zoneT = [0] * 4
    zoneSR = [0] * 4
    for i in tqdm(allpasses, total=len(allpasses), desc="Finding SR's: "):
        row = df.ix[i]
        x_start = row['x'] * 2
        y_start = row['y']
        start_zone = get_zone(x_start, y_start)
        if row['outcome']:
            zoneS[start_zone - 1] += 1
        zoneT[start_zone - 1] += 1

    passes = df.index[(df['event_type'] == 'Pass') & (df['outcome'] == 1)]

    output = []

    for i in range(len(zoneS)):
        try:
            zoneSR[i] = zoneS[i]/zoneT[i]
        except ZeroDivisionError:
            zoneSR[i] = 1
    # pdb.set_trace()

    for i in tqdm(passes, total=len(passes), desc="Calculating Metric"):
        row = df.ix[i]
        player = row['player']
        x_start = row['x'] * 2
        y_start = row['y']
        x_end = row['pass_end_x'] * 2
        y_end = row['pass_end_y']
        dx = x_end - x_start
        dy = y_end - y_start
        start_zone = get_zone(x_start, y_start)
        end_zone = get_zone(x_end, y_end)
        if end_zone == 4 or start_zone == 4:
            ret = (player, get_scale(start_zone, zoneSR[3]) * np.sqrt(4 * dx ** 2 + 1 * dy ** 2))
            output.append(ret)
        elif start_zone == 1:
            ret = (player, get_scale(start_zone, zoneSR[0]) * my_sign(dx) * np.sqrt(.25 * dx ** 2 + .125 * dy ** 2))
            output.append(ret)
        elif start_zone == 2:
            ret = (player, get_scale(start_zone, zoneSR[1]) * my_sign(dx) * np.sqrt(.5 * dx ** 2 + .125 * dy ** 2))
            output.append(ret)
        else:
            ret = (player, get_scale(start_zone, zoneSR[2]) * my_sign(dx) * np.sqrt(2 * dx ** 2 + .25 * dy ** 2))
            output.append(ret)

    return output


def my_sign(x):
    return 1 if x > 0 else 0


# generate_pass_metric(DATA_DIR+"/Full Datasets - Opta/USMNT/USMNT.csv", target_file="output/temp.csv")
f = "USMNTFilter"
country_list = ["USA", "France", "Croatia", "Belgium", "England", "Brazil", "US Women", f]
stem = "output/passesWC18NG"
generate_pass_metric_by_country(DATA_DIR + "/Full Datasets - Opta/WC/World Cup.csv", stem, country_list, wc_filter="Season 2017/2018", goalie=False)
generate_pass_metric(DATA_DIR+"/Full Datasets - Opta/USMNT/"+f+".csv", target_file=stem + f + ".csv", filterc="USA", wc_filter="Qualifying World Cup 2018")
generate_pass_metric(DATA_DIR+"/Full Datasets - Opta/WWC/Women's World Cup.csv", target_file=stem+"US Women.csv", filterc="USA Women", wc_filter="Season 2014/2015")
generate_averages_by_player(stem, country_list)
read_averages(stem, country_list)

# f = DATA_DIR+"/Full Datasets - Opta/USMNT/USMNTFilter.csv"
# generate_pass_metric(f, target_file="output/passesUSMNTFilter.csv")
# avg_stv(target_file="output/passesUSMNTFilter.csv")


