import csv
import pdb
import numpy as np
import matplotlib.pyplot as plt

stem = "output/passesWC18NG"
countries = ["Croatia", "France", "Belgium", "England", "USMNTFilter"]
outstem = "output/percentages/"
NUM_PLAYERS = 10
role_map = {
    "Luka Modric": "M",
    "Ante Rebic": "F",
    "Ivan Perisic": "F",
    "Vedran Corluka": "D",
    "Filip Bradaric": "M",
    "Josip Pivaric": "D",
    "Ivan Rakitic": "M",
    "Milan Badelj": "M",
    "Mateo Kovacic": "M",
    "Andrej Kramaric": "F",
    "Sime Vrsaljko": "D",
    "Duje Caleta-Car": "D",
    "Marko Pjaca": "F",
    "Marcelo Brozovic": "M",
    "Domagoj Vida": "D",
    "Ivan Strinic": "D",
    "Tin Jedvaj": "D",
    "Mario Mandzukic": "F",
    "Dejan Lovren": "D",
    "Paul Pogba": "M",
    "Ousmane Dembélé": "F",
    "Thomas Lemar": "F",
    "Antoine Griezmann": "F",
    "Kylian Mbappé": "F",
    "Nabil Fekir": "F",
    "Raphael Varane": "D",
    "Benjamin Mendy": "D",
    "Olivier Giroud": "F",
    "Samuel Umtiti": "D",
    "Djibril Sidibe": "D",
    "Blaise Matuidi": "M",
    "Corentin Tolisso": "M",
    "Benjamin Pavard": "D",
    "Presnel Kimpembe": "D",
    "Steven N'Zonzi": "M",
    "Lucas Hernández": "D",
    "N'Golo Kanté": "M",
    "DeAndre Yedlin": "D",
    "Geoff Cameron": "D",
    "Paul Arriola": "M",
    "Bobby Wood": "F",
    "Jordan Morris": "F",
    "Christian Pulisic": "M",
    "Jozy Altidore": "F",
    "Matt Besler": "D",
    "Clint Dempsey": "F",
    "Fabian Johnson": "M",
    "Darlington Nagbe": "M",
    "Jermaine Jones": "M",
    "Jorge Flores Villafaña": "D",
    "Michael Bradley": "M",
    "Omar González": "D",
    "Kellyn Acosta": "M",
    "Jorge Villafaña": "D",
    "John Brooks": "D",
    "Alejandro Bedoya": "M",
    "Dax McCarty": "M",
    "DaMarcus Beasley": "M",
    "Graham Zusi": "M",
    "Tim Ream": "D",
    "Timothy Chandler": "D",
    "Benny Feilhaber": "M",
    "Youri Tielemans": "M",
    "Thorgan Hazard": "M",
    "Eden Hazard": "F",
    "Kevin De Bruyne": "M",
    "Dries Mertens": "F",
    "Romelu Lukaku": "F",
    "Thomas Meunier": "D",
    "Yannick Carrasco": "M",
    "Vincent Kompany": "D",
    "Mousa Dembélé": "M",
    "Jan Vertonghen": "D",
    "Toby Alderweireld": "D",
    "Dedryck Boyata": "D",
    "Marouane Fellaini": "M",
    "Axel Witsel": "M",
    "Thomas Vermaelen": "D",
    "Nacer Chadli": "M",
    "Michy Batshuayi": "F",
    "Jamie Vardy": "F",
    "Harry Kane": "F",
    "Marcus Rashford": "F",
    "Kieran Trippier": "D",
    "Jordan Henderson": "M",
    "Bamidele Alli": "M",
    "Ashley Young": "D",
    "John Stones": "D",
    "Harry Maguire": "D",
    "Kyle Walker": "D",
    "Ruben Loftus-Cheek": "M",
    "Raheem Sterling": "F",
    "Jesse Lingard": "M",
    "Eric Dier": "M",
    "Danny Rose": "D",
    "Fabian Delph": "D",
    "Douglas Costa de Souza": "F",
    "Neymar da Silva Santos Júnior": "F",
    "Philippe Coutinho": "M",
    "Carlos Henrique José Francisco Venâncio": "M",
    "Marcelo Vieira Da Silva Junior": "D",
    "Roberto Firmino Barbosa de Oliveira": "F",
    "Gabriel Fernando de Jesus": "F",
    "Carlos Henrique Jose Francisco Venancio": "M",
    "Filipe Luis Kasmirski": "D",
    "Willian Borges Da Silva": "M",
    "Renato Soares de Oliveira Augusto": "M",
    "Thiago Emiliano da Silva": "D",
    "Marcos Aoas Correa": "D",
    "Fernando Luiz Rosa": "M",
    "João Miranda De Souza Filho": "D",
    "Filipe Luís Kasmirski": "D",
    "Fagner Conserva Lemos": "D",
    "José Paulo Bezerra Maciel Júnior": "M",
    "Danilo Luiz da Silva": "D",
    "Megan Rapinoe": "F",
    "Amy Rodriguez": "F",
    "Lori Chalupny": "D",
    "Julie Ertz": "M",
    "Meghan Klingenberg": "D",
    "Ali Krieger": "D",
    "Tobin Heath": "F",
    "Sydney Leroux": "F",
    "Kelley O'Hara": "D",
    "Morgan Brian": "M",
    "Christen Press": "F",
    "Carli Lloyd": "M",
    "Lauren Holiday": "M",
    "Alex Morgan": "F",
    "Christie Pearce": "D",
    "Becky Sauerbrunn": "D",
    "Abby Wambach": "F",
    "Heather O'Reilly": "M",
}

Dlist = []
Mlist = []
Flist = []
Olist = []

for c in countries:
    infile = stem+c+"players.csv"
    players = []
    scores = []

    with open(infile, "r") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        p_index = header.index("Player")
        s_index = header.index("Score")
        for row in reader:
            p = row[p_index]
            s = float(row[s_index])
            if s > 0:
                players.append(p)
                scores.append(s)
            # print('"'+row[p_index] + '": "", ')
        # print(players)
        # print(scores)
    # exit(1)
    vals = {"M": [], "D": [], "F": []}
    for i in range(len(players)):
        p = players[i]
        role = role_map[p]
        vals[role].append(scores[i])
    # pdb.set_trace()
    total = sum(scores)
    Mlist.append(sum(vals["M"]) / total)
    Dlist.append(sum(vals["D"]) / total)
    Flist.append(sum(vals["F"]) / total)
for i in range(len(Mlist)):
    Olist.append(1-Mlist[i]-Dlist[i]-Flist[i])
print(Dlist)
print(Mlist)
print(Flist)
print(Olist)

Dlist = np.array(Dlist) * 100
Mlist = np.array(Mlist) * 100
Flist = np.array(Flist) * 100
Olist = np.array(Olist) * 100

ind = np.arange(len(countries))
width = .5

fig = plt.figure()
ax = plt.subplot(111)

p1 = plt.bar(ind, Dlist, width)
p2 = plt.bar(ind, Mlist, width, bottom=Dlist)
p3 = plt.bar(ind, Flist, width, bottom=Dlist+Mlist)
p4 = plt.bar(ind, Olist, width, bottom=Dlist+Mlist+Flist)

plt.ylim((0, 100))
plt.xticks(ind, [c if c != "USMNTFilter" else "USA" for c in countries])
# plt.legend((p1[0], p2[0], p3[0]), ("Defender", "Midfield", "Forward"), loc='best')
t1 = "Contribution to Forward Progression by Role (Men's)"
t2 = "USA Mens vs Womens Teams Contribution to Forward Progression"
plt.title(t1)
plt.ylabel("Percent Contribution")

# Horizontal Line
# print(Flist[:-1])
# print(np.mean(Flist[:-1]))
# print(np.mean(Flist))
bar = 100 - np.mean(Flist[:-1])
print(bar)
xmin, xmax = plt.xlim()
line = plt.plot((xmin, xmax), (bar, bar), label="Test", linestyle='--', color='r')

# Labels
for r1, r2, r3, r4 in zip(p1, p2, p3, p4):
    h1 = r1.get_height()
    h2 = r2.get_height()
    h3 = r3.get_height()
    plt.text(r1.get_x() + r1.get_width() / 2., h1 / 2., "%.1f" % h1, ha="center", va="bottom", color="white", fontsize=10,
             fontweight="bold")
    plt.text(r2.get_x() + r2.get_width() / 2., h1 + h2 / 2., "%.1f" % h2, ha="center", va="bottom", color="white",
             fontsize=10, fontweight="bold")
    plt.text(r3.get_x() + r3.get_width() / 2., h1 + h2 + h3 / 2., "%.1f" % h3, ha="center", va="bottom", color="white",
             fontsize=10, fontweight="bold")


# Legend
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
first_legend = plt.legend((p1[0], p2[0], p3[0]), ("Defender", "Midfield", "Forward"), loc='center left', bbox_to_anchor=(1, .3))
plt.gca().add_artist(first_legend)
textstr = str(100-round(bar))+"%\nAverage of all non\nUS teams' contribution to \nforward progression from\nthe forward role"
props = dict(boxstyle='round', facecolor='white', alpha=0.7)

# place a text box in upper left in axes coords
ax.text(.99, bar/100+.03, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='top', bbox=props)
# box = ax.get_position()
# ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
# ax.legend((p1[0], p2[0], p3[0]), ("Defender", "Midfield", "Forward"), loc='center left', bbox_to_anchor=(1, 0.5))


plt.show()
