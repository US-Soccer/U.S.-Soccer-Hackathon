var factor = 0.5;


var holder3 = d3.select("#heatmap-divid3") // select the 'body' element
      .append("svg")     
      .attr("width", 1000*factor)      
      .attr("height", 500*factor);

// draw a rectangle - pitch
holder3.append("rect")        // attach a rectangle
    .attr("x", 0)         // position the left of the rectangle
    .attr("y", 0)          // position the top of the rectangle
    .attr("height", 500*factor)    // set the height
    .attr("width", 1000*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280")    // set the fill colour 
    .attr("id", "pitch_rec")



// draw a rectangle - halves
holder3.append("rect")        // attach a rectangle
    .attr("x", 0)         // position the left of the rectangle
    .attr("y", 0)          // position the top of the rectangle
    .attr("height", 500*factor)    // set the height
    .attr("width", 500*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280");    // set the fill colour 


// draw a circle - center circle
holder3.append("circle")          // attach a circle
    .attr("cx", 500*factor)             // position the x-centre
    .attr("cy", 250*factor)             // position the y-centre
    .attr("r", 50*factor)               // set the radius
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")      // set the line colour
    .style("fill", "none");      // set the fill colour


// draw a rectangle - penalty area 1
holder3.append("rect")        // attach a rectangle
    .attr("x", 0)         // position the left of the rectangle
    .attr("y", 105*factor)          // position the top of the rectangle
    .attr("height", 290*factor)    // set the height
    .attr("width", 170*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280");    // set the fill colour 


// draw a rectangle - penalty area 2
holder3.append("rect")        // attach a rectangle
    .attr("x", 830*factor)         // position the left of the rectangle
    .attr("y", 105*factor)          // position the top of the rectangle
    .attr("height", 290*factor)    // set the height
    .attr("width", 170*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280");    // set the fill colour 

// draw a rectangle - six yard box 1
holder3.append("rect")        // attach a rectangle
    .attr("x", 0)         // position the left of the rectangle
    .attr("y", 184*factor)          // position the top of the rectangle
    .attr("height", 132*factor)    // set the height
    .attr("width", 60*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280");    // set the fill colour 

// draw a rectangle - six yard box 2
holder3.append("rect")        // attach a rectangle
    .attr("x", 940*factor)         // position the left of the rectangle
    .attr("y", 184*factor)          // position the top of the rectangle
    .attr("height", 132*factor)    // set the height
    .attr("width", 60*factor)    // set the width
    .style("stroke-width", 5)    // set the stroke width
    .style("stroke", "#001400")    // set the line colour
    .style("fill", "#80B280");    // set the fill colour 


// draw a circle - penalty spot 1
holder3.append("circle")        // attach a circle
    .attr("cx", 120*factor)           // position the x-centre
    .attr("cy", 250*factor)           // position the y-centre
    .attr("r", 5)             // set the radius
    .style("fill", "#001400");     // set the fill colour

// draw a circle - penalty spot 2
holder3.append("circle")        // attach a circle
    .attr("cx", 880*factor)           // position the x-centre
    .attr("cy", 250*factor)           // position the y-centre
    .attr("r", 5)             // set the radius
    .style("fill", "#001400");     // set the fill colour

// draw a circle - center spot
holder3.append("circle")        // attach a circle
    .attr("cx", 500*factor)           // position the x-centre
    .attr("cy", 250*factor)           // position the y-centre
    .attr("r", 5)             // set the radius
    .style("fill", "#001400");     // set the fill colour



// penalty box semi-circle 1

var pi = Math.PI;
    
var arc = d3.svg.arc()
    .innerRadius(70*factor)
    .outerRadius(75*factor)
    .startAngle(0.75) //radians
    .endAngle(2.4) //just radians
    
var arc2 = d3.svg.arc()
    .innerRadius(70*factor)
    .outerRadius(75*factor)
    .startAngle(-0.75) //radians
    .endAngle(-2.4) //just radians

    // holder3.append("path")
    // .attr("d", arc)
    // .attr("fill", "#001400")
    // .attr("transform", "translate(90,187.5)");

    // holder3.append("path")
    // .attr("d", arc2)
    // .attr("fill", "#001400")
    // .attr("transform", "translate(660,187.5)");