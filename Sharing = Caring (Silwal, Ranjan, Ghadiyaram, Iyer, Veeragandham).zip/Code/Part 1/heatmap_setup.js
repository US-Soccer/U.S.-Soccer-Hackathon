// now generate some random data
var factor = 0.5;
var width = 1000*factor;
var height = 500*factor;
var newpoints = [];
var newpoints2 = [];
var newpoints3 = [];
var local_count = 0;
var local_count2 = 0;
var matchups = {"matchup1": ["croatia.csv", "france.csv"], "matchup2": ["ne.csv", "mont.csv"], "matchup3": ["belgium.csv", "usa.csv"]}

var segment1 = holder.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });


var segment2 = holder.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });



var segment12 = holder2.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });


var segment22 = holder2.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });

var segment13 = holder3.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });


var segment23 = holder3.append('line')
              .attr({
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 0,
                stroke: '#000',
                "stroke-width": 5
              });

var heatmapInstance = h337.create({container: document.querySelector('.heatmap-div'), 
  radius: 50,
  minOpacity: 0,
  maxOpacity: 0.7,
});

var heatmapInstance2 = h337.create({container: document.querySelector('.heatmap-div2'), 
  radius: 80,
  minOpacity: 0,
  maxOpacity: 0.7,
});

var heatmapInstance3 = h337.create({container: document.querySelector('.heatmap-div3'), 
  radius: 80,
  minOpacity: 0,
  maxOpacity: 0.7,
});


// function update_heatmap(this_x, this_y){
//   compute_data(this_x, this_y);
// };

function compute_data(this_x, this_y){
    newpoints3 = [];
    newpoints = [];
    newpoints2 = [];

  var team1 = document.getElementById("team1");
  var value1 = team1.options[team1.selectedIndex].value;
  var actual_team1 = matchups[value1][0];

  d3.csv(actual_team1, function (data) {
    local_count = 0;
    for (var i = 0; i < data.length; i++){
      if ((Math.abs(this_x - data[i].canvas_x_start) < 25) && (Math.abs(this_y - data[i].canvas_y_start) < 25)){
            local_count += 1;
      };
    };
    for (var i = 0; i < data.length; i++){
      if ((Math.abs(this_x - data[i].canvas_x_start) < 25) && (Math.abs(this_y - data[i].canvas_y_start) < 25)){
            newpoints.push({x: parseFloat(data[i]["canvas_x_end"]), y: parseFloat(data[i].canvas_y_end), value: 1/local_count});
          if ((Math.abs(this_x - data[i].canvas_x_start) > 15) && (Math.abs(this_y - data[i].canvas_y_start) > 15)) {
          newpoints3.push({x: parseFloat(data[i]["canvas_x_end"]), y: parseFloat(data[i].canvas_y_end), value: 1/local_count});
            };
      };
    };
    make_heatmap2(newpoints, 1/local_count2*20, 0);
    make_heatmap(newpoints3, 1/local_count*2, 0);

  });


  var actual_team2 = matchups[value1][1];

  d3.csv(actual_team2, function (data2) {
    local_count2 = 0;

    for (var i = 0; i < data2.length; i++){
      if ((Math.abs(this_x - data2[i].canvas_x_start) < 25) && (Math.abs(this_y - data2[i].canvas_y_start) < 25)){
            local_count2 += 1;
      };
    };
    for (var i = 0; i < data2.length; i++){
      if ((Math.abs(this_x - data2[i].canvas_x_start) < 25) && (Math.abs(this_y - data2[i].canvas_y_start) < 25)){
            newpoints2.push({x: parseFloat(data2[i]["canvas_x_end"]), y: parseFloat(data2[i].canvas_y_end), value: 1/local_count2});
        if ((Math.abs(this_x - data2[i].canvas_x_start) > 15) && (Math.abs(this_y - data2[i].canvas_y_start) > 15)) {
        newpoints3.push({x: parseFloat(data2[i]["canvas_x_end"]), y: parseFloat(data2[i].canvas_y_end), value: -1/local_count2});
          };
      };
    };
    make_heatmap3(newpoints2, 1/local_count2*20, 0);

  });

};


// document.querySelector('.wrapper').onmousedown = function(ev) {
//  compute_data(ev.layerX, ev.layerY);
//  draw_circle(ev.layerX, ev.layerY);
//  draw_circle2(ev.layerX, ev.layerY);
//  draw_circle3(ev.layerX, ev.layerY);
// };

document.querySelector('.wrapper2').onmousedown = function(ev) {
 compute_data(ev.layerX, ev.layerY);
 draw_circle(ev.layerX, ev.layerY);
 draw_circle2(ev.layerX, ev.layerY);
 draw_circle3(ev.layerX, ev.layerY);
};

// document.querySelector('.wrapper3').onmousedown = function(ev) {
//  compute_data(ev.layerX, ev.layerY);
//  draw_circle(ev.layerX, ev.layerY);
//  draw_circle2(ev.layerX, ev.layerY);
//  draw_circle3(ev.layerX, ev.layerY);
// };


function draw_circle(x, y){
    segment1.attr('x1', x-15).attr('y1', y-15).attr('x2', x+15).attr('y2', y+15)
    segment2.attr('x1', x+15).attr('y1', y-15).attr('x2', x-15).attr('y2', y+15)
}

function draw_circle2(x, y){
    segment12.attr('x1', x-15).attr('y1', y-15).attr('x2', x+15).attr('y2', y+15)
    segment22.attr('x1', x+15).attr('y1', y-15).attr('x2', x-15).attr('y2', y+15)
}


function draw_circle3(x, y){
    segment13.attr('x1', x-15).attr('y1', y-15).attr('x2', x+15).attr('y2', y+15)
    segment23.attr('x1', x+15).attr('y1', y-15).attr('x2', x-15).attr('y2', y+15)
}


function make_heatmap(points, max, min){
  console.log(points.length);
  var data = { 
    min: min,
    max: max, 
    data: points 
  };
  heatmapInstance.setData(data);
};


function make_heatmap2(points, max, min){
  var data = { 
    min: min,
    max: max, 
    data: points 
  };
  heatmapInstance2.setData(data);
};


function make_heatmap3(points, max, min){

  var data = { 
    min: min,
    max: max, 
    data: points 
  };
  heatmapInstance3.setData(data);
};


