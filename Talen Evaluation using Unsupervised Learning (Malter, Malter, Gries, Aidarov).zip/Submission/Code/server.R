# server.R

shinyServer(function(input, output) {
  
  formulaText1 <- reactive({
    
    if (input$player_input != '') {
      paste(input$attempt_name, " chart for ", input$player_input)
    } else {
      paste(input$attempt_name, " chart for all players")
    }
    
  })
  
  # Return the formula text for printing as a caption
  output$caption1 <- renderText({
    formulaText1()
  })

  ### Shots Map ### 
  
  # output$plot1 <- renderPlot({  
  #   
  #   # Subset dataset based on input in ui.R
  #   #if (input$player_name != '') opta.plot <- opta[which(opta$player==input$player_name),]
  #   
  #   if (input$player_name != '') {
  #     opta.plot <- opta[which(opta$player==input$player_name),]
  #   } else {
  #     opta.plot <- opta
  #   }
  #   
  #   create_Pitch() + 
  #     geom_point(data = subset(opta.plot,
  #                     #player %in% (input$player_name) & 
  #                     fixture %in% (input$fixture_name) & 
  #                     event_type %in% (input$attempt_name)), aes(x, y), 
  #                color = 'yellow', size = 2)
  # })
  
### Generate Plot ###
  
  # Generate player list for autofill into text input
  player_list <- reactive({
    player_list <- as.character(opta$player)
  })
  
  fixture_list <- reactive({
    fixture_list <- unique(as.character(opta$fixture))
  })
  
  team_list <- reactive({
    team_list_home <- unique(as.character(opta$home))
    team_list_away <- unique(as.character(opta$away))
    team_list <- unique(append(team_list_home, team_list_away))
  })
  
  zone_list <- reactive({
    zone_list <- unique(as.character(opta$zone_bin))
  })
  
  output$player_input <- renderUI({
    selectInput(inputId = "player_input", label = "Select or type in a player.  Leave empty to see all.", choices = player_list())
  })
  
  output$fixture_input <- renderUI({
    pickerInput("fixture_name","Fixture", choices=fixture_list(), 
                                    options = list(`actions-box` = TRUE),
                                    selected='USA v Bolivia', multiple = T)
  })
  
  output$team1_input <- renderUI({
    pickerInput("team1_name","Team 1", choices=team_list(), 
                options = list(`actions-box` = TRUE),
                selected='USA', multiple = T)
  })
  
  output$team2_input <- renderUI({
    pickerInput("team2_name","Team 2", choices=team_list(), 
                options = list(`actions-box` = TRUE),
                selected='Bolivia', multiple = F)
  })
  
  output$zone_input <- renderUI({
    pickerInput("zone_name","Zone", choices=zone_list(), 
                options = list(`actions-box` = TRUE),selected=c('1', '2', '3', '4', '5', '6'), multiple = T)
  })
  
  
  
  
    output$plot1 <- renderPlot({

    # Player name input
    if (input$player_input != '') {
      opta.plot <- opta[which(opta$player==input$player_input),]
    } else {
      opta.plot <- opta
    }
    

    ggplot(subset(opta.plot, 
                    home %in% c(input$team1_name, input$team2_name) &
                    away %in% c(input$team1_name, input$team2_name) &
                    #fixture %in% (input$fixture_name) &
                    event_type %in% (input$attempt_name) &
                    period_id2 %in% (input$period) &
                    zone_bin %in% (input$zone_name)),
      aes(x = x, y = y)) +
      annotate_pitch(colour = "#ffffff",
                     fill = "#538032") +
      geom_point(aes(x=x,y=y, color=team),size=2) +   # players
      #geom_text(aes(x=x,y=y,group=player_id,label=player),color='black') +     # players
      theme_pitch() +
      coord_flip(xlim = c(49, 101),
                 ylim = c(-1, 101)) +
      labs(color='Team')
  })
  
  
### Generate a table summarizing each players stats ###
  
  output$table <- renderDataTable({
    opta_new <- unique(opta[, c('team', 'player')])
    opta_new <- subset(opta_new, player != '')
    colnames(opta_new)[which(names(opta_new) == "team")] <- "Team"
    colnames(opta_new)[which(names(opta_new) == "player")] <- "Player"
    opta_new <- opta_new[with(opta_new, order(Team, Player)), ]
    opta_new
  })
  
})