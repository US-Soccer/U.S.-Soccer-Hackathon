# global.R

library(shiny)
library(shinydashboard)
library(shinyWidgets)

source("~/Desktop/opta/create_pitch.R")
source("~/Desktop/opta/opta_clean.R")
