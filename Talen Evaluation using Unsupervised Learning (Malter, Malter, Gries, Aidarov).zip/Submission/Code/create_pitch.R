theme_pitch <- function(aspect_ratio = 68/105) {
  
  theme_basic <- ggplot2::theme(
    panel.grid.major = ggplot2::element_blank(),
    panel.grid.minor = ggplot2::element_blank(),
    axis.title       = ggplot2::element_blank(),
    axis.ticks       = ggplot2::element_blank(),
    axis.text        = ggplot2::element_blank(),
    axis.line        = ggplot2::element_blank(),
    panel.background = ggplot2::element_blank(),
    panel.border     = ggplot2::element_blank()
  )
  
  if (!is.null(aspect_ratio)) {
    return(list(theme_basic,
                ggplot2::theme(aspect.ratio = aspect_ratio)))
  }
  
  list(theme_basic)
}


annotate_pitch <- function(colour = "white",
                           fill = "white",
                           x_scale = 1,
                           y_scale = 1,
                           x_shift = 0,
                           y_shift = 0) {
  
  markings <- list(
    # Add pitch outline
    ggplot2::geom_rect(
      xmin = 0 * x_scale + x_shift,
      xmax = 100 * x_scale + x_shift,
      ymin = 0 * y_scale + y_shift,
      ymax = 100 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    # Centre circle
    ggplot2::annotation_custom(
      grob = grid::circleGrob(r  = grid::unit(1, "npc"),
                              gp = grid::gpar(col  = colour,
                                              fill = fill,
                                              lwd = 2)),
      xmin = (50-7) * x_scale + x_shift,
      xmax = (50+7) * x_scale + x_shift,
      ymin = (50-7) * y_scale + y_shift,
      ymax = (50+7) * y_scale + y_shift
    ),
    # Centre spot
    ggplot2::annotate(
      geom = "point",
      x = 50 * x_scale + x_shift,
      y = 50 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    # Halfway line
    ggplot2::annotate(
      "segment",
      x    = 50 * x_scale + x_shift,
      xend = 50 * x_scale + x_shift,
      y    = 0 * y_scale + y_shift,
      yend = 100 * y_scale + y_shift,
      colour = colour
    ),
    # Add penalty areas (with penalty spot)
    ggplot2::annotation_custom(
      grob = grid::circleGrob(r  = grid::unit(1, "npc"),
                              gp = grid::gpar(col  = colour,
                                              fill = fill,
                                              lwd = 2)),
      xmin = (88.5-7) * x_scale + x_shift,
      xmax = (88.5+7) * x_scale + x_shift,
      ymin = (50-7) * y_scale + y_shift,
      ymax = (50+7) * y_scale + y_shift
    ),
    ggplot2::geom_rect(
      xmin = 83 * x_scale + x_shift,
      xmax = 100 * x_scale + x_shift,
      ymin = 21.1 * y_scale + y_shift,
      ymax = 79.9 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    ggplot2::annotate(  # Penalty spot
      geom = "point",
      x = 88.5 * x_scale + x_shift,
      y = 50 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    ggplot2::annotation_custom(
      grob = grid::circleGrob(r  = grid::unit(1, "npc"),
                              gp = grid::gpar(col  = colour,
                                              fill = fill,
                                              lwd = 2)),
      xmin = (11.5-7) * x_scale + x_shift,
      xmax = (11.5+7) * x_scale + x_shift,
      ymin = (50-7) * y_scale + y_shift,
      ymax = (50+7) * y_scale + y_shift
    ),
    ggplot2::geom_rect(
      xmin = 0 * x_scale + x_shift,
      xmax = 17 * x_scale + x_shift,
      ymin = 21.1 * y_scale + y_shift,
      ymax = 79.9 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    ggplot2::annotate(  # Penalty spot
      geom = "point",
      x = 11.5 * x_scale + x_shift,
      y = 50 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    # Add 6 yard boxes
    ggplot2::geom_rect(
      xmin = 94.2 * x_scale + x_shift,
      xmax = 100 * x_scale + x_shift,
      ymin = 36.8 * y_scale + y_shift,
      ymax = 63.2 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    ggplot2::geom_rect(
      xmin = 0 * x_scale + x_shift,
      xmax = 5.8 * x_scale + x_shift,
      ymin = 36.8 * y_scale + y_shift,
      ymax = 63.2 * y_scale + y_shift,
      colour = colour,
      fill = fill
    ),
    # Add goals
    ggplot2::geom_rect(
      xmin = 99.8 * x_scale + x_shift,
      xmax = 100.2 * x_scale + x_shift,
      ymin = 44.2 * y_scale + y_shift,
      ymax = 55.8 * y_scale + y_shift,
      colour = '#000000',
      fill = '#000000'
    ),
    ggplot2::geom_rect(
      xmin = 0 * x_scale + x_shift,
      xmax = -2 * x_scale + x_shift,
      ymin = 44.2 * y_scale + y_shift,
      ymax = 55.8 * y_scale + y_shift,
      colour = colour,
      fill = fill
    )
  )
  
  return(markings)
}

#' Adds soccer pitch markings as a layer for use in a ggplot plot.
#'
#' This function is deprecated. Please use `annotate_pitch` instead.
#'
#' @export
pitch_layer <- function(colour = "black",
                        fill = "white",
                        x_scale = 1,
                        y_scale = 1,
                        x_shift = 0,
                        y_shift = 0) {
  .Deprecated("annotate_pitch")
  annotate_pitch(
    colour,
    fill,
    x_scale,
    y_scale,
    x_shift,
    y_shift)
}