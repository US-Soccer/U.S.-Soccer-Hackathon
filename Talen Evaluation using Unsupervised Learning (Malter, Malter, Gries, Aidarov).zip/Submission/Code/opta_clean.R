#################################
# Title: Cleaning of Opta Data
# Author: Danny Malter
#################################

library(dplyr)
library(data.table)
library(stringr)
library(tidyverse)

source("~/Desktop/opta/create_pitch.R")

opta <- read.csv("~/Desktop/opta/Sample_Data.csv", header=TRUE) 

# Test dataset
#test <- opta[11:20,c(1:26)]
#setDT(test)[, possession_count := seq_len(.N), by=rleid(team, fixture)]



##### Data Cleaning #####

# sort by date, fixture, min and sec
opta <- setDT(opta)[order(game_date, fixture, period_min, period_second),]

# Create a count for number of events over one possession
setDT(opta)[, possession_count := seq_len(.N), by=rleid(team, fixture)]

# Add dummy column for goals scored
opta$goal <- ifelse(opta$event_type == 'Goal', 1, 0)

# Add dummy column for if event is a shot
opta$shot <- ifelse(opta$event_type %in% c("Goal", "Keeper pick-up", 
                                           "Miss", "Post", "Punch"), 1, 0)

# Clean columns
opta$from_corner <- ifelse(is.na(opta$from_corner), 0, 1)
opta$head <- ifelse(is.na(opta$head), 0, 1)
opta$penalty <- ifelse(is.na(opta$penalty), 0, 1)
opta$blocked <- ifelse(is.na(opta$blocked), 0, 1)
opta$flick_on <- ifelse(is.na(opta$flick_on), 0, 1)
opta$assist <- ifelse(is.na(opta$assist), 0, 1)
opta$long_ball <- ifelse(is.na(opta$long_ball), 0, 1)
opta$cross <- ifelse(is.na(opta$cross), 0, 1)
opta$head_pass <- ifelse(is.na(opta$head_pass), 0, 1)
opta$through_ball <- ifelse(is.na(opta$through_ball), 0, 1)
opta$free_kick_taken <- ifelse(is.na(opta$free_kick_taken), 0, 1)
opta$corner_taken <- ifelse(is.na(opta$corner_taken), 0, 1)
opta$attacking_pass <- ifelse(is.na(opta$attacking_pass), 0, 1)
opta$first_touch <- ifelse(is.na(opta$first_touch), 0, 1)

# Add column for key pass (pass leading to a shot)
opta$key_pass_previous <- shift(opta$shot, 1, type = 'lead')
opta$key_pass <- ifelse(opta$event_type == 'Pass' & opta$key_pass_previous == 1, 1, 0)  # pass leading to a shot
opta$key_pass_previous <- NULL

# Add a column for event 'from player'
opta[, from_player := .(shift(player, 1L, fill=NA, type="lag"))]
player_list <- list(opta$player)
from_player_list <- list(opta$from_player)

# Clean period
opta$period_id <- as.factor(opta$period_id)
opta$period_id2 <- opta$period_id
levels(opta$period_id2)[levels(opta$period_id2) %in%  c("1", "3")] <- "First Half"
levels(opta$period_id2)[levels(opta$period_id2) %in%  c("2", "4")] <- "Second Half"

# Add shot zones - assuming dimensinos are 100 x 100
opta <- opta %>%
  mutate(zone_bin = ifelse(x > 94 & abs(y - 60) < 10, 1, 
                       ifelse(x > 82 & abs(y - 60) < 10, 2, 
                              ifelse(x > 82 & abs(y - 60) < 22, 3, 
                                     ifelse(x > 72 & abs(y - 60) < 22, 4, 
                                            ifelse(abs(y - 60) < 22, 5, 6))))))
opta$zone_bin <- as.factor(opta$zone_bin)

# Find distance from point to center of x-axis and also to goal line on y-axis.
findDistance<-function(x, y){
  x_off <- abs(136-x)
  y_off <- 0-y
  distance <- sqrt((x_off*x_off)+(y_off*y_off))
  return(distance)
}

# Add shot distance to dataframe
opta$shot_dist <- findDistance(opta$x, opta$y)

# Divide shot_dist by 4 to convert distance of co-ordinates to metres
opta$shot_dist <- findDistance(as.numeric(opta$x), as.numeric(opta$y))/4

# Calculate shot angle to goal
findAngle <- function(x, y){
  #co-ordinates post to post
  d1 = 30
  #distance from ball to post 1
  d2 = findDistance(x-15, y)
  #distance from ball to post 2
  d3 = findDistance(x+15, y)
  #cosine rule
  angle = acos(((d2*d2)+(d3*d3)-(d1*d1))/(2*d2*d3))
  #convert radians to degrees
  angle <- (angle*180)/pi
  return(angle)
}

opta$shot_angle <- findAngle(as.numeric(opta$x), as.numeric(opta$y))



##### Summary Statistics #####

# number of passes by possession
opta %>%
  group_by(event_type, possession_count) %>% 
  summarize(avg_passes = max(possession_count))

# summary for each team by game
opta %>% 
  group_by(fixture, team) %>%
  summarise(goals = sum(goal),
            shots = sum(shot),
            shots1 = sum(shot[zone_bin=="1"]),  # sum shots for zone bin 1
            shots2 = sum(shot[zone_bin=="2"]),
            shots3 = sum(shot[zone_bin=="3"]),
            shots4 = sum(shot[zone_bin=="4"]),
            shots5 = sum(shot[zone_bin=="5"]),
            shots6 = sum(shot[zone_bin=="6"]),
            corners = sum(corner_taken),
            blocked = sum(blocked),
            free_kicks = sum(free_kick_taken),
            goal_from_corner = sum(goal[from_corner=="1"]),
            goal_from_head = sum(goal[head=="1"]))