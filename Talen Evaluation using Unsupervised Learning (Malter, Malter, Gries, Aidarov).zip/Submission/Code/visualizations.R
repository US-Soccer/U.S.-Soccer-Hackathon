#################################
# Title: Visualizing Opta Data
# Author: Danny Malter
#################################

library(ggplot2)
library(ggforce)
library(ggsoccer)  # devtools::install_github("torvaney/ggsoccer")
library(igraph)
library(visNetwork)

source("~/Desktop/opta/opta_clean.R")

##### Plotting #####

# plot shots
opta.shots <- subset(opta, shot == 1)

ggplot(opta.shots, aes(x = x, y = y)) +
  annotate_pitch(colour = "gray50",
                 fill = "gray90") +
  geom_point(fill = "white", size = 3, pch = 21) +
  #geom_point(aes(x=x,y=y,group=player_id,color=factor(player)),size=2) +   # players
  #geom_text(aes(x=x,y=y,group=player_id,label=player),color='black') +     # players
  theme_pitch() +
  coord_flip(xlim = c(49, 101),
             ylim = c(-1, 101)) +
  labs(color='Player Name') +
  ggtitle("Shotmap")


# plot of passes for possession 3
opta.passes <- subset(opta, event_type == "Pass" & fixture == 'USA v Bolivia' & 
                        team == 'USA' & possession_count == 3)

ggplot(opta.passes) + 
  annotate_pitch(colour = "#ffffff",
                 fill = "#538032") +
  geom_segment(aes(x = x, y = y, xend = pass_end_x, yend = pass_end_y),
               arrow = arrow(length = unit(0.25, "cm"),
                             type = "closed")) +
  geom_point(aes(x=x,y=y),size=2) +   # players
  #geom_text(aes(x=x,y=y,group=player_id,label=player),color='black') +     # players
  theme_pitch() +
  #direction_label() +
  xlim(-1, 101) +
  ylim(-5, 101) +
  labs(color='Player Name')

# plot of spacial range for possession

ggplot(opta.passes) + 
  annotate_pitch(colour = "#ffffff",
                 fill = "#538032") +
  geom_point(data=opta.passes,aes(x=x,y=y,group=player_id,color=factor(player)),size=2) +       #players
  geom_text(data=opta.passes,aes(x=x,y=y,group=player_id,label=player),color='black') +     #players
  geom_polygon(data=opta.passes,aes(x=x,y=y,group=player_id,fill=factor(player)),alpha = 0.2) +  #convex hull
  #geom_point(data=opta,aes(x=x,y=y),color='darkorange',size=3) +             #ball
  #scale_color_manual(values=c("blue","orange", "green", "red", "lightsteelblue2", "orangered2", "purple", "yellow", "black", "grey")) +
  #scale_fill_manual(values=c("blue","orange", "green", "red", "lightsteelblue2", "orangered2", "purple", "yellow", "black", "grey")) +
  theme(legend.position="none")

### Network Graph ###
opta.network <- subset(opta, event_type == "Pass" & fixture == 'USA v Bolivia' & 
                         team == 'USA' & possession_count == 3)

df.passes <- data.frame(subset(opta.network))
df.pass <- df.passes[,c("from_player","player")]
df.pass.links <- subset(df.pass, !is.na(from_player))
df.pass.links$from_player <- as.character(df.pass.links$from_player)
df.pass.links$player <- as.character(df.pass.links$player)
colnames(df.pass.links)[1] <- "from"
colnames(df.pass.links)[2] <- "to"
df.pass.links <- subset(df.pass.links, from != '')
df.pass.links <- subset(df.pass.links, to != '')
df.pass.links <- df.pass.links[which(df.pass.links$from!=df.pass.links$to),] # remove rows where to and from are the same
df.pass.links

df.pass.nodes1 <- data.frame(unique(df.pass.links[, c(1,1)]))
colnames(df.pass.nodes1)[1] <- "id1"
colnames(df.pass.nodes1)[2] <- "id2"
df.pass.nodes2 <- data.frame(unique(df.pass.links[, c(2,2)]))
colnames(df.pass.nodes2)[1] <- "id1"
colnames(df.pass.nodes2)[2] <- "id2"
df.pass.nodes <- unique(rbind(df.pass.nodes1, df.pass.nodes2))
colnames(df.pass.nodes)[1] <- "id"
colnames(df.pass.nodes)[2] <- "player"

net <- graph_from_data_frame(d=df.pass.links, vertices=df.pass.nodes, directed=T) 
net <- simplify(net, remove.multiple = F, remove.loops = T) 

# compute node size
deg <- degree(net, mode="all")
V(net)$size <- deg*3

plot(net, edge.arrow.size=.4, edge.curved=.1)

plot(net, edge.arrow.size=.2, edge.color="orange",
     vertex.color="orange", vertex.frame.color="#ffffff",
     vertex.label=V(net)$media, vertex.label.color="black") 


### Network Graph ###

# We'll start by adding new node and edge attributes to our dataframes. 
vis.nodes <- df.pass.nodes
vis.links <- df.pass.links

vis.nodes$shape  <- "dot"  
vis.nodes$shadow <- TRUE # Nodes will drop shadow
#vis.nodes$title  <- vis.nodes$media # Text on click
vis.nodes$label  <- vis.nodes$player # Node label
vis.nodes$size <- degree(net, mode="all")
#vis.nodes$size   <- vis.nodes$audience.size # Node size
vis.nodes$borderWidth <- 2 # Node border width

vis.nodes$color.background <- c("slategrey", "tomato", "gold")[df.pass.nodes$player]
vis.nodes$color.border <- "black"
vis.nodes$color.highlight.background <- "orange"
vis.nodes$color.highlight.border <- "darkred"

vis.links$color <- "gray"    # line color  
vis.links$arrows <- "to" # arrows: 'from', 'to', or 'middle'
#vis.links$smooth <- FALSE    # should the edges be curved?
vis.links$shadow <- FALSE    # edge shadow

visnet <- visNetwork(vis.nodes, vis.links,
                     main="In Game Passing Network",
                     footer= "Passes amongst players")

visOptions(visnet, highlightNearest = TRUE, selectedBy = "player")
visNetwork(vis.nodes, vis.links) %>%
  visOptions(highlightNearest = TRUE, selectedBy = "player")
