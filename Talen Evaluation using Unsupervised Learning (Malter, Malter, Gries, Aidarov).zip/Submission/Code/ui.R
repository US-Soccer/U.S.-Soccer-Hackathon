# ui.R

dashboardPage(skin="black",
              dashboardHeader(title = "Field Map"),
              dashboardSidebar(
                sidebarMenu(
                  menuItem(uiOutput("player_input")),
                  menuItem(selectInput("attempt_name", label = h4("Shot Result"),
                                       c("Goal", "Attempt saved", "Keeper pick-up", "Miss"),
                                       selected=c("Goal"))),
                  #menuItem(uiOutput("fixture_input")),
                  menuItem(uiOutput("team1_input")),
                  menuItem(uiOutput("team2_input")),
                  menuItem(uiOutput("zone_input")),
                  #menuItem(checkboxGroupInput("zone_bin", label = h4("Zone Breakdown"),
                  #                     c("1", "2", "3", "4", "5", "6"),
                  #                     selected=c("1", "2", "3", "4", "5", "6"), inline = TRUE)),
                  menuItem(checkboxGroupInput("period", label = h4("Period"),
                                       c("First Half", "Second Half"),
                                       selected=c("First Half", "Second Half"), inline = TRUE)),
                  menuItem("Plot", tabName = "plot", icon=icon("table")),
                  menuItem("Code",  icon = icon("file-text-o"),
                           menuSubItem("ui.R", tabName = "ui", icon = icon("angle-right")),
                           menuSubItem("server.R", tabName = "server", icon = icon("angle-right")),
                           menuSubItem("global.R", tabName = "global", icon = icon("angle-right"))
                  ),
                  menuItem("ReadMe", tabName = "readme", icon=icon("mortar-board"))
                )
              ),
              
              dashboardBody(
                tabItems(
                  tabItem(tabName = "player_name"
                  ),
                  tabItem(tabName = "plot",
                                 h4(textOutput("caption1")),
                                 tags$head(tags$style("#caption1{color: black;
                                    font-size: 22px;;
                                 }")),
                                 HTML('<br/>'),
                                 box(plotOutput("plot1"), title = "Plot", width=12, collapsible = TRUE),
                                 HTML('<br/>'),
                                 box(dataTableOutput("table"), width=12, collapsible = TRUE)
                          ),
                  tabItem(tabName = "ui",
                          box( width = NULL, status = "primary", solidHeader = TRUE, title="ui.R",
                               br(),br(),
                               pre(includeText("ui.R"))
                          )
                  ),
                  tabItem(tabName = "server",
                          box( width = NULL, status = "primary", solidHeader = TRUE, title="server.R",
                               br(),br(),
                               pre(includeText("server.R"))
                          )
                  ),
                  tabItem(tabName = "global",
                          box( width = NULL, status = "primary", solidHeader = TRUE, title="global.R",
                               br(),br(),
                               pre(includeText("global.R"))
                          )
                  ),
                  tabItem(tabName = "readme",
                          includeMarkdown("readme.rmd")
                  )
                )
              )
)