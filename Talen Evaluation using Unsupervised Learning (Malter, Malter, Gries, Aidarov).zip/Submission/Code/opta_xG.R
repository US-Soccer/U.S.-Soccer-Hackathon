#################################
# Title: Expected Goals Scored
# Author: Danny Malter
#################################

library(caret)
library(gbm)

source("~/Desktop/opta/opta_clean.R")

##### Model Expected Goals ##### 
opta.shots <- subset(opta, shot == 1)
opta.shots$event_type <- levels(droplevels(opta.shots$event_type))  # drop unused levels
opta.shots$event_type <- ifelse(opta.shots$event_type == 'Goal', 'Goal', 'Miss')
opta.shots$event_type <- as.factor(opta.shots$event_type)

set.seed(3456)
trainIndex <- createDataPartition(opta.shots$event_type, p = .8, 
                                  list = FALSE, 
                                  times = 1)

shotsTrain <- opta.shots[ trainIndex,]
shotsTest  <- opta.shots[-trainIndex,]

ctrl <- trainControl(method = "cv", 
                     summaryFunction = twoClassSummary, 
                     classProbs = TRUE)

model.gbm1 <- train(event_type ~ shot_dist + shot_angle + head + first_touch + 
                      cross + head_pass + through_ball + free_kick_taken + corner_taken,
                   data=shotsTrain, 
                   method="gbm",
                   verbose=FALSE,
                   trControl = ctrl,
                   metric="ROC")

model.gbm1

summary(model.gbm1)

model1.predict <- predict(model.gbm1, newdata=shotsTest)

# plot confusion matrix of results
confusionMatrix(model1.predict, shotsTest$event_type)
