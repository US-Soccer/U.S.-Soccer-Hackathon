HOW TO RUN:

app.r file requires official dataset provided by the organisers. Due to confidentiality reasons, we wont be able to upload it. If you have the dataset files, kindly add them to the folder. 

1. Open app.r in RStudio
2. Click on RunApp
3. It should open a pane which will run the app


The csv files were genereted using the python code present in ComparisnGen.ipynb file. You will need jupyter notebook to view the content of the file.