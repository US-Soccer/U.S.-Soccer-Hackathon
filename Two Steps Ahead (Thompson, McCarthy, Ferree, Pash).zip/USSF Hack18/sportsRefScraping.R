rm(list=ls())

require("rvest")

sportsRefData <- NULL

for(i in 2004:2016) {
  sportsRef <- read_html(paste("http://www.sports-reference.com/cbb/seasons/", i, "-school-stats.html", sep=""))
  
  sportsRef <- sportsRef %>%
    html_nodes(".left , .right") %>%
    html_text()
  
  sportsRefTeam <- matrix(sportsRefTeam, ncol=34, byrow=T)
  
  sportsRefData <- rbind(sportsRefData, sportsRefTeam)
}



sportsRefOppData <- NULL

for(i in 2004:2016) {
  sportsRef <- read_html(paste("http://www.sports-reference.com/cbb/seasons/", i, "-opponent-stats.html", sep=""))
  
  sportsRefOpp <- sportsRef %>%
    html_nodes(".left , .right") %>%
    html_text()
  
  sportsRefOpp <- matrix(sportsRefOpp, ncol=34, byrow=T)
  
  sportsRefOppData <- rbind(sportsRefOppData, sportsRefOpp)
}


colnames(sportsRefData) <- c("Rank","School","G","W","L","W%","SRS","SOS","ConfW","ConfL","HomeW","HomeL","AwayW","AwayL","PtsF","PtsA","Blank","Mins","FG","FGA","FG%","3P","3PA","3P%","FT","FTA","FT%","ORB","TRB","AST","STL","BLK","TOV","PF")

colnames(sportsRefOppData) <- c("Rank","School","G","W","L","W%","SRS","SOS","ConfW","ConfL","HomeW","HomeL","AwayW","AwayL","PtsF","PtsA","Blank","Mins","OppFG","OppFGA","OppFG%","Opp3P","Opp3PA","Opp3P%","OppFT","OppFTA","OppFT%","OppORB","OppTRB","OppAST","OppSTL","OppBLK","OppTOV","OppPF")

sportsRefOppData <- sportsRefOppData[,-c(1:18)]
sportsRefData <- sportsRefData[,-17]

sportsRefData <- cbind(sportsRefData, sportsRefOppData)

write.csv(sportsRefData, "C:/Users/Jason/Documents/NC State/Sports Analytics/sportsRefData.csv")
