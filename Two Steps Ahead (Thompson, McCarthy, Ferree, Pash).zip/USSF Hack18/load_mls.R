### script to read in MLS data for USSF Hackathon 2018
## TEAM : Cardiac Pack

# required packages
packages <- c("tidyverse","data.table")
lapply(packages,require,character.only=TRUE)

### MLS Data
## NOTE : create variable dpath for local path to directory containing data
read_mls <- function(dpath){
  files <- list.files(dpath)
  mls_seasons <- list()
  for(ii in 1:length(files)){
    data <- fread(paste0(dpath,"/",files[ii]),sep=",",stringsAsFactors = FALSE)
    mls_seasons[[ii]] <- as.data.frame(data)
  }
  return(mls_seasons)
}

mls_dir <- "C:/Users/graha/Desktop/Hackathon Raw Files/Full Datasets - Opta/MLS"

mls_seasons <- read_mls(mls_dir)

# unpack list to dynamically assigned variable names
for(ii in 1:length(mls_seasons)){
  name <- paste0("mls",ii+10) # mls data starts in 2011 -- offset of 10 years
  assign(name,mls_seasons[[ii]])
}

rm(ii,mls_dir,name,mls_seasons,packages)