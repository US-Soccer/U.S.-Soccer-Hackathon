function(input, output, session) {
  
  output$plot1 <- renderPlot({
    cols <- rev(brewer.pal(10, "Spectral"))
    
    type <- eventReactive(input$go, {
      "tile"
    })
    
    xmin <- floor(input$x/10)*10
    xmax <- ceiling(input$x/10)*10
    ymin <- floor(input$y/10)*10
    ymax <- ceiling(input$y/10)*10
    if(abs(input$y-ymin)>5){ymin<-ymin+5}
    else{ymax<-ymax-5}
    
    xmin2 <- floor(input$x2/10)*10
    xmax2 <- ceiling(input$x2/10)*10
    ymin2 <- floor(input$y2/10)*10
    ymax2 <- ceiling(input$y2/10)*10
    if(abs(input$y2-ymin2)>5){ymin2<-ymin2+5}
    else{ymax2<-ymax2-5}
    
    # filter data
    mlsdata <- mls18 %>% filter((rep(100,dim(mls18)[1])-prev_start_y)>=xmin & (rep(100,dim(mls18)[1])-prev_start_y)<=xmax & prev_start_x>=ymin & prev_start_x<=ymax &
                                (rep(100,dim(mls18)[1])-y)>=xmin2 & (rep(100,dim(mls18)[1])-y)<=xmax2 & x>=ymin2 & x<=ymax2)
    # mlsdata <- mls18 %>% filter(x>=xmin,x<=xmax,y>=ymin,y<=ymax)
    
    
    g <- ggplot(data=mlsdata) +  
      stat_density2d(aes(x=rep(100,dim(mlsdata)[1])-as.numeric(pass_end_y), y=as.numeric(pass_end_x), z=1,
                         fill = ..density.., na.rm=TRUE), geom=type(),  contour = FALSE) + 
      scale_fill_gradientn(colours=cols) + 
      theme_minimal() +
      geom_segment(aes(x = 0, y = 0, xend = 100, yend = 0), size=1) + 
      geom_segment(aes(x = 0, y = 100, xend = 100, yend = 100), size=1) + 
      geom_segment(aes(x = 0, y = 0, xend = 0, yend = 100), size=1) + 
      geom_segment(aes(x = 100, y = 0, xend = 100, yend = 100), size=1) +
      geom_segment(aes(x=0, y= 50, xend = 100, yend = 50), size=1) + 
      geom_segment(aes(x=21, y=0, xend = 21, yend=17), size=1) + 
      geom_segment(aes(x=21, y=17, xend = 79, yend=17), size=1) + 
      geom_segment(aes(x=79, y=0, xend = 79, yend= 17), size=1) + 
      geom_segment(aes(x=0, y= 50, xend = 100, yend = 50), size=1) + 
      geom_segment(aes(x=36.8, y= 5.8, xend = 36.8, yend = 0), size=1) + 
      geom_segment(aes(x=63.2, y=0, xend = 63.2, yend = 5.8), size=1) + 
      geom_segment(aes(x=36.8, y=5.8, xend = 63.2, yend = 5.8), size=1)+ 
      geom_segment(aes(x=21, y=83, xend=21.2, yend=100), size=1) + 
      geom_segment(aes(x=21, y=83, xend=79, yend=83), size=1) + 
      geom_segment(aes(x=79, y=83, xend=79, yend=100), size=1)+ 
      geom_segment(aes(x=36.8, y=100, xend=36.8, yend=94.2), size=1) + 
      geom_segment(aes(x=36.8, y=94.2, xend=63.2, yend=94.2), size=1) + 
      geom_segment(aes(x=63.2, y= 100, xend=63.2, yend=94.2), size=1) +
      geom_segment(aes(x=xmin,y=ymin,xend=xmax,yend=ymin),size=0.7,color="white")+
      geom_segment(aes(x=xmin,y=ymax,xend=xmax,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmin,y=ymin,xend=xmin,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmax,y=ymin,xend=xmax,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymin2,xend=xmax2,yend=ymin2),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymax2,xend=xmax2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymin2,xend=xmin2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=xmax2,y=ymin2,xend=xmax2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=mean(xmin,xmax),y=mean(ymin,ymax),xend=mean(xmin2,xmax2),yend=mean(ymin2,ymax2)),
                   size=0.7,color="white",arrow=arrow())+
      NULL
    
    g
    # if(!is.null(input$origin)){
    #   g<-g+geom_segment(aes(x=12,y=12,xend=24,yend=24),size=5)
    # }else(g)
    
  })
  
  ##
  observeEvent(input$origin, {
    
    #create object for clicked polygon
    click <- input$origin
    RV$Clicks<-c(RV$Clicks,click$id)
    print(RV$Clicks)
    
  }) #END OBSERVE EVENT
  
  # observeEvent(input$dest,{
  #   dbl <- input$dest
  #   RV$Clicks<-c(RV$Clicks,click$id)
  #   print(RV$Clicks)
  # })
  ##
  
  output$plot2 <- renderPlot({
    cols <- rev(brewer.pal(10, "Spectral"))
    
    # xmin <- floor(input$plot_click$x/10)*10
    # xmax <- ceiling(input$plot_click$x/10)*10
    # if(abs(input$plot_click$x-xmin)>5){xmin<-xmin+5}
    # else{xmax<-xmax-5}
    # ymin <- floor(input$plot_click$y/10)*10
    # ymax <- ceiling(input$plot_click$y/10)*10
    
    
    type <- eventReactive(input$go, {
      "tile"
    })
    
    xmin <- floor(input$x/10)*10
    xmax <- ceiling(input$x/10)*10
    ymin <- floor(input$y/10)*10
    ymax <- ceiling(input$y/10)*10
    if(abs(input$y-ymin)>5){ymin<-ymin+5}
    else{ymax<-ymax-5}
    
    xmin2 <- floor(input$x2/10)*10
    xmax2 <- ceiling(input$x2/10)*10
    ymin2 <- floor(input$y2/10)*10
    ymax2 <- ceiling(input$y2/10)*10
    if(abs(input$y2-ymin2)>5){ymin2<-ymin2+5}
    else{ymax2<-ymax2-5}
    
    # filter data
    mlsdata <- mls18 %>% filter((rep(100,dim(mls18)[1])-prev_start_y)>=xmin & (rep(100,dim(mls18)[1])-prev_start_y)<=xmax & prev_start_x>=ymin & prev_start_x<=ymax &
                                  (rep(100,dim(mls18)[1])-y)>=xmin2 & (rep(100,dim(mls18)[1])-y)<=xmax2 & x>=ymin2 & x<=ymax2)
    # mlsdata <- mls18 %>% filter(x>=xmin,x<=xmax,y>=ymin,y<=ymax)
    
    
    g <- ggplot(data=mlsdata) +  
      stat_density2d(aes(x=rep(100,dim(mlsdata)[1])-as.numeric(pass_end_y), y=as.numeric(pass_end_x), z=1,
                         fill = ..density.., na.rm=TRUE), geom=type(),  contour = FALSE) + 
      scale_fill_gradientn(colours=cols) + 
      theme_minimal() +
      geom_segment(aes(x = 0, y = 0, xend = 100, yend = 0), size=1) + 
      geom_segment(aes(x = 0, y = 100, xend = 100, yend = 100), size=1) + 
      geom_segment(aes(x = 0, y = 0, xend = 0, yend = 100), size=1) + 
      geom_segment(aes(x = 100, y = 0, xend = 100, yend = 100), size=1) +
      geom_segment(aes(x=0, y= 50, xend = 100, yend = 50), size=1) + 
      geom_segment(aes(x=21, y=0, xend = 21, yend=17), size=1) + 
      geom_segment(aes(x=21, y=17, xend = 79, yend=17), size=1) + 
      geom_segment(aes(x=79, y=0, xend = 79, yend= 17), size=1) + 
      geom_segment(aes(x=0, y= 50, xend = 100, yend = 50), size=1) + 
      geom_segment(aes(x=36.8, y= 5.8, xend = 36.8, yend = 0), size=1) + 
      geom_segment(aes(x=63.2, y=0, xend = 63.2, yend = 5.8), size=1) + 
      geom_segment(aes(x=36.8, y=5.8, xend = 63.2, yend = 5.8), size=1)+ 
      geom_segment(aes(x=21, y=83, xend=21.2, yend=100), size=1) + 
      geom_segment(aes(x=21, y=83, xend=79, yend=83), size=1) + 
      geom_segment(aes(x=79, y=83, xend=79, yend=100), size=1)+ 
      geom_segment(aes(x=36.8, y=100, xend=36.8, yend=94.2), size=1) + 
      geom_segment(aes(x=36.8, y=94.2, xend=63.2, yend=94.2), size=1) + 
      geom_segment(aes(x=63.2, y= 100, xend=63.2, yend=94.2), size=1) +
      geom_segment(aes(x=xmin,y=ymin,xend=xmax,yend=ymin),size=0.7,color="white")+
      geom_segment(aes(x=xmin,y=ymax,xend=xmax,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmin,y=ymin,xend=xmin,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmax,y=ymin,xend=xmax,yend=ymax),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymin2,xend=xmax2,yend=ymin2),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymax2,xend=xmax2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=xmin2,y=ymin2,xend=xmin2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=xmax2,y=ymin2,xend=xmax2,yend=ymax2),size=0.7,color="white")+
      geom_segment(aes(x=mean(xmin,xmax),y=mean(ymin,ymax),xend=mean(xmin2,xmax2),yend=mean(ymin2,ymax2)),
                   size=0.7,color="white",arrow=arrow())+
      NULL
    
    g
    
  })
  
  output$info <- renderText({
    paste0("xorigin=", input$origin$x, "\nyorigin=", input$origin$y,"\nxdest=",input$dest$x,'\nydest=',input$dest$y)
  })
  
  
}