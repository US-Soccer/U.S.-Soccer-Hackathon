library(ggplot2)
library(RColorBrewer)
library(data.table)

basicPage(
    fluidRow(
      column(width=1,
             numericInput("x", "Start X:", 49, min = 0, max = 100),
             numericInput("y", "Start Y:", 49, min = 0, max = 100),
             numericInput("x2", "End X:", 29, min = 0, max = 100),
             numericInput("y2", "End Y:", 49, min = 0, max = 100),
             actionButton("go", "Go")
      ),
      column(width=5,plotOutput("plot1", height=800,
                 click = "origin",
                 dblclick = dblclickOpts(
                   id = "dest"
                 )
        )
        
      ),
      column(width=5,plotOutput("plot2",height=800))
    )
)