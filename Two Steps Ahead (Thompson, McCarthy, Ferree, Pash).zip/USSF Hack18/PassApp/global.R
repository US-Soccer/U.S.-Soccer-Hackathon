library(data.table)
library(dplyr)

gana <- as.data.frame(fread("./gana.csv"))
mls <- as.data.frame(fread("./mls18.csv"))
mls18 <- mls
#mls18 <- mls
