# required packages
packages <- c("tidyverse","dplyr")
lapply(packages,require,character.only=TRUE)

source('load_mls.R')
mls_seasons <- list(mls11,mls12,mls13,mls14,mls15,mls16,mls17,mls18)

mls_passes <- list()

for(ii in 1:length(mls_seasons)){
  passes <- mls_seasons[[ii]] %>% filter(event_type=="Pass") %>%
    select(c(competition_id,competition,season,game_id,fixture,home_team,home,away_team,
             away,event_id,event_type_id,event_type,period_id,period_min,period_second,
             outcome,team_id,team,player_id,player,x,y,pass_end_x,pass_end_y,length,angle,
             keeper_throw,goal_kick,gk_hoof,gk_kick_from_hands,player_position,
             team_formation,team_player_formation,formation_slot,fair_play,gk_start,
             kick_off,first_touch))
  
  passes$firstpass <- NA
  passes$prev_start_x <- NA
  passes$prev_start_y <- NA
  team <- passes$team[1]
  passes$firstpass[1] <- 1
  time1 <- proc.time()
  for(i in 2:dim(passes)[1]){
    
    if(passes$team[i]!=team){
      passes$firstpass[i] <- 1
      team <- passes$team[i]
    } else{ # if passes$team[i]==team
      passes$prev_start_x[i] <- passes$x[i-1]
      passes$prev_start_y[i] <- passes$y[i-1]
      passes$firstpass[i] <- 0
    }
    
    if(i %in% seq(1,dim(passes)[1],5000)){
      print(paste0("Observation ",i))
      print(paste0(100*round(i/dim(passes)[1],digits = 3),"% complete"))
      print(paste0(round(((proc.time() - time1)[3])/60,digits = 3)," minutes from start"))
      print(" ")
    }
    
  }
  
  final_pass <- passes %>% filter(firstpass==0)
  write.csv(final_pass,paste0('mls1',ii,'.csv'),row.names = F)

  
}

# current pass x/y, next pass x/y, previous pass x/y
