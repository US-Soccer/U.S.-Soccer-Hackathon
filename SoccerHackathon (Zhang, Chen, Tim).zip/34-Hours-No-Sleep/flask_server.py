from flask import Flask,render_template,json,request,g
from flask_cors import CORS, cross_origin

import numpy as np
import pandas as pd
import sqlite3
from numpy import sort

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
#import matplotlib.pyplot as plt
import tensorflow as tf
import warnings
import csv
import copy
import json
import nltk
import os
import re
import codecs
import time
from sklearn.datasets import fetch_mldata
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.model_selection import cross_val_predict
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from tensorflow.examples.tutorials.mnist import input_data
from time import gmtime, strftime
from datetime import datetime
from sklearn.datasets import make_classification, load_iris
from sklearn.preprocessing import LabelBinarizer
from sklearn.linear_model import LogisticRegression #for comparison
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.utils import check_random_state
from sklearn.utils import shuffle
from sklearn.externals import joblib

from xgboost import XGBClassifier
######################################Import Database and Assign Variable of Application#############################################
database = './source/db/team_country.sqlite'
app = Flask(__name__)


###############################################calcualte prepare###############################################
"""
In the output dictionary, match will contains the following attributes as ordered: 
    [0: home(Home true away false), 1: avg_rate(fifa 18 rate avg), 2: avg_age(fifa 18 age avg), 3: pre5gameWin(count for win),
     4: pre5gamesAvgRateDiff(Difference on avg rate), 5: pre5gamesAvgAgeDiff(Difference on avg age), 6: pre5gameHome(Count for home),
     7: RestDays, 8: Score(class)]
"""
getLast = {}

with open ('2nd_Output.json', encoding="utf-8", errors = "ignore") as f:

    temp_dict = json.load(f)
    for key, value in temp_dict.items():
        if key in getLast:
        	getLast[key].extend(value)
        else:
            getLast[key] = []
    #print(temp_dict)

cf = pd.read_csv('LR_Input.csv', header=None, delimiter=',')
# Scatching data from csv file
X = cf.loc[:, 0:7].values
#X = cf.loc[:, 1:5].values
Y = cf.loc[:, 8].values
sc = StandardScaler()
sc.fit(X)
filename = 'finalized_model_8features_knn.sav'
loaded_model = joblib.load(filename)

#############################################Cross Domain############################################
CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
#############################################Request function################################################
@app.route('/')
def signUp():
    return render_template('index.html')

@app.route('/sendjson', methods=['GET', 'POST'])
@cross_origin()
def sendjson():
    data = json.loads(request.form.get('data'))
    team = data['team']
    print(team)
    #result = calculate().tolist()

    #print(result[0])
    #return json.dumps({'team':team,'wins':result[0][0],'loses':result[0][1],'draws':result[0][2]});
    return json.dumps({'team':team,'wins':'0.1','loses':'0.1','draws':'0.1'});

@app.route('/getFeatureImportance', methods=['GET', 'POST'])
@cross_origin()
def getFeatureImportance():
    data = json.loads(request.form.get('data'))
    #team = data['team']
    #result = calculate().tolist()
    generateFeatureDictionary()
    x,y = calFeatureImportance()
    #print()
    #print(result[0])
    #return json.dumps({'team':team,'wins':result[0][0],'loses':result[0][1],'draws':result[0][2]});
    column_name = ['avg_rate(fifa 18 rate avg)', 'pre5gamesAvgAgeDiff(Difference on avg age)', 
    'pre5gamesAvgRateDiff(Difference on avg rate)', 'pre5gameWin(count for win)',
     'avg_age(fifa 18 age avg)', 'RestDays', 'pre5gameHome(Count for home)', 'home(Home true away false)']
    column_value= [0.20199895,0.18884797,0.14466071,0.13150974,0.12309311,0.12204103,0.0473435,0.040505  ]
    return json.dumps({'name':column_name,'value':column_value})

@app.route('/getData', methods=['GET', 'POST'])
@cross_origin()
def getData():
    data = json.loads(request.form.get('data'))
	# expectdata represents the user expect data, like country, team name.
    expectdata = data['expectdata']
    table = data['table']
    result = query_db('select DISTINCT '+ expectdata + ' from '+ table)
    teams = result[expectdata].unique()
    #close_connection()
    return json.dumps(teams.tolist())

#####################################################################################################
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(database)
    print('Get DB success')
    return db

def query_db(query):
    df = pd.read_sql(query,get_db())
    return df
# Another approach to query 
"""
@app.route('/getData', methods=['GET', 'POST'])
@cross_origin()
def getData():
    data = json.loads(request.form.get('data'))
    expectdata = data['expectdata']
    result = query_db('select * from Team')
    teams = result[expectdata].unique()
    close_connection()
    return json.dumps(teams.tolist());
def query_db(query, args=(), one=False):
    df = pd.read_sql_query(query,get_db())
    return df
"""
def close_connection():
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()
        print('close db')


def generateFeatureDictionary():
   featuresRaw = pd.read_csv('./source/csv/opta definition trim.csv', header=None, delimiter=',')
   featuresDict = dict(zip(featuresRaw[0], featuresRaw[1]))
   print(featuresDict)

def calculate():
    Xtest = np.array([[0, 90.0, 25.0, 2, -3.0, -3.0, 4, 22]])

    Xtest = sc.transform(Xtest)

    result = loaded_model.predict(Xtest)
	
    if result==2:
    	print(str(3))
    else:
    	print(str(result))

    proba_result = loaded_model.predict_proba(Xtest)
    print(proba_result)
    return proba_result
    
def calFeatureImportance():
    """
    # split data into train and test sets
    seed = 7
    test_size = 0.33
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=test_size, random_state=seed)
    # fit model no training data
    model = XGBClassifier()
    model.fit(X_train, y_train)
    print(model)
    # make predictions for test data
    y_pred = model.predict(X_test)
    predictions = [round(value) for value in y_pred]
    # evaluate predictions
    accuracy = accuracy_score(y_test, predictions)

    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    """
    
    
    model = XGBClassifier()
    model.fit(X, Y)
    # feature importance
    keys = model.feature_importances_
    values = ['home(Home true away false)', 'avg_rate(fifa 18 rate avg)', 'avg_age(fifa 18 age avg)', 'pre5gameWin(count for win)',
     'pre5gamesAvgRateDiff(Difference on avg rate)', 'pre5gamesAvgAgeDiff(Difference on avg age)', 'pre5gameHome(Count for home)',
     'RestDays', 'Score(class)']
    dictionary = dict(zip(keys, values))
    newOrderKeys = sort(keys)[::-1]
    print(newOrderKeys)
    newOrderValues = [dictionary[x] for x in newOrderKeys]
    print(newOrderValues)
    return newOrderKeys,newOrderValues
    #data = -sort(-model.feature_importances_)
    #data = model.feature_importances_[::-1].sort()
    #data = model.feature_importances_
    #print(data)

    # plot
    #pyplot.bar(range(len(data)), data)
    #pyplot.show()
    #print(X)
#################################################################################################################
if __name__=="__main__":
    app.run(debug = True)

