#/bin/python

# Description: U.S Soccer Hackthon Chicago, this script is for load model and do the predicting purposes.
# Author: Liyuan Huang
# Date: 2018-07-06

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
import warnings
import csv
import copy
import json
import nltk
import os
import re
import codecs
import time
from sklearn.datasets import fetch_mldata
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.model_selection import cross_val_predict
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from tensorflow.examples.tutorials.mnist import input_data
from time import gmtime, strftime
from datetime import datetime
from sklearn.datasets import make_classification, load_iris
from sklearn.preprocessing import LabelBinarizer
from sklearn.linear_model import LogisticRegression #for comparison
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.utils import check_random_state
from sklearn.utils import shuffle
from sklearn.externals import joblib

cf = pd.read_csv('LR_Input.csv', header=None, delimiter=',')

# Scatching data from csv file
X = cf.loc[:, 0:7].values
#X = cf.loc[:, 1:5].values
Y = cf.loc[:, 8].values

sc = StandardScaler()
sc.fit(X)
#
filename = 'finalized_model_8features_knn.sav'

loaded_model = joblib.load(filename)

Xtest = np.array([0, 90.0, 25.0, 2, -3.0, -3.0, 4, 22])

Xtest = sc.transform(Xtest)

result = loaded_model.predict(Xtest)
if result==2:
	print(str(3))
else:
	print(str(result))

proba_result = loaded_model.predict_proba(Xtest)
print(proba_result)