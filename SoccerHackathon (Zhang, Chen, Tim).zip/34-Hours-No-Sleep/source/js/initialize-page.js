$( document ).ready(function() {
	initialSelectBox('#inputHome','name','team');
    initialSelectBox('#inputAway','name','team');
    //document.getElementById("#inputAway").value = "1";
    //initialSelectBox('#inputLeague','League','League');
    $('#inputLeague').change(function(){
        var selected = document.getElementById("inputLeague");	
        var Val = selected.options[selected.selectedIndex].value;
        if(Val == 'MLS'){
            initialSelectBox('#inputHome','name','team');
            initialSelectBox('#inputAway','name','team');
        }else{
            initialSelectBox('#inputHome','name','country');
            initialSelectBox('#inputAway','name','country');
        }
        
    });  
    $('#inputAway').change(function(){
        var selected = document.getElementById('inputAway');	
        var Val = selected.options[selected.selectedIndex].value;
        console.log(Val);
        // var x = document.getElementById("mySelect").selectedIndex;
        // var y = document.getElementById("mySelect").options;
        // console.log("Index: " + y[x].index + " is " + y[x].text);
        
    });   
});

function initialSelectBox(selectBoxName,expectdata,table){
	var dataVal = {
         data: JSON.stringify({'expectdata': expectdata,'table':table})
    }
    $.ajax({
            url: 'http://127.0.0.1:5000/getData',
            data: dataVal,
            type: 'POST',
            dataType: 'text json',
            success: function(response){
				addOptions(selectBoxName,response);
            },
            error: function(error){
                console.log(error);
            }
        });	
}

function addOptions(select_id,options){
	$(select_id).empty();
	$.each(options, function(key, value) {
    $(select_id)
        .append($("<option></option>")
        .attr("value",value)
        .text(value));
    });

}