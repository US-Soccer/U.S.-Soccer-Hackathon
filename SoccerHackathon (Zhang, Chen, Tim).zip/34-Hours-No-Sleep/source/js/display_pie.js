function displayPie(){
	result = arguments[0];
	var config = {
		type: 'pie',
		data: {
			datasets: [{
				data: [
					result.wins,
					result.loses,
					result.draws,
				],
				backgroundColor: [
					window.chartColors.red,
					window.chartColors.yellow,
					window.chartColors.blue,
				],
				label: 'Dataset 1'
			}],
			labels: [
				'Win',
				'Lose',
				'Tie'
			]
		},
		options: {
			responsive: true
		}
	};
	var ctx = document.getElementById('chart-area').getContext('2d');
	chart = new Chart(ctx, config);
	chart.render();
	$('#returnResult').val(JSON.stringify(result));
}