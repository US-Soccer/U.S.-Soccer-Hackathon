function displayBar(){
        var color = Chart.helpers.color;
        console.log(arguments[0].name);
        console.log(arguments[0].value);
		var barChartData = {
            labels: arguments[0].name,
            //labels:['test'],
			datasets: [{
				label: '',
				backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
				borderColor: window.chartColors.red,
				borderWidth: 1,
                data: arguments[0].value
                //data: [2]
			}]

		};

	var ctx = document.getElementById('canvas').getContext('2d');
    myBar = new Chart(ctx, {
        type: 'bar',
        data: barChartData,
        options: {
            responsive: true,
            legend: {
                display:false,
            },
            title: {
                display: true,
                text: 'Factor_RANK'
            },
            scaleShowValues: true,
            scales: {
                yAxes: [{
                ticks: {
                beginAtZero: true
                }
                }],
                xAxes: [{
                ticks: {
                mirior: true
                }
                }]
            }
        }
    });
    myBar.render();
}