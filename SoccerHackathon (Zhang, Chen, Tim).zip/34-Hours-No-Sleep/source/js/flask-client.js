$(function(){
    $('#predict-button').click(function(){
        var selectedHome = document.getElementById("inputHome");	
        var selected = document.getElementById("inputAway");	
        
        if(selectedHome.options[selectedHome.selectedIndex].value == selected.options[selected.selectedIndex].value){
            alert("Please select different two teams.");
            return;
        }  
        var selectedteam = document.getElementById("inputHome");	
        var teamVal = selectedteam.options[selectedteam.selectedIndex].value;
        var dataVal = {
                    data: JSON.stringify({'team': teamVal})
            }
        $.ajax({
            url: 'http://127.0.0.1:5000/sendjson',
            data: dataVal,
            type: 'POST',
            dataType: 'text json',
            success: function(response){
                displayPie(response);
            },
            error: function(error){
                console.log(error);
            }
        });
        var dataVal = {
            data: JSON.stringify({'team': teamVal})
    }
        $.ajax({
            url: 'http://127.0.0.1:5000/getFeatureImportance',
            data: dataVal,
            type: 'POST',
            dataType: 'text json',
            success: function(response){
                displayBar(response);
            },
            error: function(error){
                console.log(error);
            }
        });
    });
    

});

