#/bin/python

# Team: ()
# Project Name: Team Performance and Play Style Analysis
# Date: 7/15/2018
# Description: This script is for further processing output file from player2team.py. We will calculate the current days influence features included 
# average team lineup rate, average team lineup age, home or away, rest days, etc. At the same time, we will calculate the influence feature from 
# previous 5 days, include 5 game win count, 5 game home count, average rate difference, average age difference.

import csv
import copy
import json
import nltk
import os
import re
import codecs
import time
from time import gmtime, strftime
from datetime import datetime

# file for us soccer international data
USInter = "USMNT_Matches.json"

# file for world cup data
WC = "WC_Matches.json"

# files directory for mls data
MLS = "MLS/"

#############################################
## Main()

team_match = {}

# Dictionary storing new generated features
new_dict = {}

# for us soccer international data
with codecs.open(USInter, "r", encoding="utf-8", errors = "ignore") as f:
	temp_dict = json.load(f)

	for key, value in temp_dict.items():
		if key in team_match:
			team_match[key].extend(value)
		else:
			team_match[key] = []

with codecs.open(WC, "r", encoding="utf-8", errors = "ignore") as f:
	temp_dict = json.load(f)

	for key, value in temp_dict.items():
		if key in team_match:
			team_match[key].extend(value)
		else:
			team_match[key] = []
"""
for filename in os.listdir(MLS):
	if filename.endswith(".json"): 
		with codecs.open("{}{}".format(MLS, filename), "r", encoding="utf-8", errors = "ignore") as f:
			temp_dict.loads(f)

			for key, value in temp_dict.items():
				if key in team_match:
					team_match[key].extend(value)
				else:
					team_match = []
"""
# Sort the content in dictionary values content	on date, ascending on date
for key, value in team_match.items():
	team_match[key] = sorted(value, key=lambda l:l[1], reverse=False)



# The input file has the following data structure:
# 0: game_id 1: date 2: homeOraway 3:home_team_id 4: avg rating 5: avg age 6: home performances list 7: away_team_id 8: away avg rating
# 9: away avg age 10: away performance list 11: Final class

# What features we want on generated file:
# Current Day 0: rest date 1: homeOraway 2: self average rating 3:self average age 4: opposite average rating 5: opposite average age
# 6-83(#6) home last game performances 84(#7):Class(0:loss 1:draw 2: win)
for key, value in team_match.items():
	new_dict[key] = []

	last_date = ""
	last_77 = []
	last_restday = 0
	last_home = 0
	last_self_rating = 70
	last_self_age = 30
	last_oppo_rating = 70
	last_oppo_age = 30
	last_class = -1
	for i, match in enumerate(value):
		new_List = []
		if i==0:
			last_date = match[1]
			last_77 = match[6]
		else:
			#print(match[1][0: 11])
			datetime_object = datetime.strptime(match[1], '%Y-%m-%d %H:%M:%S')
			lastdatetime_object = datetime.strptime(last_date, '%Y-%m-%d %H:%M:%S')
			gap = datetime_object - lastdatetime_object
			print("{} - {}".format(lastdatetime_object, datetime_object))
			new_List.append(gap.days) # Rest days
			new_List.append(match[2]) # home or away
			if match[4]: # self rating
				new_List.append(match[4])
			else:
				new_List.append(70)
			if match[5]: # self age
				new_List.append(match[5])
			else:
				new_List.append(30)
			if match[8]: # opposite rating
				new_List.append(match[8])
			else:
				new_List.append(70)
			if match[9]: # opposite age
				new_List.append(match[9])
			else:
				new_List.append(30)
			new_List.append(last_77) # performance matrix
			new_List.append(match[-1]) # class
			last_date = match[1]
			last_77 = match[6]
			new_dict[key].append(new_List)
	new_List = [last_restday, last_home, last_self_rating, last_self_age, last_oppo_rating, last_oppo_age, last_77, last_class, last_date] # additional 1 parameter, date, use for predict today result
	new_dict[key].append(new_List)

with codecs.open("2nd_Output.json", 'w+') as f:
	json.dump(new_dict, f, indent=2)

with codecs.open("Model_input.csv", 'a+') as file:
	for key, value in new_dict.items():
		for List in value:
			if len(List)==8:
				#print(List[:6])
				temp_List = List[:6]
				for i in List[6]:
					temp_List.append(i)
				temp_List.append(List[7])
				temp_List = [str(x) for x in temp_List]
				file.write(','.join(temp_List)+ "\n")











