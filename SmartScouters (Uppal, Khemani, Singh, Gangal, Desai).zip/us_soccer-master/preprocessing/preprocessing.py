from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import Normalizer
import numpy as np
import pandas as pd

class Preprocess:

	def load_data(self,filepath):
		df = pd.read_csv(filepath,encoding= 'latin-1')
		return df

	def preprocess(self):
		print("preprocess data")
		df = df.fillna(df.median())
		df = df.dropna(axis='columns')
		norm = Normalizer()
		df = norm.fit_transform(df)
		return(df)

	def drop_categorical(self):
		print("dropping categorical values")
		df = df.drop(colummns=['player_name'], axis=1)
		return(df)

	def _init_(self):
		df = load_data(filepath)
		df_up = df.preprocess()
		df_up = df.drop_categorical()
		self.df_up = df_up




