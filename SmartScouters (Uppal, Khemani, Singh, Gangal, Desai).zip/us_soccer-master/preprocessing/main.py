import preprocessing as pr

def main():
	x = pr.Preprocess()
	print(x.df_up)