
# coding: utf-8

# In[136]:


import pandas as pd


# In[137]:


import numpy as np
from sklearn.feature_selection import RFE
from sklearn.svm import SVR
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.datasets import load_iris
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import OneHotEncoder


# In[3]:


# fifa18 = pd.read_csv("/Users/kislayasingh/Documents/Hackathon/Hackathon_Raw_Files/FIFA_18_Ratings.csv", sep=",")


# In[5]:


df = fifa18


# In[6]:


df1=df.drop(df.columns[[1, 2, -1, -2, -3]], axis=1)


# In[7]:


df1


# In[8]:


def parseValue(strVal):
    print(strVal)
    if 'M' in strVal:
        return int(float(strVal.replace('M', '')) * 1000000)
    elif 'K' in strVal:
        return int(float(strVal.replace('K', '')) * 1000)
    elif "'" in strVal:
        return int(float(strVal.replace("'", "")))
    elif "cm" in strVal:
        return int(float(strVal.replace("cm", "")))
    elif "kg" in strVal:
        return int(float(strVal.replace("kg", "")))
    else:
        return int(strVal)


# In[9]:


df1['Value (Euros)'] = df1['Value (Euros)'].str.replace('€', '')


# In[10]:


df1['Wage (Euros)'] = df1['Wage (Euros)'].apply(lambda x: parseValue(x))


# In[11]:


df1['Value (Euros)'] = df1['Value (Euros)'].apply(lambda x: parseValue(x))


# In[12]:


y = df1['Overall Rating']


# In[13]:


X = df1.drop('Overall Rating', 1)


# In[14]:


X = X.replace({"'": ''}, regex=True)


# In[15]:


X = pd.concat([X,pd.get_dummies(X['Current Team'],dummy_na=True)],axis=1).drop(['Current Team'],axis=1)


# In[16]:


X['Club Position'].unique()


# In[17]:


forward = ['RS', 'LW', 'LS', 'ST', 'RW', 'LF', 'RF', 'CF']
mid_fielder = ['RCM','LCM', 'LM', 'CDM','CAM','RDM','LDM','CM', 'LAM', 'RAM']
defender = ['LCB', 'LB', 'RB', 'RCB','CB','LWB', 'RWB']
goal_keeper = ['GK']


# In[18]:


dfX = X.copy(deep=True)


# In[19]:


def find_position_category(position_abb):
    if position_abb in forward:
        position_abb = 'f'        
    elif position_abb in defender:
        position_abb = 'd'
    elif position_abb in mid_fielder:
        position_abb = 'm'
    return position_abb


# In[20]:


dfX['Club_Position']=dfX['Club Position'].apply(find_position_category)


# In[21]:


dfX=dfX.drop(['Club Position'], axis=1)


# In[22]:


dfX = dfX.fillna(str(0))


# In[23]:


dfX = pd.concat([dfX,pd.get_dummies(dfX['Club_Position'],dummy_na=True)],axis=1).drop(['Club_Position'],axis=1)


# In[24]:


dfX=dfX.drop(['Name'], axis=1)


# In[25]:


pd.set_option('display.max_columns', None)


# In[26]:


dfX['Height'] = dfX['Height'].apply(lambda x: parseValue(x))


# In[27]:


dfX['Weight'] = dfX['Weight'].apply(lambda x: parseValue(x))


# In[59]:


new_x = dfX.values[0:10, :]


# In[60]:


new_y = y.values[0:10]


# In[61]:


from sklearn.linear_model import LogisticRegression


# In[62]:


# model = LogisticRegression()


# In[63]:


#estimator = SVR(kernel="linear")


# In[67]:


#selector = RFE(model, 10)


# In[104]:


model = ExtraTreesClassifier()


# In[105]:


rfe = model.fit(new_x, new_y)


# In[106]:


#rfe.n_features_


# In[114]:


np.argmax(rfe.feature_importances_)


# In[73]:


import collections, numpy


# In[117]:


dfX.columns


# In[74]:


collections.Counter(rfe.support_)


# In[103]:


#rfe.support_


# In[75]:


dfX.columns[0:8]


# In[77]:


import numpy as np


# In[78]:


np.where(rfe.support_==True)


# In[102]:


#dfX


# In[99]:


index = np.where(rfe.support_==True)[0]


# In[100]:


index = index.tolist()


# In[101]:


dfX.columns[index]


# In[119]:


# pu = pd.read_csv("/Users/kislayasingh/Documents/Hackathon/Hackathon_Raw_Files/player_update.csv")


# In[127]:


# pu = pu.drop(pu.columns[0], axis=1)

