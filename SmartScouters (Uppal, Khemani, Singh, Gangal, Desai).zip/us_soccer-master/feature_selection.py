
# coding: utf-8

# In[407]:


import pandas as pd
import numpy as np
from sklearn.feature_selection import RFE
from sklearn.svm import SVR
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.datasets import load_iris
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression


# In[378]:


df = pd.read_csv("/Users/kislayasingh/Documents/Hackathon/Hackathon_Raw_Files/us_soccer/final_merge.csv",
                sep=",")


# In[380]:


df1 = df.drop(['Club name'], 1)


# In[382]:


df1.fillna(df1.median(),inplace=True)


# In[383]:


df1.dropna(how='all', axis=1, inplace=True)


# In[385]:


y = df1['overall_rating']


# In[386]:


X = df1.drop('overall_rating', 1)


# In[389]:


new_X = X.select_dtypes(include=[np.number])


# In[391]:


new_X1 = new_X.values[0:999, :]


# In[392]:


new_y = y.values[0:999]


# In[395]:


model = LogisticRegression()


# In[396]:


selector = RFE(model, 20)


# In[397]:


rfe = selector.fit(new_X1, new_y)


# In[400]:


import collections, numpy


# In[401]:


collections.Counter(rfe.support_)


# In[402]:


temp = np.where(rfe.support_==True)


# In[404]:


index = temp[0].tolist()


# In[408]:


new_X.columns[index]

