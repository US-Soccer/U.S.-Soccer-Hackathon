import pandas as pd

def makePlayerWise(filename):
	df = pd.read_csv(filename+'.csv',low_memory=False);
	print('file=',filename);
	etcDF = df.groupby(['player'])[list(df)].median();
	print('etcDF');
	trdf = df.groupby(['player','event_type'])['game_id'].count().reset_index(name='count');
	print('trdf');
	newDF = pd.DataFrame(columns=['player_name'])
	tempDF = pd.DataFrame()
	i=0
	print('entering for loop');
	for name in trdf['player'].unique():
		aDict = {};
		aDict['player_name'] = name;
		print('name=',name);
		for et in trdf['event_type'].unique():
			aDict[et] = 0;
			if et in trdf.loc[(trdf['player']==name)]['event_type'].values:
				aDict[et] = trdf.loc[(trdf['player']==name) & (trdf['event_type']==et)]['count'].values[0]
		for col in list(etcDF):
			aDict[col] = etcDF[col][i];
		newDF = newDF.append(pd.DataFrame(aDict,index=[i]));
		i=i+1;
	newDF.to_csv(filename+'_reduced.csv',index=False)
	
fileList=[];
fileList.append('MLS 2011-2012');
fileList.append('MLS 2012-2013');
fileList.append('MLS 2013-2014');
fileList.append('MLS 2014-2015');
fileList.append('MLS 2015-2016');
fileList.append('MLS 2016-2017');
fileList.append('MLS 2017-2018');
fileList.append('MLS 2018-2019');

for file in fileList:
	print('Reducing file: ',file);
	makePlayerWise(file);
	
num = 2011
str1 = str(num) + "-" + str(num+1)
df_1 = pd.read_csv("drive/us_soccer_hack/MLS "+str1+"_reduced.csv", encoding='latin-1')
df_comb = df_1
for num in range(2012,2016):
  str2 = str(num) + "-" + str(num+1)
  df_2 = pd.read_csv("drive/us_soccer_hack/MLS "+str2+"_reduced.csv", encoding='latin-1')
  df_comb = df_comb.append(df_2) 

df_final = df_comb.groupby('player_name', as_index=False).mean()
df_final.to_csv("drive/us_soccer_hack/MLS_playerwise_2017.csv", index=False)
