## Hackathon Code

library(dplyr)
library(tidyverse)
# Fifa18
datapath <- "/Users/hannahwishart/Desktop/Hackathon Raw Files"
fifa18 <- read.csv(file=paste(datapath,"FIFA 18 Ratings.csv",sep="/"))

positions <- as.vector(unique(fifa18$Club.Position))
positions
defenders <- positions[c(9,13,14,18,20,25,30)]
defenders

# FIFA Defensive Player Ranking variables
def_fifa <-
  fifa18 %>%
  filter(Club.Position %in% defenders) %>%
  distinct(Club.Position, Overall.Rating, Age,
           Crossing, Finishing, Heading.Accuracy, Short.Passing, Volleys, Dribbling, Curve, Free.Kick.Accuracy, Long.Passing, Ball.Control, Acceleration,
           Sprint.Speed, Agility, Reactions, Balance, Shot.Power, Jumping, Stamina, Strength, Long.Shots, Aggression, Interceptions, Positioning, Vision,
           Penalties, Composure, Marking, Standing.Tackle, Sliding.Tackle, GK.Diving, GK.Handling, GK.Kicking, GK.Positioning, GK.Reflexes, Weak.Foot.Rating,
           Skill.Moves) 

instanceconvert <- colnames(def_fifa[4:39])

for (i in instanceconvert){
  def_fifa[,i] <- as.numeric(def_fifa[,i])
}

# PCA of FIFA Defensive Player Ranking variables
def_fifa_PCA <- princomp(~Age + Crossing + Finishing + Heading.Accuracy + Short.Passing + Volleys + Dribbling + Curve + Free.Kick.Accuracy + 
                           Long.Passing + Ball.Control + Acceleration + Sprint.Speed + Agility + Reactions + Balance + Shot.Power + Jumping + Stamina +
                           Strength + Long.Shots + Aggression + Interceptions + Positioning + Vision + Penalties + Composure + Marking + Standing.Tackle +
                           Sliding.Tackle + GK.Diving + GK.Handling + GK.Kicking + GK.Positioning + GK.Reflexes + Weak.Foot.Rating + Skill.Moves
                         , data = def_fifa)
def_fifa_PCA

VAF <- cumsum(def_fifa_PCA$sdev^2/sum(def_fifa_PCA$sdev^2))
plot(VAF, type = "b", xlab = "Number of Components", ylab = "VAF")
VAF

# Keep 3 components
retained.loadings <- def_fifa_PCA$loadings[,1:3]
sort(abs(def_fifa_PCA$loadings[,1]))
sort(abs(def_fifa_PCA$loadings[,2]))
sort(abs(def_fifa_PCA$loadings[,3]))

# World Cup Data
atapath2<- "/Users/hannahwishart/Desktop/Hackathon Raw Files/Full Datasets - Opta/WC"
World.Cup <- read.csv(file=paste(datapath2,"World Cup.csv",sep="/"))
names(World.Cup)

wc <- World.Cup

# Using the three PCAs, we found variables in the World Cup data that would display the defensive characteristics we're looking for
full_df <- as.data.frame(
  wc %>%
    mutate(group = ceiling((period_min+1)/3), 
           sub = case_when(event_type == 'Player Off' ~ 1, TRUE ~ 0),
           tackle =case_when(event_type == 'Tackle' ~ 1, TRUE ~ 0),
           interception = case_when(event_type == "Interception" ~ 1, TRUE ~ 0),
           clearance = case_when(event_type == "Clearance" ~ 1, TRUE ~ 0),
           good_skill = case_when(event_type == 'Good Skill' ~ 1, TRUE ~ 0),
           off_side_provoked = case_when(event_type == 'Offside provoked' ~ 1, TRUE ~ 0),
           shield = case_when(event_type == 'Shield ball opp' ~ 1, TRUE ~ 0)) %>%
    select(fixture, game_id, team, group, sub,
           cross, long_ball, good_skill, blocked_cross, off_side_provoked, clearance,
           head_pass, last_line, shield,
           tackle, interception, free_kick, out_of_play) %>%
    replace(is.na(.),0) %>%
    group_by(fixture, game_id, team, group) %>%
    summarise_all(funs(sum)) %>%
    arrange(fixture, game_id, group)
)
head(full_df)

df <- as.data.frame(
  full_df %>%
    group_by(fixture, game_id, team, group, sub) %>%
    transmute(tactical_skill = sum(cross, long_ball, good_skill, blocked_cross, off_side_provoked, clearance),
              athletic_skill = sum(head_pass, last_line, shield),
              aggressive_play = sum(tackle, interception, free_kick, out_of_play))
)

# World Cup match results
results <- as.data.frame(
  wc %>%
    select(game_id, fixture, event_type, team) %>%
    mutate(goals = case_when(event_type == 'Goal' ~ 1, TRUE ~ 0)) %>%
    group_by(game_id, fixture, team) %>%
    summarise(total_goals = sum(goals))
)

results <- as.data.frame(
  results %>%
    group_by(game_id) %>%
    arrange(game_id, fixture, total_goals) %>%
    mutate(diff = total_goals - lag(total_goals)) %>%
    na.omit() %>%
    filter(diff != 0)
)
head(results)

win_df <- merge(results, df, by = c('game_id'), all = TRUE)
str(win_df)

temp <- as.data.frame(
  win_df %>%
    mutate(win = case_when(as.character(team.x) == as.character(team.y) ~ 1, TRUE ~ 0)) %>%
    arrange(game_id, group, win) %>%
    select(game_id, fixture.x, win, group, tactical_skill, athletic_skill, aggressive_play)
)

write.csv(temp, paste(datapath2,"wins.csv",sep="/"))

# CSV above used for graphics in Tableau



















