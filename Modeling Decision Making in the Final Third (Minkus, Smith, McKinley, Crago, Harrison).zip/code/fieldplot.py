import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Arc

def fieldplot(x,y,filename):

    x1 = x[0,:]
    x2 = x[:,0]

    fig1, axes = plt.subplots(nrows=1,ncols=3)
    fig1.set_size_inches(10,8)
    i=0;

    for ax in axes:

        #Pitch Outline & Centre Line
        ax.plot([75,75],[0,80], color="black")
        ax.plot([75,115],[80,80], color="black")
        ax.plot([115,115],[80,0], color="black")
        ax.plot([115,75],[0,0], color="black")

        #Right Penalty Area
        ax.plot([115,97],[62,62],color="black")
        ax.plot([97,97],[62,18],color="black")
        ax.plot([97,115],[18,18],color="black")

        #Right 6-yard Box
        ax.plot([115,109],[50,50],color="black")
        ax.plot([109,109],[50,30],color="black")
        ax.plot([109,115],[30,30],color="black")

        #Prepare Circles
        rightPenSpot = plt.Circle((103,40),0.8,color="black")

        #Draw Circles
        ax.add_patch(rightPenSpot)

        ax.set_aspect('equal')

        #Prepare Arcs
        rightArc = Arc((103,40),height=18.3,width=18.3,angle=0,theta1=130,theta2=230,color="black")

        #Draw Arcs
        ax.add_patch(rightArc)
        ax.axis('off')

        fig = ax.contourf(x1,x2,y[i,:,:])
        plt.ylim(0, 80)
        plt.xlim(75, 115)

    fig1.colorbar(fig,ax=axes.ravel().tolist(),orientation='horizontal')
    plt.imsave(filename)
