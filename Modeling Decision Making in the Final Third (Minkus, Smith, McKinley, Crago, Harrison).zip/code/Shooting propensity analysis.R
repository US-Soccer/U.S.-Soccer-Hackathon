library(tidyverse)
library(lubridate)
source('createPitch.R')



all.mls=read.csv('./Raw Data/Possession Shot Propensity/MLS 2011-2012  posessions w propensity.csv')
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2012-2013  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2013-2014  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2014-2015  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2015-2016  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2016-2017  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2017-2018  posessions w propensity.csv'))
all.mls=rbind.data.frame(all.mls, read.csv('./Raw Data/Possession Shot Propensity/MLS 2018-2019  posessions w propensity.csv'))

save(all.mls, file='./Raw Data/Possession Shot Propensity/All mls propensities.Rdata')

 load('./Raw Data/Possession Shot Propensity/All mls propensities.Rdata')
 all.mls$data.set='MLS'
 all.nwsl=read.csv('./Raw Data/Possession Shot Propensity/NWSL  posessions w propensity.csv')
 all.nwsl$data.set='NWSL'
 all.usmnt=read.csv('./Raw Data/Possession Shot Propensity/USMNT  posessions w propensity.csv')
 all.usmnt$data.set='USMNT'
 all.uswnt=read.csv('./Raw Data/Possession Shot Propensity/USWNT  posessions w propensity.csv')
 all.uswnt$data.set='USWNT'
 all.WWC=read.csv('./Raw Data/Possession Shot Propensity/Womens World Cup  posessions w propensity.csv')
 all.WWC$data.set='WWC'
 all.MWC=read.csv('./Raw Data/Possession Shot Propensity/World Cup  posessions w propensity.csv')
 all.MWC$data.set='MWC'

all.poss=rbind.data.frame(all.mls, all.nwsl, all.usmnt, all.uswnt, all.WWC, all.MWC)
save(all.poss, file='./Raw Data/Possession Shot Propensity/All data propensities.Rdata')

load('./Raw Data/Possession Shot Propensity/All data propensities.Rdata')

all.poss$date=as.POSIXct(all.poss$game_date)


createPitch(data=all.poss %>% sample_n(10000), halfPitch = T)+geom_point(aes(x=end.x, y=end.y, color=shot_pr_score))


labs <- paste("Result of Posession:", c("Shot", "No shot"))
all.poss %>%
  mutate(shot = ifelse(final.action.shot == 1, labs[1], labs[2])) %>%
  ggplot(aes(x = shot_pr_score)) +
  geom_histogram(color = "white") +
  facet_wrap(~shot) +
  xlab("Posession shot propensity") +
  theme_bw()+
  labs(y='Number of Posessions', caption=paste0('N=', nrow(all.poss)))

labs <- paste("Result of Posession:", c("Shot", "No shot"))

  ggplot(all.poss, aes(x = end.distance, group=final.action.shot, fill=final.action.shot)) +
  geom_density(alpha=0.5) +
  #facet_wrap(~shot) +
  xlab('Distance from goal at end of posession') +

  labs(y='Number of Posessions', caption=paste0('N=', nrow(all.poss)))

  
  ggplot(all.poss, aes(x = shot_pr_score, group=final.action.shot, fill=final.action.shot)) +
    geom_density(alpha=0.5) +
    #facet_wrap(~shot) +
    xlab("Posession shot propensity") +
    geom_vline(xintercept = 0.5, linetype='dashed')+
    theme_bw()+
  labs(y='Posession Density', caption=paste0('N=', nrow(all.poss)))
  
  

ggplot(all.poss, aes(x=end.distance, y=shot_pr_score))+geom_point(alpha=0.02)+
  geom_smooth(se=FALSE)+
  theme_bw()+
  labs(x='Distance from goal at end of posession', y='Shot Propensity', 
       title='Shots in MLS PLay 2011-2018')

ggplot(all.nwsl, aes(x=end.distance, y=shot_pr_score))+geom_point(alpha=0.1)+
  geom_smooth(se=FALSE)+
  theme_bw()+
  labs(x='Distance from goal at end of posession', y='Shot Propensity', title='Shots in NWSL PLay 2017-2018')



ggplot(all.poss%>% filter(data.set=='MLS' & period<3), aes(x=time, y=shot_pr_score))+geom_point(alpha=0.1, color="red")+
  geom_smooth()+
  theme_bw()+
  labs(x='Game time (s)', y='Shot Propensity', title='Shots in NWSL PLay 2017-2018')



ggplot(all.poss, aes(x=end.distance, y=shot_pr_score, color=data.set))+geom_smooth()

ggplot(all.poss, aes(x=start.distance, y=shot_pr_score, color=data.set))+geom_smooth()+
  scale_color_brewer(palette="Set1")


team.poss.shots=all.poss%>%
  filter(data.set=='MLS')%>%
  group_by(team)%>%
  summarise(N=n(),
            shots=sum(final.action.shot),
            total.shot.prop=sum(shot_pr_score),
            shots.prop=shots-total.shot.prop)


player.poss.shots=all.poss%>%
  filter(data.set=='MLS' & date > as.Date('2011-01-01'))%>%
  group_by(season, team)%>%
  summarise(N=n(),
            games=length(unique(game_id)),
            shots=sum(final.action.shot),
            xShot=sum(shot_pr_score),
            shots.xShots=shots-xShot,
            shots.game=shots/games,
            xShot.game=xShot/games,
            shot.xShot.game=shots.game-xShot.game)%>%
  filter(N>50)%>%
  arrange(desc(shot.xShot.game))

top.bottom=rbind.data.frame(head(player.poss.shots,10), tail(player.poss.shots,10))
top.bottom$player=factor(top.bottom$player, levels=reorder(top.bottom$player, top.bottom$shot.xShot.game))
                         
                         

ggplot(top.bottom)+geom_bar(aes(x=player, y=shot.xShot.game), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  labs(x="", y="Shots - xShots per game")




MLS.player.poss.shots=all.poss%>%
  filter(data.set=='MLS' & player!= "" & date > as.Date('2018-01-01'))%>% # & date<as.Date('2018-01-01'))%>%
  #mutate(after.azteca= date> as.Date('2017-06-08'))%>%
  group_by(player)%>%
  summarise(N=n(),
            distance=mean(end.distance),
            shot.distance=mean(end.distance[final.action.shot==1]),
            games=length(unique(game_id)),
            shots=sum(final.action.shot),
            xShot=sum(shot_pr_score),
            shots.xShots=shots-xShot,
            shots.game=shots/games,
            xShot.game=xShot/games,
            shot.xShot.game=shots.game-xShot.game,
            goals=sum(final.action.name=='Goal'),
            xG.poss=sum(xG_pr_score),
            goals.xG.poss=goals-xG.poss)%>%
  filter(N>50)%>%
  arrange(desc(shot.xShot.game))

write.csv(MLS.player.poss.shots, 'xShot xGPoss 2018 MLS.csv', row.names=F)

ggplot(MLS.player.poss.shots, aes(x=shot.distance, y=shot.xShot.game))+  geom_point()+
  geom_smooth(method='lm')

cor(MLS.player.poss.shots$shot.distance,MLS.player.poss.shots$shot.xShot.game)

top.bottom=rbind.data.frame(head(MLS.player.poss.shots,10), tail(MLS.player.poss.shots,10))
top.bottom$player=factor(top.bottom$player, levels=reorder(top.bottom$player, top.bottom$shot.xShot.game))

p=ggplot(top.bottom)+geom_bar(aes(x=player, y=shot.xShot.game), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=60, hjust=1))+
  labs(x="", y="Shots - xShots per game", 
       title='Top and Bottom 10: MLS 2018')

ggsave(plot=p, filename='MLS shot-xShot per game.png')

MLS.player.poss.shots=  MLS.player.poss.shots%>%
  arrange(goals.xG.poss)

top.bottom=rbind.data.frame(head(MLS.player.poss.shots,10), tail(MLS.player.poss.shots,10))
top.bottom$player=factor(top.bottom$player, levels=reorder(top.bottom$player, top.bottom$goals.xG.poss))

p=ggplot(top.bottom)+geom_bar(aes(x=player, y=goals.xG.poss), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  labs(x="", y="Goals - xGPoss", 
       title='Top and Bottom 10: MLS 2018')

ggsave(plot=p, filename='MLS goals - xGPoss.png')


p=ggplot(MLS.player.poss.shots%>%filter(player=='Michael Bradley'))+geom_bar(aes(x=after.azteca, y=shot.xShot.game), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  labs(x="After Azteca Goal in MLS play", y="Shots - xShots per game", 
       title='Michael Bradley 2017 MLS')

ggsave(plot=p, filename='Michael Bradley xS Azteca.png')


ggplot(top.bottom)+geom_bar(aes(x=player, y=shot.xShot.game), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  labs(x="", y="Shots - xShots per game")

NWSL.player.poss.shots=all.poss%>%
  filter(data.set=='NWSL' & date > as.Date('2011-01-01'))%>%
  group_by(player)%>%
  summarise(N=n(),
            distance=mean(end.distance),
            shot.distance=mean(end.distance[final.action.shot==1]),
            games=length(unique(game_id)),
            shots=sum(final.action.shot),
            xShot=sum(shot_pr_score),
            shots.xShots=shots-xShot,
            shots.game=shots/games,
            xShot.game=xShot/games,
            shot.xShot.game=shots.game-xShot.game)%>%
  filter(N>50)%>%
  arrange(desc(shot.xShot.game))


USWNT.player.poss.shots=all.poss%>%
  filter(data.set=='USWNT' & player!= "")%>%
  #mutate(after.azteca= date> as.Date('2017-06-08'))%>%
  group_by(player)%>%
  summarise(N=n(),
            distance=mean(end.distance),
            shot.distance=mean(end.distance[final.action.shot==1]),
            games=length(unique(game_id)),
            shots=sum(final.action.shot),
            xShot=sum(shot_pr_score),
            shots.xShots=shots-xShot,
            shots.game=shots/games,
            xShot.game=xShot/games,
            shot.xShot.game=shots.game-xShot.game)%>%
  filter(N>50)%>%
  arrange(desc(shot.xShot.game))

write.csv(USWNT.player.poss.shots, 'xShot xG USWNT.csv', row.name=T)
