# PossParse.py - tool generates unique possession identifiers for events in an OPTA-formatted data file
# outputs a single-column .csv with possession IDs

import csv

file_to_read = 'MLS 2018-2019 trimmed'
file_to_write = file_to_read + "possID" + ".csv"
ignoreEvents = ['27','28','18','19','20',
                '21','30','34','36','40',
                '68','24','65','22','23',
                '25','17','43','55'] #unrelated to possession
outfile = open(file_to_write,'w',newline='')
posswriter = csv.writer(outfile) # modified csv with possession numbers
with open(file_to_read + ".csv","rt",encoding="utf-8") as infile:
    reader = csv.reader(infile)
    ColNames = next(reader) # header
    posswriter.writerow(['PossID'])
    StatFilter = []     # empty list of indices for stats of interest
    PossID = []         # event list of possession IDs for each event
    PossCount = 1       # possession identifier
    actiontype = ''     # initialized variable for action type
    actionresult = ''   # initialized variable for action outcome
    PossEnd = [
               (1,0),   # unsuccessful pass
               (2,1),   # offside pass
               (61,0),  # unsuccessful touch
               (50,1),  # dispossessed
               (13,1),  # shot missed
               (14,1),  # post
               (15,1),  # save
               (16,1),  # goal
               (3,0),   # take on
               (4,0),   # foul
               (30,1)   # time end
               ]
    for i,j in enumerate(ColNames):
        if j in ['event_type_id','outcome']:
            StatFilter.append(i)
    for row in reader:      # iterate row by row over file
        actiontype = row[StatFilter[0]]
        actionresult = row[StatFilter[1]]
        PossID.append(PossCount)        # possession continues...
        if actiontype in ignoreEvents:
            posswriter.writerow(['NA']) # event unrelated to possession
        else:
            posswriter.writerow([str(PossCount)])
        if (int(actiontype),int(actionresult)) in PossEnd:  # ...until possession ends
            PossCount = PossCount + 1
outfile.close()

