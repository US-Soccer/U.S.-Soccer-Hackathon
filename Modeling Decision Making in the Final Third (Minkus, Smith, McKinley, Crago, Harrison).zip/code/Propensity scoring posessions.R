#Eliot McKinley 07-14-18

#Propensity scoring of posession data
library(tidyverse)
library(MatchIt)
library(flexclust)
library(class)

xmax=115
ymax=80

source('createPitch.R')

#Get data

#event.data=readRDS('./Raw Data/Data w xG/USMNT trimmed x xG.rds')

data.temp=readRDS('./Raw Data/Data w xG/MLS 2011-2012 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2011-2012 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)

event.data=data.temp

data.temp=readRDS('./Raw Data/Data w xG/MLS 2012-2013 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2012-2013 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)
event.data=rbind.data.frame(event.data, data.temp)

data.temp=readRDS('./Raw Data/Data w xG/MLS 2013-2014 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2013-2014 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)
event.data=rbind.data.frame(event.data, data.temp)

#event.data=readRDS('./Raw Data/Data w xG/MLS 2016-2017 trimmed x xG.rds')


#possessions=read.csv('./Raw Data/PossIDs/USMNTpossID.csv')
#possessions=read.csv('./Raw Data/PossIDs/MLS16_17possID.csv')
#event.data=data.frame(event.data, possessions)


# convert relative coordinates to absolute and convert game time to seconds
event.data=event.data%>%
  mutate(x.yard=x/100*xmax,
         y.yard=y/100*ymax,
         endX.yard=pass_end_x/100*xmax,
         endY.yard=pass_end_y/100*ymax,
         game.time=60*period_min+period_second)

event.data=event.data %>%
  filter( !event_type_id%in% c(70,32, 18, 19) )%>%
  group_by(PossID, game_id)%>%
  mutate(N=n(),
         poss_team=first(team))
  #ungroup()%>%
  #filter(team!=poss_team)
#possessions.test <- possessions.test[possessions.test$team==possessions.test$poss_team,]
event.data <- event.data[event.data$team==event.data$poss_team,]




  
#a=possessions.test[,c('team', 'poss_team', 'PossID')]
#b=event.data[,c('team', 'PossID')]


possessions.game=event.data %>%
  #filter(game_id==980425) %>%
  group_by(PossID, game_id,game_date,season, team) %>%
  filter(game_id==420390)%>%
  summarise(
            N=n(),
            start.distance=first(distance),
            end.distance=last(distance),
            #start.x=first(x),
            #start.y=first(y),
            #end.x=last(x),
            #end.y=last(y),
            #time=last(game.time)-first(game.time),
            velocity=(start.distance-end.distance)/(last(game.time)-first(game.time)),
            passes=sum(event_type=='Pass'),
            take.ons=sum(event_type=='Take on'),
            final.action=last(event_type_id),
            final.action.name=last(event_type),
            final.action.shot=ifelse(final.action %in% c(13:16),1,0),
            final.uid=last(uid),
            team.1=ifelse(as.character(first(team))!=as.character(first(home)), as.character(first(home)), as.character(first(away))),
            player=last(player),
            xG=sum(xG, na.rm=T))%>%
  filter(N>1 & is.finite(velocity) & end.distance<40)
  #select(-c(final.action, final.action.name))


# train on 50165 posessions
shot.glm.xG <- glm(xG ~ N+start.distance + end.distance+velocity+passes+take.ons,
            family = binomial(), data = possessions.game)
summary(shot.glm.xG)
save(shot.glm.xG, file='shot.glm.xG.Rdata')

shot.glm.shot <- glm(final.action.shot ~ N+start.distance + end.distance+velocity+passes+take.ons,
                family = binomial(), data = possessions.game)
summary(shot.glm.shot)
save(shot.glm.shot, file='shot.glm.shot.Rdata')


possessions.game$shot_pr_score=predict(shot.glm.shot, type = "response")
possessions.game$xG_pr_score=predict(shot.glm.xG, type = "response")

#possessions.game$shot=shot.glm$model$final.action.shot

labs <- paste("Result of Posession:", c("Shot", "No shot"))
possessions.game %>%
  mutate(shot = ifelse(final.action.shot == 1, labs[1], labs[2])) %>%
  ggplot(aes(x = shot_pr_score)) +
  geom_histogram(color = "white") +
  facet_wrap(~shot) +
  xlab("Probability of shot possession") +
  theme_bw()

labs <- paste("Result of Posession:", c("Shot", "No shot"))
possessions.game %>%
  mutate(shot = ifelse(final.action.shot == 1, labs[1], labs[2])) %>%
  ggplot(aes(x = xG_pr_score)) +
  geom_histogram(color = "white") +
  facet_wrap(~shot) +
  xlab("xG Probability") +
  theme_bw()





#possessions.game=possessions.game[complete.cases(possessions.game),]

match.poss=matchit(final.action.shot ~ start.distance + end.distance+velocity+passes+take.ons,
        method = "nearest", data = possessions.game)

summary(match.poss)
plot(match.poss)

matched.possessions=possessions.game[match.poss$weights,]

a=matched.possessions %>%
  group_by(final.action.shot) %>%
  #select(one_of(ecls_cov)) %>%
  summarise_all(funs(mean))

t.test(matched.possessions$velocity ~ matched.possessions$final.action.shot)

with(matched.possessions, t.test(velocity ~ final.action.shot))

possessions.game=na.omit(possessions.game)

matched.poss=match.data(match.poss)
  
  

a=sample_n(possessions.game, 10, replace=FALSE)

set.seed(42)
cl<-cclust(as.matrix(possessions.game[1:100,]), 60)

prc_test_pred <- knn(train = possessions.game[1:5000,], test = possessions.game[5001:10000,],cl = prc_train_labels, k=10)



matchit(catholic ~ race_white + w3income + p5hmage + p5numpla + w3momed_hsb,
        method = "nearest", data = ecls_nomiss)

possession.knn=knn

posessions.out=matchit(xG~ start.distance +end.distance+velocity+passes+take.ons+final.action, data=possessions.game, method = "nearest")

#m.out1 <- matchit(treat ~ age + educ + black + hispan + nodegree + married + re74 + re75, data = lalonde, method = “nearest”, distance = “logit”)

  
poss=subset(event.data, (game_id==980425 & PossID==115))
poss$num=1:nrow(poss)

createPitch(data=poss)+geom_segment(aes(x=x.yard, y=y.yard, xend=endX.yard, yend=endY.yard), arrow = arrow(length = unit(0.01, "npc")))+
  geom_point(aes(x=x.yard, y=y.yard, shape=event_type))+
  geom_text(aes(x=x.yard, y=y.yard, label=num), nudge_x =2, hjust=1, vjust=1)
