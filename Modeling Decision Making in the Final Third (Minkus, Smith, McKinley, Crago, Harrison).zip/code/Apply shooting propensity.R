#Eliot McKiney7/14/2018
# Apply shooting propensity model

load('shot.glm.xG.Rdata')
load('shot.glm.shot.Rdata')

xmax=115
ymax=80

folder.events='./Raw Data/Data w xG/'
folder.poss='./Raw Data/PossIDs/'

files.events=list.files(folder.events, pattern='.rds')
files.poss=list.files(folder.poss, pattern='possID.csv')

save.folder='./Raw Data/Possession Shot Propensity/'

for (i in 1:length(files.events)){
  print(files.events[i])
  
  event.data=readRDS(paste0(folder.events, files.events[i]))
  possession.data=read.csv(paste0(folder.poss, files.poss[i]))
  event.data=data.frame(event.data, possession.data)
  
  event.data=event.data%>%
    mutate(x.yard=x/100*xmax,
           y.yard=y/100*ymax,
           endX.yard=pass_end_x/100*xmax,
           endY.yard=pass_end_y/100*ymax,
           game.time=60*period_min+period_second)
  
  event.data=event.data %>%
    filter( !event_type_id%in% c(70,32, 18, 19) )%>%
    group_by(PossID, game_id)%>%
    mutate(N=n(),
           poss_team=first(team))
  #ungroup()%>%
  #filter(team!=poss_team)
  #possessions.test <- possessions.test[possessions.test$team==possessions.test$poss_team,]
  event.data <- event.data[event.data$team==event.data$poss_team,]
  
  
  
  
  
  #data.temp=read.csv('./Raw Data/Trimmed Columns - Opta/MLS/MLS 2011-2012 trimmed.csv')
  
  
  possessions.game=event.data %>%
    #filter(game_id==980425) %>%
    group_by(PossID, game_id,game_date,season, team) %>%
    #filter(game_id==420390)%>%
    summarise(
      N=n(),
      start.distance=first(distance),
      end.distance=last(distance),
      start.x=first(x.yard),
      start.y=first(y.yard),
      end.x=last(endX.yard),
      end.y=last(endY.yard),
      time=last(game.time)-first(game.time),
      velocity=(start.distance-end.distance)/(last(game.time)-first(game.time)),
      passes=sum(event_type=='Pass'),
      take.ons=sum(event_type=='Take on'),
      final.action=last(event_type_id),
      final.action.name=last(event_type),
      final.action.shot=ifelse(final.action %in% c(13:16),1,0),
      final.uid=last(uid),
      team.1=ifelse(as.character(first(team))!=as.character(first(home)), as.character(first(home)), as.character(first(away))),
      player=last(player),
      xG=sum(xG, na.rm=T),
      game.time=last(game.time),
      period=last(period_id)
      )%>%
    filter(N>1 & is.finite(velocity) & end.distance<40)
  
  possessions.game$shot_pr_score=predict(shot.glm.shot, possessions.game, type = "response")
  possessions.game$xG_pr_score=predict(shot.glm.xG, possessions.game, type = "response")
  

  filename=gsub('trimmedpossID.csv', ' posessions w propensity.csv', files.poss[i])
  
  write.csv(possessions.game, paste0(save.folder, filename ))
  #filenameRDS=gsub('.csv', '.rds', filename)
  #saveRDS(data.temp,paste0('./Raw Data/Data w xG/', filenameRDS ))
  #data.temp$xG=predict(USSF.xg.model, data.temp, type = "response")
  
}







