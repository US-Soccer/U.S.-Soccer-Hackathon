#Propensity scoring of posession data
library(tidyverse)
library(MatchIt)
library(flexclust)
library(class)
library(randomForest)

xmax=115
ymax=80

source('createPitch.R')

#Get data

#event.data=readRDS('./Raw Data/Data w xG/USMNT trimmed x xG.rds')

data.temp=readRDS('./Raw Data/Data w xG/MLS 2011-2012 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2011-2012 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)

event.data=data.temp

data.temp=readRDS('./Raw Data/Data w xG/MLS 2012-2013 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2012-2013 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)
event.data=rbind.data.frame(event.data, data.temp)

data.temp=readRDS('./Raw Data/Data w xG/MLS 2013-2014 trimmed x xG.rds')
possessions=read.csv('./Raw Data/PossIDs/MLS 2013-2014 trimmedpossID.csv')
data.temp=data.frame(data.temp,possessions)
event.data=rbind.data.frame(event.data, data.temp)

#event.data=readRDS('./Raw Data/Data w xG/MLS 2016-2017 trimmed x xG.rds')


#possessions=read.csv('./Raw Data/PossIDs/USMNTpossID.csv')
#possessions=read.csv('./Raw Data/PossIDs/MLS16_17possID.csv')
#event.data=data.frame(event.data, possessions)


# convert relative coordinates to absolute and convert game time to seconds
event.data=event.data%>%
  mutate(x.yard=x/100*xmax,
         y.yard=y/100*ymax,
         endX.yard=pass_end_x/100*xmax,
         endY.yard=pass_end_y/100*ymax,
         game.time=60*period_min+period_second)

event.data=event.data %>%
  filter( !event_type_id%in% c(70,32, 18, 19) )%>%
  group_by(PossID, game_id)%>%
  mutate(N=n(),
         poss_team=first(team))
#ungroup()%>%
#filter(team!=poss_team)
#possessions.test <- possessions.test[possessions.test$team==possessions.test$poss_team,]
event.data <- event.data[event.data$team==event.data$poss_team,]





#a=possessions.test[,c('team', 'poss_team', 'PossID')]
#b=event.data[,c('team', 'PossID')]


possessions.game=event.data %>%
  #filter(game_id==980425) %>%
  group_by(PossID, game_id,game_date,season, team) %>%
  filter(game_id==420390)%>%
  summarise(
    N=n(),
    start.distance=first(distance),
    end.distance=last(distance),
    #start.x=first(x),
    #start.y=first(y),
    #end.x=last(x),
    #end.y=last(y),
    #time=last(game.time)-first(game.time),
    velocity=(start.distance-end.distance)/(last(game.time)-first(game.time)),
    passes=sum(event_type=='Pass'),
    take.ons=sum(event_type=='Take on'),
    final.action=last(event_type_id),
    final.action.name=last(event_type),
    final.action.shot=ifelse(final.action %in% c(13:16),1,0),
    final.uid=last(uid),
    team.1=ifelse(as.character(first(team))!=as.character(first(home)), as.character(first(home)), as.character(first(away))),
    player=last(player),
    xG=sum(xG, na.rm=T))%>%
  filter(N>1 & is.finite(velocity) & end.distance<40)
#select(-c(final.action, final.action.name))



