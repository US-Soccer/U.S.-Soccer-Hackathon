#Causal

causal=read.csv('./Raw Data/player_estimates.csv')

causal=causal %>%
  arrange(total_difference)


top.bottom=rbind.data.frame(head(causal,10), tail(causal,10))
top.bottom$player=factor(top.bottom$player, levels=reorder(top.bottom$player, -top.bottom$total_difference))

p=ggplot(top.bottom)+geom_bar(aes(x=player, y=total_difference), stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=45, hjust=1))+
  labs(x="", y="Total xG added", 
       title='Top and Bottom 10: MLS 2018')

ggsave(plot=p, filename='MLS total xG added.png')

