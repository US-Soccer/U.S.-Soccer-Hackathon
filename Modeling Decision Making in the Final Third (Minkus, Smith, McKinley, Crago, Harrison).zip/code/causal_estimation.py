from __future__ import division
import argparse
import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors


parser = argparse.ArgumentParser()
parser.add_argument("--data-location", type=str, required=True, help="location of the data file")
parser.add_argument("--output-location", type=str, required=True, help="location to output final file")


def main():
    args = parser.parse_args()
    data = pd.read_csv(args.data_location)
    nbrs = NearestNeighbors(n_neighbors=20)
    nbrs.fit(np.array(data.shot_pr_score).reshape(-1, 1))
    shots = data[data.xG != 0].reset_index()
    shots['alt_value'] = 0
    for index, row in shots.iterrows():
        neigh, indices = nbrs.kneighbors(row['shot_pr_score'])
        shots.loc[index, 'alt_value'] = data.loc[indices[0], 'xG_pr_score'].mean()


    fun = {"xG": "sum", "xG_pr_score": "sum", "time": "size"}
    players = shots.groupby('player')[['xG', 'xG_pr_score']].agg(fun).reset_index()

    players['total_difference'] = players.xG - players.xG_pr_score
    players['ave_difference'] = players.total_difference / players.time
    with open("{}{}.csv".format(args.output_location, "player_estimates"), "w") as fout:
        players.to_csv(fout, index=False)



if __name__ == "__main__":
    main()
    
