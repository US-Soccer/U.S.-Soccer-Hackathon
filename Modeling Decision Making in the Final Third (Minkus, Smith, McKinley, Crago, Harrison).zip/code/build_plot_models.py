import argparse
import numpy as np
import pandas as pd
from gp.output_models import build_model, plot_model


parser = argparse.ArgumentParser()
parser.add_argument("--data-location", type=str, required=True, help="location of the data file")
parser.add_argument("--output-location", type=str, required=True, help="location to write the plots to")


def main():
    args = parser.parse_args()
    data = pd.read_csv(args.data_location)
    for player_id in data.player_id.unique():
        player_data = data[data.player_id == player_id]
        model = build_model(player_data)
        plot_model(model, player_id, args.output_location)


if __name__ == "__main__":
    main()
