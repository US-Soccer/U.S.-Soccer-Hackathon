import pandas as pd
import os

wd = r'C:\Users\Nox\Desktop\NU Classes\USHackathon\Scripts'
os.chdir(wd)

fields = ['season', 'game_id', 'team_id', 'player_id']
full_data = pd.read_csv('../Hackathon Raw Files/MLS.csv', usecols = fields, encoding='latin-1')
#(3806045, 4)

to_work = full_data.drop_duplicates()
#(68942, 4)

to_work.groupby(by=['season','game_id','team_id']).agg('count').describe()

#df with our clusters from previous analysis
cluster_pass = pd.read_csv('cluster_pass.csv')
#cluster_pass.describe()
cluster_shoot = pd.read_csv('shoot_result.csv')
#cluster_shoot.describe()

#df with all the possible matches
match = pd.read_csv('match_result.csv')

    

def fillColumns(season, teamid, gameid, cluster_df):
    players = to_work[(to_work['season']==season) & (to_work['game_id']==gameid) & (to_work['team_id']==teamid)]['player_id'].dropna()
    playerscluster = []
    errorcount = 0
    for p in players:
        try:
            find = cluster_df[(cluster_df['player_id']==p) & (cluster_df['season']==season)].iloc[0,-1]
            if find != 2:
                playerscluster.append(find)
            else:
                errorcount += 1
        except IndexError:
            errorcount += 1
    
    cluster_count = cluster_df.iloc[:,-1].max()+1
    cluster = [0] * cluster_count
    for j in playerscluster:
        cluster[j] += 1
    #print(errorcount)
    return cluster



k_pass = cluster_pass.iloc[:,-1].max()+1
k_shot = cluster_shoot.iloc[:,-1].max()+1
t11 = ['t1_pass' + str(i) for i in range(k_pass)]
t12 = ['t1_shot' + str(i) for i in range(k_shot)]
t21 = ['t2_pass' + str(i) for i in range(k_pass)]
t22 = ['t2_shot' + str(i) for i in range(k_shot)]

col_names = ['season','teamid1','teamid2']+t11+t12+t21+t22+['goaldiff']
             
final = pd.DataFrame(columns = col_names)
final_total = pd.DataFrame(columns = col_names)
for i in match.iterrows():
    team1 = []
    team2 = []
    
    season = i[1][0]
    teamid1 = i[1][2]
    teamid2 = i[1][4]
    gameid = i[1][1]
    goal1 = i[1][3]
    goal2 = i[1][5]

    clusterpass1 = fillColumns(season, teamid1, gameid, cluster_pass)
    clusterpass2 = fillColumns(season, teamid2, gameid, cluster_pass)
    clustershoot1 = fillColumns(season, teamid1, gameid, cluster_shoot)
    clustershoot2 = fillColumns(season, teamid2, gameid, cluster_shoot)    
#    print(clusterpass1)
#    print(clusterpass2)
#    print(clustershoot1)
#    print(clustershoot2)

    newrow = [season, teamid1, teamid2] + clusterpass1 + clustershoot1 + clusterpass2 + clustershoot2 + [goal1-goal2]
    newrow_flipped = [season, teamid2, teamid1] + clusterpass2 + clustershoot2 + clusterpass1 + clustershoot1 + [goal2-goal1]

    rowdict = {name:[value] for name,value in zip(col_names, newrow)}
    rowdict_flipped = {name:[value] for name,value in zip(col_names, newrow_flipped)}
    
    final = final.append(pd.DataFrame(rowdict))
    final_total = final_total.append(pd.DataFrame(rowdict))
    final_total = final_total.append(pd.DataFrame(rowdict_flipped))
    
final.to_csv('final3.csv', index=False)
final_total.to_csv('final_flipped3.csv', index=False)




