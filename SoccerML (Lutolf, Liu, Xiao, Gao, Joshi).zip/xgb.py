import xgboost as xgb
from xgboost import XGBClassifier, XGBRegressor
import pandas as pd
import numpy as np
from matplotlib import rcParams
from sklearn import metrics
from sklearn import preprocessing
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV

data = pd.read_csv("final_flipped.csv")
data.head()

Y = data.loc[:,"goaldiff"].values
X = data.drop(["goaldiff"], axis = 1).values

Y[np.where(Y<0)] = 1
Y[np.where(Y>0)] = 2

np.random.seed(2018-2-4)
xgb_base = XGBClassifier(objective= 'multi:softmax', num_class=3)
xgb_base.fit(X,Y)

scores = cross_val_score(xgb_base, X, Y, cv=10, scoring = 'accuracy', n_jobs = -1, verbose = 1)
print(scores.mean())

def test_model(model, train_X = X, train_y = Y, cv_folds=10, early_stopping_rounds=50):
    # Using cross validation to figure out the number of trees/number of boosting rounds
    xgb_param = model.get_xgb_params()
    xgtrain = xgb.DMatrix(train_X, label=train_y)
    # perform cross validation for the given parameters on this model and return the error
    cvresult = xgb.cv(xgb_param, xgtrain, nfold=cv_folds, metrics='merror',
                      num_boost_round=model.get_params()['n_estimators'],  # no of rounds same as no of trees
                      early_stopping_rounds=early_stopping_rounds)
                    # CV error needs to decrease at least once in these many rounds.
    # cvresult will return a pandas DataFrame containing the mean error (AUC here) for each iteration until 
    # the metric is increasing. Therefore, we know that after those iterations, the AUC doesn not increase, 
    # therefore we will set the n_estimators to be the number of rows in this data frame
    model.set_params(n_estimators=cvresult.shape[0]) # sets the n_estimators parameter as justified above
    # Fit the algorithm on the data
    model.fit(train_X, train_y, eval_metric='merror')
    # Predict training set:
    dtrain_predictions = model.predict(train_X)
    dtrain_predprob = model.predict_proba(train_X)[:,1]
    # Cross validated AUC Score
    scores = cross_val_score(model, train_X, train_y, cv = cv_folds, scoring = 'accuracy')
    # Print model report:
    print ("\nModel Report")
    print ("Optimal number of boosting iterations/number of trees =", cvresult.shape[0])
    print ("Cross validated Accuracy (Train) : %.4g" % scores.mean())
    print ("Accuracy (Train) : %.4g" % metrics.accuracy_score(train_y, dtrain_predictions))
    # print ("AUC Score (Train): %f" % metrics.roc_auc_score(train_y, dtrain_predprob))
    # plotting feature imporatance scores
    rcParams['figure.figsize'] = 6, 24 # increasing figure size to make the plot readable
    xgb.plot_importance(model)
    return cvresult.shape[0]


xgb1 = XGBClassifier(
 learning_rate =0.1,
 n_estimators=1000,
 max_depth=5,
 min_child_weight=1,
 gamma=0,
 subsample=0.8,
 colsample_bytree=0.8,
 objective= 'multi:softmax',
 num_class= 3,
 nthread=4,
 scale_pos_weight=1)

n_estimators = test_model(xgb1)

n_estimators

def GridSearchXGBoost(trainX, trainY, param_grid, scoring = 'accuracy', n_jobs = -1, iid = False, cv = 10, 
                      learning_rate = 0.1, n_estimators = 1000, max_depth = 5, min_child_weight = 1, gamma = 0, 
                      subsample = 0.8, colsample_bytree = 0.8, objective= 'binary:logistic', nthread = 4, 
                      scale_pos_weight = 1, reg_alpha = 0.01, seed=27):
    gsearch = GridSearchCV(estimator = XGBClassifier(learning_rate = learning_rate, n_estimators = n_estimators, 
                                                     max_depth = max_depth, min_child_weight = min_child_weight, 
                                                     gamma = gamma, subsample = subsample, 
                                                     colsample_bytree = colsample_bytree, objective = objective, 
                                                     nthread=nthread, scale_pos_weight=scale_pos_weight, 
                                                     reg_alpha = reg_alpha, seed=seed), 
                           param_grid = param_grid, scoring = scoring, n_jobs=n_jobs,iid=iid, cv=cv)
    gsearch.fit(trainX, trainY)
    print(gsearch.best_params_, gsearch.best_score_)
    return tuple([gsearch.best_params_[k] for k in param_grid.keys()])

param_test1 = {
 'max_depth':range(3,10,2),
 'min_child_weight':range(1,6,2)
}

max_depth, min_child_weight = GridSearchXGBoost(X, Y, param_test1, n_estimators = n_estimators)

max_depth, min_child_weight

param_test2 = {
 'max_depth':[max_depth-1, max_depth, max_depth+1],
 'min_child_weight':[min_child_weight-1, min_child_weight, min_child_weight+1]
}

max_depth, min_child_weight = GridSearchXGBoost(X, Y, param_test2, n_estimators = n_estimators)

max_depth, min_child_weight

param_test3 = {
 'gamma':[i/10.0 for i in range(0,5)]
}

gamma = GridSearchXGBoost(X, Y, param_test3, n_estimators = n_estimators, max_depth = max_depth, 
                          min_child_weight = min_child_weight)

gamma = gamma[0]
gamma

xgb2 = XGBClassifier(
 learning_rate = 0.1,
 n_estimators=1000,
 max_depth=max_depth,
 min_child_weight=min_child_weight,
 gamma=gamma,
 subsample=0.8,
 colsample_bytree=0.8,
 objective= 'multi:softmax',
 num_class= 3,
 nthread=4,
 scale_pos_weight=1)

n_estimators = test_model(xgb2)

param_test4 = {
 'subsample':[i/10.0 for i in range(6,10)],
 'colsample_bytree':[i/10.0 for i in range(6,10)]
}

subsample, colsample_bytree = GridSearchXGBoost(X, Y, param_test4, n_estimators = n_estimators, 
                                                max_depth = max_depth, min_child_weight = min_child_weight, 
                                                gamma = gamma)

subsample, colsample_bytree


param_test5 = {
 'subsample':[i/100.0 for i in range(int(subsample*100.0) - 5, int(subsample*100.0) + 10, 5)],
 'colsample_bytree':[i/100.0 for i in range(int(colsample_bytree*100.0) - 5, int(colsample_bytree*100.0) + 10, 5)]
}

subsample, colsample_bytree = GridSearchXGBoost(X, Y, param_test5, n_estimators = n_estimators, 
                                                max_depth = max_depth, min_child_weight = min_child_weight, 
                                                gamma = gamma)

subsample, colsample_bytree

param_test6 = {
 'reg_alpha':[1e-5, 1e-2, 0.1, 1, 100]
}

reg_alpha = GridSearchXGBoost(X, Y, param_test6, n_estimators = n_estimators, max_depth = max_depth, 
                                min_child_weight = min_child_weight, gamma = gamma, subsample = subsample, 
                                colsample_bytree = colsample_bytree)

reg_alpha = reg_alpha[0]
reg_alpha

param_test7 = {
 'reg_alpha':[0, 0.001, 0.005, 0.01, 0.05]
}

reg_alpha = GridSearchXGBoost(X, Y, param_test7, n_estimators = n_estimators, max_depth = max_depth, 
                                min_child_weight = min_child_weight, gamma = gamma, subsample = subsample, 
                                colsample_bytree = colsample_bytree)

reg_alpha = reg_alpha[0]
reg_alpha

final_model = XGBClassifier(
 learning_rate = 0.01,
 n_estimators=1000,
 max_depth=max_depth,
 min_child_weight=min_child_weight,
 gamma=gamma,
 subsample=subsample,
 colsample_bytree=colsample_bytree,
 reg_alpha=reg_alpha,
 objective= 'multi:softmax',
 num_class= 3,
 nthread=4,
 scale_pos_weight=1)

final_model.fit(X, Y)

scores = cross_val_score(final_model, X, Y, cv=10, scoring = "accuracy", n_jobs = -1, verbose = 1)
print(scores.mean())