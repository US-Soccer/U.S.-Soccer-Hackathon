Submission repo for the US Soccer Hackathon:
https://u-s-soccer-hackathon.devpost.com/