# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import pandas as pd


data_root = r"C:\Users\Nox\Desktop\NU Classes\USHackathon\Hackathon Raw Files\Full Datasets - Opta\MLS"
data_list = []
for filename in os.listdir(data_root): 
    MLS_Part = pd.read_csv(data_root + r'\\' + filename)
    MLS_Part['season'] = filename.split()[1]
    data_list.append(MLS_Part)


path = r'C:\Users\Nox\Desktop\NU Classes\USHackathon'
os.chdir(path)
os.getcwd()


full = r'C:\Users\Nox\Desktop\NU Classes\USHackathon\Hackathon Raw Files\Full Datasets - Opta'
trim = r'C:\Users\Nox\Desktop\NU Classes\USHackathon\Hackathon Raw Files\Trimmed Columns - Opta'
fullMLS = r'C:\Users\Nox\Desktop\NU Classes\USHackathon\Hackathon Raw Files\Full Datasets - Opta\MLS'


MLS = pd.read_csv(os.path.join(full, 'MLS/MLS 2011-2012.csv'))
MLStrim = pd.read_csv(os.path.join(trim, 'MLS/MLS 2011-2012 trimmed.csv'))

col_names = MLS.columns
col_names_trim = MLStrim.columns

removed_trimmed = set([s for s in col_names if s not in col_names_trim])
#with open('col_names'):
    
MLS['angle'].describe()

MLS['zone'].describe(include="all")

f = foo(3)
print (f(2))



goal_keeper = ['Parried safe',
               'Parried danger',
               'fingertip',
               'caught',
               'collected',
               'standing',
               'diving',
               'stooping',
               'reaching',
               'hands',
               'feet',
               'gk hoof',
               'gk kick from hands',
               
               
               
        ]


shooting  = [
        ]

keep = [

 'persistent_infringement',



 
 'right',

 'right_post',
 'shirt_pull_holding',

 

 'strong',
 
 'unsporting_behaviour',
 'violent_conduct',
 'weather_problem'
 
 ]

col_names_trim[:100]
col_names_trim[:25]
MLS['players_caught_offside'].head(100)
MLS[7:8]['player_id']
MLS['chance_missed'].describe()




col_names2 = [i for i in col_names if i.startswith('c')]
col_names2



################################################################

total_passes

succ = [
        ]

unsucc = ['blocked_pass',
          'chance_missed',
          
        ]

offensive = [
        ]


MLS.describe().append(MLS.isnull().sum().rename('isnull')).to_excel('check_some_stuff.csv')

MLSall = pd.concat(data_list)



data_list = [None] * len(os.listdir('.'))
for i in range(len(os.listdir('.'))):
    data_list[i] = pd.....




##################################################################
    
    
#Fuck you Rush
    
import pandas as pd   
 
path = r'C:\Users\Nox\Desktop\NU Classes\USHackathon\Hackathon Raw Files'
fields = ['player_position', 'season', 'competition_id', 'game_id', 'team_id', 'player_id']
df = pd.read_csv(os.path.join(path, 'MLS.csv'), encoding='latin-1')


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


