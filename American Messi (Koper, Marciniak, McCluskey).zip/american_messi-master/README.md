
Scraping, data cleaning, analysis and vizualizations code prepared for the 2018 U.S. Soccer Hackathon. The regression identifies the expected number of youth callups for every U.S. County using Census data on income and population 

Team
---
Andrew Kober
Chris Marciniak
Matt McCluskey
