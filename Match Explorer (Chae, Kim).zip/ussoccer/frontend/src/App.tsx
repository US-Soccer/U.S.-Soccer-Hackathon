import * as React from 'react';
import './App.css';
import * as d3 from 'd3';
import field from './field.svg';
import alex_morgan from './alex_morgan.json';
import uswnt_vs_china from './uswnt_vs_china.json';

class App extends React.Component {
  public static leftPadLOL(numString : string) {
    if (numString.length == 1)
      return '0' + numString;
    else
      return numString;
  }
  public static drawFieldEvents(wholedataset: Array<any>, start: number, end: number) {
    //Width and height
    var w = 800;
    var h = 524;
    var padding = 16;
 
    //Create scale functions
    var xScale = d3.scaleLinear()
                  .domain([0, 100])
                  .range([padding, w + padding]);
 
    var yScale = d3.scaleLinear()
                  .domain([0, 100])
                  .range([h+padding, padding]);

    // Find SVG element
    var svg = d3.select("svg");

    var dataset = wholedataset.slice(start, end)

 
    //Create circles
    svg.append('g')
       .selectAll('circle')
       .data(dataset)
       .enter()
       .append("circle")
       .attr("cx", function (d) {
         return xScale(d.x);
       })
       .attr("cy", function (d) {
         return yScale(d.y);
       })
       .attr("r", function (d) {
         return 5;
       });

       
    let convertToSeconds = function (d: any): number {
      return (Number(d.period_min) * 60 + Number(d.period_second))
    }       

    let timeDomain: [number, number] = [
      d3.min(wholedataset, (d) => convertToSeconds(d)),
      d3.max(wholedataset, (d) => convertToSeconds(d))
    ]
    let greenColorScale = d3.scaleSequential(d3.interpolateGreys)
                            .domain(timeDomain); 


    let teamColorScale = d3.scaleOrdinal()
                           .domain(['USA Women', 'China PR Women'])
                           .range(["#0000FF", '#FF0000'])


    //Create labels
    svg.append('g')
     .selectAll("text")
     .data(dataset)
     .enter()
     .append("text")
     .text(function(d) {
       return d.player + " " + d.period_min + ":" + App.leftPadLOL(d.period_second);
       //return d.x + "," + d.y;
     })
     .attr("x", function(d) {
       return xScale(d.x);
     })
     .attr("y", function(d) {
       return yScale(d.y);
     })
     .attr("font-family", "sans-serif")
     .attr("font-size", "11px")
     .attr("fill", (d) => (teamColorScale(d.team) as string));
 
    let defs = svg.append("defs")

    defs.append("marker")
      .attr("id", "arrow",)
      .attr("viewBox", "0 -5 10 10",)
      .attr("refX", 5,)
      .attr("refY", 0,)
      .attr("markerWidth", 4,)
      .attr("markerHeight", 4,)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("class", "arrowHead");

    svg.append('g')
       .selectAll('circle')
       .data(dataset)
       .enter()
       .append("line")
       .filter((d) => d.event_type == "Pass")
       .attr("class", "arrow",)
       .attr("marker-end", "url(#arrow)",)
       .attr("x1", (d) => xScale(d.x))
       .attr("y1", (d) => yScale(d.y))
       .attr("x2", (d) => xScale(d.pass_end_x))
       .attr("y2", (d) => yScale(d.pass_end_y))
       .attr("stroke", (d) => d3.rgb(greenColorScale(convertToSeconds(d))).hex());


     // draw Passes
     // "event_type": "Pass",
  }

  public componentDidMount() {
    d3.xml(field).then(function(xml) {
      document.querySelector('.field').appendChild(xml.documentElement);

      var dataset = [
        alex_morgan[0]
      ];
      var dataset: any[] = uswnt_vs_china.filter((d: any) => d.event_type != "Start")

      App.drawFieldEvents(dataset, 0, dataset.length);
      //let i = 0;
      //setInterval(function() {
      //  App.drawFieldEvents(dataset, i, i+1);
      //  i += 1;
      //}, 500);
    });
  }

  public render() {
    return (
      <div className="App">
        <div className="field">
        </div>
      </div>
    );
  }
}

export default App;
