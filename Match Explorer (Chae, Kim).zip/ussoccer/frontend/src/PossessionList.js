import React, { Component } from 'react';

class PossessionList extends Component {
  constructor(props){
    super(props);
  }

  renderRow(ps) {
    return (
      <div>
        <strong>{ps.time}</strong> <a onClick={() => this.props.possessionCallback(ps.id)} >{ps.label}</a> <span>{ps.importance}</span>
      </div>
    )
  }

  render() {
    const pss = this.props.possessions;
    if (!pss) return null;

    return (
      <div>
        <h1>Possessions</h1>
        {pss.map((p, i) => {
           return (
              this.renderRow(p)
            )
        })}
      </div>
    )
  }
}


export default PossessionList;
