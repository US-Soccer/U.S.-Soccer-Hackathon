import React, { Component } from 'react';
import { Button, Icon, Statistic, Header, Grid, Modal } from 'semantic-ui-react'

class Insights extends Component {
  constructor(props){
    super(props);
    this.clickRun = this.clickRun.bind(this);
    this.state = {
      user_script: 'possession',
      user_script_output: ''
    };
  }

  clickRun(context) {
    var res = function(script) { 
      return JSON.stringify(eval(script))
    }.call(context, 'var possession = this;'+this.state.user_script)

    console.log(res);
    this.setState({user_script_output: res});
  }

  handleChange(event) {
    this.setState({user_script: event.target.value});
  }

  passCount() {
    return this.props.possession.steps.length;
  }

  playerCount() {
    return this.props.possession.steps.length;
  }

  render() {
    if (!this.props.possession) return null;

    let p = this.props.possession;
    return (
    <div className="Insights">
      <h1>Insights</h1>
      <Statistic.Group>
        <Statistic>
          <Statistic.Value>
            <Icon name='arrow circle right' />
            {this.passCount()}
          </Statistic.Value>
          <Statistic.Label>Passes</Statistic.Label>
        </Statistic>

        <Statistic>
          <Statistic.Value>
            <Icon name='users' />
            {this.playerCount()}
          </Statistic.Value>
          <Statistic.Label>Players Involved</Statistic.Label>
        </Statistic>

        <Statistic>
          <Statistic.Value>
            <Modal trigger={<Icon name='search' size='small' />}>
              <Modal.Header>Explore {p.label}</Modal.Header>
              <Modal.Content>
                <Modal.Description>
                  <Grid columns={2}>
                    <Grid.Row>
                      <Grid.Column>
                        <textarea value={this.state.user_script} onChange={(event) => this.handleChange(event)}/>
                        <Button content='Run' onClick={() => this.clickRun(p)} />
                      </Grid.Column>
                      <Grid.Column>
                        <div className='output'>{this.state.user_script_output}</div>
                      </Grid.Column>
                    </Grid.Row>
                  </Grid>
                </Modal.Description>
              </Modal.Content>
            </Modal>
          </Statistic.Value>
          <Statistic.Label>Explore</Statistic.Label>
        </Statistic>
      </Statistic.Group>
    </div>
    )
  }
}


export default Insights;
