import React, { Component } from 'react';
import './Header.css'

class Header extends Component {
  render() {
    return (
      <div className="Header">
        <h1 className="title">
          <span className="titleHome">{this.props.match.home}</span> 
          - 
          <span className="titleAway">{this.props.match.away}</span>
        </h1>
        <div className="subtitle">
          {this.props.match.date}
        </div>
        <div className="score">
          <div className="score-left">
          </div>
          <div className="score-right">
          </div>
        </div>
      </div>
    )
  }
}


export default Header;
