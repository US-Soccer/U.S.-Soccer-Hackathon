import React, { Component } from 'react';
import { request, GraphQLClient } from 'graphql-request'
import { Container, Grid } from 'semantic-ui-react'
import './App.css';
import Header from './Header.js';
import Pitch from './Pitch.js';
import Insights from './Insights.js';
import PossessionList from './PossessionList.js';

const client = new GraphQLClient('http://localhost:3000/graphql')

const queryMatch = `query match($match_id: Int) {
  match(id: $match_id) {
    id
    home
    away
    date
  }
}`;
const queryPossesionList = `query possessionList($match_id: Int) {
  possessions(match_id: $match_id) {
    id
    time
    label
    importance
  }
}`;
const queryPossesion = `query possession($possession_id: Int) {
  possession(id: $possession_id) {
    id
    label
    time
    steps {
      id
      label
      x
      y
      player
      event_type
      period_min
      period_second
      team
      pass_end_x
      pass_end_y
    }
  }
}`;


class App extends Component {
  constructor(props){
    super(props);
    this.possessionClick = this.possessionClick.bind(this);
    this.state = {
      match: {}
    };
  }

  componentDidMount() {
    var match_id = 16; // TODO: Set match here!!!
    client.request(queryMatch, {match_id: match_id})
    .then(data => this.setState({ match: data.match }))
    client.request(queryPossesionList, {match_id: match_id})
    .then(data => this.setState({ possessions: data.possessions}))
  }

  possessionClick(ps_id) {
    console.log(ps_id);
    client.request(queryPossesion, {possession_id: Number(ps_id)})
    .then(data => this.setState({ curr_ps: data.possession}))
  }

  render() {
    return (
      <div className="App">
        <Container>
          <Header match={this.state.match} />
        </Container>
        <Grid columns={2} divided>
          <Grid.Row>
            <Grid.Column width={10}>
              <Pitch possession={this.state.curr_ps} />
              <Insights possession={this.state.curr_ps} />
            </Grid.Column>
            <Grid.Column width={6}>
              <PossessionList possessions={this.state.possessions} possessionCallback={this.possessionClick}/>
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    );
  }
}

export default App;
