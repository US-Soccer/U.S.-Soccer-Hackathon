import React, { Component } from 'react';
import { request, GraphQLClient } from 'graphql-request'
import * as d3 from 'd3';
import { Header } from 'semantic-ui-react';
import field from './field.svg';

// import alex_morgan from './alex_morgan.json';
// import uswnt_vs_china from './uswnt_vs_china.json';

class Pitch extends Component {
  constructor(props){
    super(props);
    this.state = {
    };
  }

  static leftPadLOL(numString) {
    if (numString.length == 1)
      return '0' + numString;
    else
      return numString;
  }

  drawFieldEvents(wholedataset, start, end) {
    //Width and height
    var w = 800;
    var h = 524;
    var padding = 16;

    //Create scale functions
    var xScale = d3.scaleLinear()
                  .domain([0, 100])
                  .range([padding, w + padding]);

    var yScale = d3.scaleLinear()
                  .domain([0, 100])
                  .range([h+padding, padding]);

    // Define the div for the tooltip
    var tip = d3.select("body").append("div")
                .attr("class", "tooltip")
                .style("opacity", 0);

    // Find SVG element
    var svg = d3.select("svg");

    var dataset = wholedataset.slice(start, end)

    //Create circles
    svg.append('g')
       .selectAll('circle')
       .data(dataset)
       .enter()
       .append("circle")
       .attr("cx", (d) => xScale(d.x))
       .attr("cy", (d) => yScale(d.y))
       .attr("r", (d) => 5)
       .on("mouseover", (d) => {
          tip.transition()
             .duration(200)
             .style("opacity", .9);
          tip.html("<span>" + d.player + " " + d.event_type + "</span>")
             .style("left", (d3.event.pageX) + "px")
             .style("top", (d3.event.pageY - 28) + "px");
        })
       .on("mouseout", (d) => {
          tip.transition()
              .duration(500)
              .style("opacity", 0);
       });


    let convertToSeconds = function (d) {
      return (Number(d.period_min) * 60 + Number(d.period_second))
    }

    let timeDomain = [
      d3.min(wholedataset, (d) => convertToSeconds(d)),
      d3.max(wholedataset, (d) => convertToSeconds(d))
    ]
    let greenColorScale = d3.scaleSequential(d3.interpolateGreys)
                            .domain(timeDomain);


    let teamColorScale = d3.scaleOrdinal()
                           .domain(['USA Women', 'China PR Women'])
                           .range(["#0000FF", '#FF0000'])


    //Create labels
    svg.append('g')
     .selectAll("text")
     .data(dataset)
     .enter()
     .append("text")
     .text(function(d) {
       return d.player + " " + d.period_min + ":" + Pitch.leftPadLOL(d.period_second);
       //return d.player + " " + d.period_min + ":" + d.period_second;
     })
     .attr("x", function(d) {
       return xScale(d.x);
     })
     .attr("y", function(d) {
       return yScale(d.y);
     })
     .attr("font-family", "sans-serif")
     .attr("font-size", "11px")
     .attr("fill", (d) => (teamColorScale(d.team)));

    let defs = svg.append("defs")

    defs.append("marker")
      .attr("id", "arrow",)
      .attr("viewBox", "0 -5 10 10",)
      .attr("refX", 5,)
      .attr("refY", 0,)
      .attr("markerWidth", 4,)
      .attr("markerHeight", 4,)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("class", "arrowHead");

    svg.append('g')
       .selectAll('circle')
       .data(dataset)
       .enter()
       .append("line")
       .filter((d) => d.event_type == "Pass")
       .attr("class", "arrow",)
       .attr("marker-end", "url(#arrow)",)
       .attr("x1", (d) => xScale(d.x))
       .attr("y1", (d) => yScale(d.y))
       .attr("x2", (d) => xScale(d.pass_end_x))
       .attr("y2", (d) => yScale(d.pass_end_y))
       .attr("stroke", (d) => d3.rgb(greenColorScale(convertToSeconds(d))).hex());

     // draw Passes
     // "event_type": "Pass",
  }

  componentDidUpdate() {
    d3.xml(field).then((xml) => {
      // let el = this.state.field_element;
      // if (!el) {
        // el = document.querySelector('.field').appendChild(xml.documentElement);
        // this.setState({field_element: el});
      // }
      let field = document.querySelector('.field');
      field.innerHTML = '';
      field.appendChild(xml.documentElement);
      var dataset = (this.props.possession) ? this.props.possession.steps : [];

      // var dataset = [
      //   alex_morgan[0]
      // ];
      // var dataset = uswnt_vs_china.filter((d) => d.event_type != "Start")

      this.drawFieldEvents(dataset, 0, dataset.length);
      let i = 0;
      // setInterval(() => {
      //   this.drawFieldEvents(dataset, i, i+1);
      //   i += 1;
      // }, 500);
    });
  }

  render() {
    let header = (this.props.possession) ? `${this.props.possession.label}` : 'Start of Match';
    return (
      <div className="Pitch">
        <h1>{header}</h1>
        <div className="field">
        </div>
      </div>
    );
  }
}

export default Pitch;
