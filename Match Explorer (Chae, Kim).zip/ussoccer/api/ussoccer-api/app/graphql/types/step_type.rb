module Types
  StepType = GraphQL::ObjectType.define do
    name 'Step'

    field :id, types.Int
    field :label, types.String
    field :x, types.Int
    field :y, types.Int
    field :player, types.String
    field :event_type, types.String
    field :period_min, types.String
    field :period_second, types.String
    field :team, types.String
    field :pass_end_x, types.Int
    field :pass_end_y, types.Int
  end
end
