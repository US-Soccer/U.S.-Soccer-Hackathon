module Types
  QueryType = GraphQL::ObjectType.define do
    name 'Query'

    field :match do
      type MatchType
      description 'Get match data'

      argument :id, types.Int
      resolve -> (obj, args, ctx) {
        Match.find(args.id)
      }
    end

    field :possessions do
      type types[PossessionType]
      description 'Get all possessions'

      argument :match_id, types.Int
      resolve -> (obj, args, ctx) {
        Match.where(id: args.match_id).includes(:possessions).first.possessions.sort do |p1, p2|
            first_event1 = p1.events.chronological.first
            p1_timestamp = first_event1.data["period_id"].to_i * 45 * 60 + first_event1.timestamp
            first_event2 = p2.events.chronological.first
            p2_timestamp = first_event2.data["period_id"].to_i * 45 * 60 + first_event2.timestamp
            p1_timestamp <=> p2_timestamp
        end.map do |p|
          OpenStruct.new(
            id: p.id,
            time: p.start_time,
            label: p.label || 'Unlabeled',
            importance: p.importance || '',
            steps: []
          )
        end
        #OpenStruct.new(id: 1, time: 'Half 1', label: 'Passing', steps: Event.last(2).map {|e| OpenStruct.new(id: e.id, label: e.event_type) }),
        #OpenStruct.new(id: 2, time: 'Half 2', label: 'Corner', steps: Event.last(2).map {|e| OpenStruct.new(id: e.id, label: e.event_type) }),
        #OpenStruct.new(id: 3, time: 'Half 2', label: 'Shot', steps: Event.last(2).map {|e| OpenStruct.new(id: e.id, label: e.event_type) })
      }
    end

    field :possession do
      type PossessionType
      description 'Get possession data'

      argument :id, types.Int
      resolve -> (obj, args, ctx) {
        p = Possession.where(id: args.id).includes(:events).first

        OpenStruct.new(
          id: p.id,
          time: p.start_time,
          label: p.label,
          importance: p.importance || '',
          steps: p.events.map do |e|
            OpenStruct.new(
              id: e.id,
              label: e.data["event_type"],
              x: e.data["x"],
              y: e.data["y"],
              player: e.data["player"],
              event_type: e.data["event_type"],
              period_min: e.data["period_min"],
              period_second: e.data["period_second"],
              team: e.data["team"],
              pass_end_x: e.data["pass_end_x"],
              pass_end_y: e.data["pass_end_y"],
              away_team: e.data["away_team"],
              home_team: e.data["home_team"]
            )
          end
        )
      }
    end

  end
end
