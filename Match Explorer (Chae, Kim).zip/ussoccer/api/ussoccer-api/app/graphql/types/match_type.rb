module Types
  MatchType = GraphQL::ObjectType.define do
    name 'Match'
    description 'Single match'

    field :id, types.ID
    field :date, types.String
    field :home, types.String
    field :away, types.String
  end
end

