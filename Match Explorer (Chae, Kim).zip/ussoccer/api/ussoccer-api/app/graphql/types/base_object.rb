class Types::BaseObject < GraphQL::Schema::Object
end
