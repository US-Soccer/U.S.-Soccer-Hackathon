module Types
  PossessionType = GraphQL::ObjectType.define do
    name 'Possession'
    description 'Single possession'

    field :id, types.ID
    field :time, types.String
    field :label, types.String
    field :importance, types.String
    field :steps do
      type types[StepType]
      description 'This possession\'s steps'
    end
  end
end
