class Types::BaseEnum < GraphQL::Schema::Enum
end
