module Types::BaseInterface
  include GraphQL::Schema::Interface
end
