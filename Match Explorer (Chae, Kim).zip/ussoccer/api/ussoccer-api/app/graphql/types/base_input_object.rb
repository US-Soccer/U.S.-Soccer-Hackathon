class Types::BaseInputObject < GraphQL::Schema::InputObject
end
