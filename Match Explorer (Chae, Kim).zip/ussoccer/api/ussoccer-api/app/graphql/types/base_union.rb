class Types::BaseUnion < GraphQL::Schema::Union
end
