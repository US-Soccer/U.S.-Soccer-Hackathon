class Possession < ApplicationRecord
  has_many :events

  belongs_to :match, optional: true

  def start_time
    first_event_data = self.events.chronological.first.data
    "H" + first_event_data["period_id"] + " " + first_event_data["period_min"] + ":" + ("%02d" % first_event_data["period_second"])
  end
end
