class Match < ApplicationRecord
  has_many :possessions
  
  has_many :events, through: :possessions
end
