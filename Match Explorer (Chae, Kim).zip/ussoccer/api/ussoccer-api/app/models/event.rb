class Event < ApplicationRecord
  # id: String
  scope :for_game, ->(id) { where("data->>'game_id' = ?", id) }
  scope :chronological, -> { order("(data->>'period_id')::Integer ASC, (data->>'period_min')::Integer ASC, (data->>'period_second')::Integer ASC") }

  store_accessor :data,
    :game_id,
    :event_type,
    :event_type_id,
    :period_id,
    :period_min,
    :period_second

  belongs_to :possession, optional: true



  def self.teams
    Hash[
      [:home, :away].zip(
        pluck("data->'home_team'", "data->'away_team'").uniq.first
      )]
  end

  # Seconds since gaem start
  def timestamp
    #(period_id.to_i - 1) +
      (period_min.to_i * 60) +
      period_second.to_i
  end
end
