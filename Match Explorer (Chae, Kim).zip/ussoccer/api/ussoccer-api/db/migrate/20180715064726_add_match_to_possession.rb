class AddMatchToPossession < ActiveRecord::Migration[5.2]
  def change
    add_column :possessions, :match_id, :integer
    add_foreign_key :possessions, :matches
  end
end
