class AddImportanceToPossession < ActiveRecord::Migration[5.2]
  def change
    add_column :possessions, :importance, :string
  end
end
