class AddLabelToPossession < ActiveRecord::Migration[5.2]
  def change
    add_column :possessions, :label, :string
  end
end
