class AllowNullPossession < ActiveRecord::Migration[5.2]
  def change
    change_column :events, :possession_id, :integer, :null => true
  end
end
