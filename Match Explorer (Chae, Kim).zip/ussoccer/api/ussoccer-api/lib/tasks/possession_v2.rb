def generate_possessions(game_id)
  # Boundry events
  # [Event, type id]
  # foul_1 [Foul, 4] current team, outcome=0
  # [Foul, 4] other team, outcome=1
  #
  # out_1 [Out, 5] current team, outcome=0
  # [Out, 5] other team, outcome=1
  #
  # [Ball recovery, 49, ] other team, outcome=1
  #
  # [Claim, 11] other team, outcome=1
  #
  # [Interception, 8] other team, outcome=1
  #
  # pass_1 [Pass, 1] current team, outcome=0
  # anything by other team, but should it be outcome 1?
  puts 'Extracting Possessions'
  chronological_game_events = Event.for_game(game_id).chronological
  first_event = chronological_game_events.first

  match = Match.find_or_initialize_by(game_id: game_id)
  match.home = first_event.data["home"]
  match.away = first_event.data["away"]
  match.date = first_event.data["game_date"]
  match.save

  current_team = first_event.data["team_id"]
  current_state = :start
  current_possession = match.possessions.create
  one_off_turnovers = Set.new(["49", "11", "8"]) # ball_recovery, claim, intercepton
  chronological_game_events.each do |event|
    if current_state == :foul_1
      next_state = :start
      if event.data["team_id"] != current_team && event.data["event_type_id"] == "4" && event.data["outcome"] == "1"
        current_team = event.data["team_id"]
        current_possession = match.possessions.create
      end
    elsif current_state == :out_1
      next_state = :start
      if event.data["team_id"] != current_team && event.data["event_type_id"] == "5" && event.data["outcome"] == "1"
        current_team = event.data["team_id"]
        current_possession = match.possessions.create
      end
    elsif current_state == :common_turnover
      next_state = :start
      if event.data["team_id"] != current_team
        current_team = event.data["team_id"]
        current_possession = match.possessions.create
      end
    elsif current_state == :start
      next_state = :start # may be overridden by more specific case within
      if event.data["team_id"] != current_team && event.data["outcome"] == "1"
        if (one_off_turnovers.include?(event.data["event_type_id"]))
          current_team = event.data["team_id"]
          current_possession = match.possessions.create
        end
      elsif event.data["event_type_id"] == "4" && event.data["outcome"] == "0" # foul to lose possession
        next_state = :foul_1
      elsif event.data["event_type_id"] == "5" && event.data["outcome"] == "0" # kicked out of bounds
        next_state = :out_1
      elsif event.data["event_type_id"] == "1" && event.data["outcome"] == "0" # bad pass
        next_state = :common_turnover
      elsif event.data["event_type_id"] == "61" && event.data["outcome"] == "0" # miscontrol
        next_state = :common_turnover
      end
    end
    event.possession = current_possession
    event.save
    current_state = next_state
  end
end
