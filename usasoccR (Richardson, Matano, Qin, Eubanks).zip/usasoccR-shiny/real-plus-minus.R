# World Cup 2014 ---
wc_14 <- read.csv(file = "data/World_cup_2014_Ridge_threshold300_2.csv")
wc_14 <- wc_14[, 3:ncol(wc_14)]
wc_14$RPM <- round(wc_14$RPM, digits=5)

# World Cup 2018 ---
wc_18 <- read.csv("data/World_cup_2018_Ridge_threshold300_2.csv")
wc_18 <- wc_18[, 2:ncol(wc_18)]
wc_18$RPM <- round(wc_18$RPM, digits=5)

# MLS 2015
mls_15 <- read.csv("data/MLS_2015-2016_Ridge_threshold900_2.csv")
mls_15 <- mls_15[, 3:ncol(mls_15)]
mls_15$RPM <- round(mls_15$RPM, digits=5)

# MLS 2016 
mls_16 <- read.csv("data/MLS_2016-2017_Ridge_threshold900_2.csv")
mls_16 <- mls_16[, 3:ncol(mls_16)]
mls_16$RPM <- round(mls_16$RPM, digits=5)

# MLS 2017 
mls_17 <- read.csv("data/MLS_2017-2018_Ridge_threshold900_2.csv")
mls_17 <- mls_17[, 3:ncol(mls_17)]
mls_17$RPM <- round(mls_17$RPM, digits=5)

