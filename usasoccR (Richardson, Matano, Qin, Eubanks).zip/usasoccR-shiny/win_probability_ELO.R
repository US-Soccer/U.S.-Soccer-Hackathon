win_probability_ELO <- function(ELO1, ELO2){
  
  tmp <- 1 / (1 + 10^((ELO2-ELO1)/400))
  
  return(c(tmp,1-tmp))
}
