# World Cup 2014 ---
wc_18_team <- read.csv(file = "data/WC2018_team_profiles.csv")
wc_18_team <- wc_18_team[, 2:ncol(wc_18_team)]
wc_18_team$elo_rank <- 1:nrow(wc_18_team)

# World Cup 2014 ---
wc_14_team <- read.csv(file = "data/WC2014_team_profiles.csv")
wc_14_team <- wc_14_team[, 2:ncol(wc_14_team)]
wc_14_team$elo_rank <- 1:nrow(wc_14_team)

mls_18_team <- read.csv("data/MLS2018_team_profiles.csv")
mls_18_team <- mls_18_team[, 2:ncol(mls_18_team)]
mls_18_team$elo_rank <- 1:nrow(mls_18_team)
