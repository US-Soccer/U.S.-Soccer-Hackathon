#!/bin/bash

# Functions ---
shiny_dir=/home/lee/Dropbox/usa-soccer-hackathon/code/usasoccR-shiny
rpackage_dir=/home/lee/Dropbox/usa-soccer-hackathon/code/usasoccR

cp $rpackage_dir/R/create_pitch_fun.R $shiny_dir

# Data ---
# cp $rpackage_dir/data-raw/World_cup_2018_Ridge_threshold300.csv $shiny_dir/data
cp $rpackage_dir/data/mls_2011.rda $shiny_dir/data

# cp $rpackage_dir/data-raw/World_cup_2018_Ridge_threshold300.csv $shiny_dir/data

#cp $rpackage_dir/data-raw/MLS_2015-2016_Ridge_threshold900.csv $shiny_dir/data
#cp $rpackage_dir/data-raw/MLS_2016-2017_Ridge_threshold900.csv $shiny_dir/data
#cp $rpackage_dir/data-raw/MLS_2017-2018_Ridge_threshold900.csv $shiny_dir/data
#cp $rpackage_dir/data-raw/World_cup_2018_Ridge_threshold300.csv $shiny_dir/data
#cp $rpackage_dir/data-raw/World_cup_2014_Ridge_threshold300.csv $shiny_dir/data


