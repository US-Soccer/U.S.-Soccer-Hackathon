source("create_pitch_fun.R")
source("opta.R")
source("real-plus-minus.R")
source("team-profile.R")
source("win_probability_ELO.R")


library(shiny)
library(shinydashboard)
library(DT)

ui <- dashboardPage(title = "Random Walkers USA", skin = "red",
  dashboardHeader(titleWidth = 500, title = "Random Walkers USA Soccer Hackathon"),

  # Sidebar Content ---
  dashboardSidebar(
    dashboardSidebar(
      sidebarMenu(
        menuItem("Opta Exploratory", tabName = "opta", icon = icon("eye")),
        menuItem("Player Profile", tabName = "player_profile", icon = icon("plus")), 
        menuItem("Team Profile", tabName = "team_profile", icon = icon("plus-square")), 
        menuItem("Win Probability", tabName = "win_prob", icon = icon("percent"))
      )
    )
  ),

  # Body Content ---
  dashboardBody(
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
    ),

    tabItems(
      # First tab content
      tabItem(tabName = "opta",
        sidebarLayout(
          # Sidebar Panel ---
          sidebarPanel(
            h4("Opta Visualzation: MLS 2017-18", align="center"),

            radioButtons("period",
                         label = "Period",
                         choices = list("All Game" = 3, 
                                        "Period 1" = 1, 
                                        "Period 2" = 2),
                         selected = 3,
                         inline = TRUE),
            
            selectInput(inputId = "team",
                        label = "Team",
                        choices = c(unique(mls_2011$team))
                        ),

            selectInput(inputId = "player",
                        label = "Player",
                        choices = c(unique(mls_2011$player))
                        ),

            selectInput(inputId = "plot_type",
                        label = "Plot Type",
                        choices = c("", 
                                    "Passes",
                                    "Passes Successful",
                                    "Passes Unsuccessful",
                                    "Pass Directions",
                                    "Shots",
                                    "All Event Types"),
                        selected = ""),
            
            sliderInput(inputId = 'nbins', 
                        label = "Bandwidth", 
                        min = 1, max = 100, value = 8)
            
          ),
          

          # Main Panel ---
          mainPanel(h4("Pitch Visualization", align="center"),
                    plotOutput(outputId = "opta_pitch"),
                    br(), br(), br(),
                    img(src="cmustats.png", width=300, height=100, align="right"),
                    img(src="ml_dept.png", width=300, height=100, align="left")
                    
          )
        )
      ),

      # Player Profile ---
      tabItem(tabName = "player_profile",
        
              sidebarLayout(
                # Sidebar Panel ---
                sidebarPanel(
                  selectInput("rpm_season",
                              label = "Select Season or Tournament",
                              choices = c("MLS 2015-16", 
                                          "MLS 2016-17",
                                          "MLS 2017-18", 
                                          "World Cup 2014", 
                                          "World Cup 2018"),
                              selected = "World Cup 2018")
                  ),
                
                # Main Panel ---
                mainPanel(
                  h4("Player Strength Profile", align="center"),
                  DT::dataTableOutput("rpm_table"),
                  plotOutput(outputId = "rpm_boxplot"),
                  img(src="cmustats.png", width=300, height=100, align="right"),
                  img(src="ml_dept.png", width=300, height=100, align="left")
                )
              )
      ), 
      
      # Team Profile ---
      tabItem(tabName = "team_profile",
              
              sidebarLayout(
                # Sidebar Panel ---
                sidebarPanel(
                  selectInput("rpm_team",
                              label = "Select Season or Tournament",
                              choices = c("World Cup 2014",
                                          "World Cup 2018", 
                                          "MLS 2017-18"),
                              selected = "World Cup 2018")
                ),
                
                # Main Panel ---
                mainPanel(
                  h4("Team Strength Profile", align="center"),
                  DT::dataTableOutput("team_table"),
                  img(src="cmustats.png", width=300, height=100, align="right"),
                  img(src="ml_dept.png", width=300, height=100, align="left")
                )
              )
      ), 
      tabItem(tabName="win_prob",
              # Sidebar Panel ---
              sidebarPanel(
                selectInput("team_one",
                            label = "Select Team 1",
                            choices = c(as.character(unique(wc_18_team$country))),
                            selected = "Brazil"),
                selectInput("team_two",
                            label = "Select Team 2",
                            choices = c(as.character(unique(wc_18_team$country))),
                            selected = "France")
              ),
              
              # Main Panel ---
              mainPanel(
                h4("Win Probability World Cup 2018", align="center"),
                plotOutput(outputId = "winprob", height=350, width=700),
                img(src="cmustats.png", width=300, height=100, align="right"),
                img(src="ml_dept.png", width=300, height=100, align="left")
              )
      )
    )
  )
)

# Server Logic ---
server <- function(input, output, session) {
  dataInput <- reactive({
    cat("Reactive Data Input \n")

    if (input$team == "all") {
      inds <- 1:nrow(mls_2011)
    } else {
      inds <- which(mls_2011$team == input$team)
    }

    mls_2011[inds, ]
  })

  output$opta_pitch <- renderPlot({
    data <- dataInput()
    print(nrow(data))

    if (input$player == "") {
      subset_data <- data
    } else {
      subset_data <- data[which(data$player == input$player), ]
    }
    
    if (input$period != 3) 
      subset_data <- subset_data[which(data$period_id == input$period), ]
    nrow(subset_data)

    
    if (input$plot_type == "") {
      pitch
    
    } else if (input$plot_type == "All Event Types") {
      create_density_plot(data=subset_data, pitch=pitch, bins=input$nbins)

    } else if (input$plot_type == "Passes") {
      subset_data <- subset_data[which(subset_data$event_type == "Pass"), ]
      print(nrow(subset_data))
      create_density_plot(data=subset_data, pitch=pitch, bins=input$nbins) + 
        geom_point(data=subset_data, aes(x=x, y=y), size=.5)
      
    } else if (input$plot_type == "Passes Successful") {
      subset_data <- subset_data[which(subset_data$event_type == "Pass"), ]
      subset_data <- subset_data[which(subset_data$outcome == 1), ]
      
      create_density_plot(data=subset_data, pitch=pitch, bins=input$nbins) + 
        geom_point(data=subset_data, aes(x=x, y=y), size=.5)
      
    } else if (input$plot_type == "Passes Unsuccessful") {
      subset_data <- subset_data[which(subset_data$event_type == "Pass"), ]
      subset_data <- subset_data[which(subset_data$outcome == 0), ]
      
      create_density_plot(data=subset_data, pitch=pitch, bins=input$nbins) + 
        geom_point(data=subset_data, aes(x=x, y=y), size=.5)
      
    } else if (input$plot_type == "Pass Directions") {
      print(nrow(subset_data))
      subset_data <- subset_data[which(subset_data$event_type == "Pass"), ]
      print(nrow(subset_data))

      pitch +
        geom_segment(data=subset_data, aes(x=x, y=y, xend=pass_end_x, yend=pass_end_y, colour = as.factor(outcome)),
                     arrow = arrow(length = unit(0.1, "inches")), size = .5) +
        scale_colour_manual(values = c("darkblue", "darkred"), name = "outcome",
                            labels = c("unsuccessful", "succesful")) +
        theme(legend.position = c(0.5, 0.03), legend.direction = "horizontal",
              plot.title = element_text(hjust = 0.5, size = 20))

    } else if (input$plot_type == "Shots") {
      print(nrow(subset_data))
      subset_data <- subset_data[which(subset_data$event_type %in% c("Goal", "Miss", "Attempt saved")), ]
      subset_data$Outcome <- as.factor(ifelse(subset_data$event_type == "Goal", "Make", "Miss"))
      print(nrow(subset_data))

      pitch + geom_point(data=subset_data, aes(x=x, y=y, colour=Outcome), size=5) +
        theme(legend.position = c(0.5, 0.03), legend.direction = "horizontal",
              plot.title = element_text(hjust = 0.5, size = 20)) +
        scale_colour_manual(values = c("#DF5058", "#F1BEBE")) 
  
    }

  })

  observe({
    cat("Observe Update Player \n")
    data <- dataInput()
    players <- data[, "player"]
    updateSelectInput(session, inputId = "player", choices = data[, "player"])
  })
  
  
  # sorted columns are colored now because CSS are attached to them
  output$rpm_table <- DT::renderDataTable({

    data <- switch(input$rpm_season, 
                   "MLS 2015-16" = mls_15, 
                   "MLS 2016-17" = mls_16,
                   "MLS 2017-18"= mls_17, 
                   "World Cup 2014" = wc_14, 
                   "World Cup 2018" = wc_18)

    DT::datatable(data, options = list(orderClasses = TRUE))
  })

  # sorted columns are colored now because CSS are attached to them
  output$team_table <- DT::renderDataTable({
    
    data <- switch(input$rpm_team, 
                   "World Cup 2014" = wc_14_team, 
                   "World Cup 2018" = wc_18_team, 
                   "MLS 2017-18" = mls_18_team)
    
    
    DT::datatable(data, options = list(orderClasses = TRUE))
  })
  
  
  # Win Probability ---
  output$winprob <- renderPlot({
    
    elo_one  <- wc_18_team$ELO[which(wc_18_team$country == input$team_one)]
    elo_two  <- wc_18_team$ELO[which(wc_18_team$country == input$team_two)]
    win_prob <- round(win_probability_ELO(elo_one, elo_two), 3)
    
    result <- c(win_prob[1], win_prob[2])*100
    barplot(result,
            main = "",
            xlab = "",
            ylab = "",
            names.arg = c(input$team_one, input$team_two),
            col = c("red", "orange"),
            horiz = TRUE, axes = FALSE, cex.names = 1.5)
    text(20, 1:2, paste(result, "%"), cex = 3)
  })
}

shinyApp(ui, server)
