library(ggplot2)
library(lubridate)

load("data/mls_2011.rda")
mls_2011$game_date <-   lubridate::ymd(as.Date(mls_2011$game_date))

cat("Creating Pitch")
pitch <- create_my_pitch()
