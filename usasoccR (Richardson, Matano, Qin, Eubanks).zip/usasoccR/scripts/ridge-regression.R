# install.packages("glmnet")
library(glmnet)
# 2017 - 2018
design <- read.csv("data-raw/MLS_2017-2018_design_matrix.csv")
mls_minutes <- read.csv("data-raw/MLS_2017-2018_total_minutes.csv")
player_names <- colnames(design)

x <- as.matrix(design[, 11:ncol(design)])
y <- as.numeric(design[, "home_goal"] - design[, "away_goal"])
weights <- 1 / (design[, "tf"] - design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=x, y=y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=x, y=y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- mls_minutes[which(mls_minutes$minutes.Freq > 900), "name"]
thresh_rows <- which(df$names %in% as.character(more_than_thresh))

df_thresh <- df[thresh_rows, ]
df_sorted <- df_thresh[order(df_thresh$betas, decreasing=TRUE), ]
write.csv(df_sorted, file = "data-raw/MLS_2017-2018_Ridge_threshold900.csv")
# write.csv(df_sorted, file = "data-raw/MLS_2017-2018_Ridge_threshold1200.csv")
write.csv(df, file = "data-raw/MLS_2017-2018_Ridge.csv")


# 2016 - 2017
design <- read.csv("data-raw/MLS_2016-2017_design_matrix.csv")
mls_minutes <- read.csv("data-raw/MLS_2016-2017_total_minutes.csv")
player_names <- colnames(design)

x <- as.matrix(design[, 11:ncol(design)])
y <- as.numeric(design[, "home_goal"] - design[, "away_goal"])
weights <- 1 / (design[, "tf"] - design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=x, y=y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=x, y=y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- mls_minutes[which(mls_minutes$minutes.Freq > 900), "name"]
thresh_rows <- which(df$names %in% as.character(more_than_thresh))

df_thresh <- df[thresh_rows, ]
df_sorted <- df_thresh[order(df_thresh$betas, decreasing=TRUE), ]
write.csv(df_sorted, file = "data-raw/MLS_2016-2017_Ridge_threshold900.csv")
write.csv(df, file = "data-raw/MLS_2016-2017_Ridge.csv")


# 2015 - 2016
design <- read.csv("data-raw/MLS_2015-2016_design_matrix.csv")
mls_minutes <- read.csv("data-raw/MLS_2015-2016_total_minutes.csv")
player_names <- colnames(design)

x <- as.matrix(design[, 11:ncol(design)])
y <- as.numeric(design[, "home_goal"] - design[, "away_goal"])
weights <- 1 / (design[, "tf"] - design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=x, y=y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=x, y=y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- mls_minutes[which(mls_minutes$minutes.Freq > 900), "name"]
thresh_rows <- which(df$names %in% as.character(more_than_thresh))

df_thresh <- df[thresh_rows, ]
df_sorted <- df_thresh[order(df_thresh$betas, decreasing=TRUE), ]
write.csv(df_sorted, file = "data-raw/MLS_2015-2016_Ridge_threshold900.csv")
write.csv(df, file = "data-raw/MLS_2015-2016_Ridge.csv")


# 2014 - 2015
design <- read.csv("data-raw/MLS_2014-2015_design_matrix.csv")
mls_minutes <- read.csv("data-raw/MLS_2014-2015_total_minutes.csv")
player_names <- colnames(design)

x <- as.matrix(design[, 11:ncol(design)])
y <- as.numeric(design[, "home_goal"] - design[, "away_goal"])
weights <- 1 / (design[, "tf"] - design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=x, y=y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=x, y=y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- mls_minutes[which(mls_minutes$minutes.Freq > 900), "name"]
thresh_rows <- which(df$names %in% as.character(more_than_thresh))

df_thresh <- df[thresh_rows, ]
df_sorted <- df_thresh[order(df_thresh$betas, decreasing=TRUE), ]
write.csv(df_sorted, file = "data-raw/MLS_2014-2015_Ridge_threshold900.csv")
write.csv(df, file = "data-raw/MLS_2014-2015_Ridge.csv")




# World Cup Ridge ---
wc_design <- read.csv("data-raw/World_cup_2018_design_matrix.csv")
wc_minutes <- read.csv("data-raw/World_cup_2018_total_minutes.csv")
wc_x <- as.matrix(wc_design[,-c(1:10)])
wc_y <- as.numeric(wc_design[, "home_goal"] - wc_design[, "away_goal"])
weights <- 1 / (wc_design[, "tf"] - wc_design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=wc_x, y=wc_y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=wc_x, y=wc_y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df_wc <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- wc_minutes[which(wc_minutes$Minutes > 300), "Name"]
thresh_rows <- which(df_wc$names %in% as.character(more_than_thresh))

df_thresh_wc <- df_wc[thresh_rows, ]
df_tresh_wc_sorted <- df_thresh_wc[order(df_thresh_wc$betas, decreasing=TRUE), ]
write.csv(df_tresh_wc_sorted, file = "data-raw/World_cup_2018_Ridge_threshold300.csv")
write.csv(df_wc, file = "data-raw/World_cup_2018_Ridge.csv")





wc_design <- read.csv("data-raw/World_cup_2014_design_matrix.csv")
wc_minutes <- read.csv("data-raw/World_cup_2014_total_minutes.csv")
wc_x <- as.matrix(wc_design[,-c(1:10)])
wc_y <- as.numeric(wc_design[, "home_goal"] - wc_design[, "away_goal"])
weights <- 1 / (wc_design[, "tf"] - wc_design[, "ts"])

model_cv <- glmnet::cv.glmnet(x=wc_x, y=wc_y, weights=weights, alpha=0)
model <- glmnet::glmnet(x=wc_x, y=wc_y, weights=weights, alpha=0, lambda=model_cv$lambda.min)
coefs <- model$beta

df_wc <- data.frame(betas=coefs@x, names=coefs@Dimnames[[1]])

more_than_thresh <- wc_minutes[which(wc_minutes$Minutes > 300), "Name"]
thresh_rows <- which(df_wc$names %in% as.character(more_than_thresh))

df_thresh_wc <- df_wc[thresh_rows, ]
df_tresh_wc_sorted <- df_thresh_wc[order(df_thresh_wc$betas, decreasing=TRUE), ]
write.csv(df_tresh_wc_sorted, file = "data-raw/World_cup_2014_Ridge_threshold300.csv")
write.csv(df_wc, file = "data-raw/World_cup_2014_Ridge.csv")

