# devtools::install_github("ryurko/fcscrapR")
library(fcscrapR)

sample_game_ids <- fcscrapR::scrape_scoreboard_ids(game_date = "2018-07-12")
first_game_id <- as.character(sample_game_ids[1, 1])

scrape_lineup(game_id=first_game_id)

years <- as.character(2000:2018)
months <- c(paste0("0", 1:9), as.character(10:12))
days <- as.character(1:31)

for (year in years) {
  for (month in months) {
    for (day in days) {
      game_string <- paste0(year, "-", month, "-", day)
      cat(game_string, " \n")

      # Step 1: Get Game IDs

      # Step 2: Extract Information for each Game ID

      # Step 3: Write out extracted information

    }
  }
}


