library(magrittr)
competition <- "MLS_2016-2017"
f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                 competition, "_lineups.csv")
all_lineups <- read.csv(f_name) %>% na.omit
all_lineups <- all_lineups[!is.na(all_lineups$espn_id),]

f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                 competition, "_segmentation.csv")
segmentation_info <- read.csv(f_name)
pl <- all_lineups$lineup[1]
all_lineups$espn_id[which(all_lineups$lineup == pl)] %>% unique

retrieve_games_id_wrong_segmentation <-
create_pm_design_matrix(all_lineups, segmentation_info)
978
