# devtools::install_github("ryurko/fcscrapR")
library(fcscrapR)
library(readr)
library(magrittr)

devtools::load_all()

# Load data
# Check MLS scraper
competition <- "MLS_2013-2014"
# competition <- "World_Cup"
where <- "MLS"
data <- read_csv(paste0("~/Dropbox/usa-soccer-hackathon/Data/Hackathon Raw Files/Full Datasets - Opta/",
                        where, "/", stringr::str_replace(competition, "_", " ")[[1]], ".csv")) %>%
  as.data.frame()


# Get espn id from opta
# Extract all the ids and date of the game
data_ids   <- data$game_id %>% unique
data_dates <- data$game_date %>% unique %>% as.character()  %>%
  as.list() %>% sapply(function(x) strsplit(x, " ")[[1]][1]) %>% unique



# EXAMPLE: Extract all the MLS games 2011/2012
espn_games  <- list()
for(jj in 1:length(data_dates)){
  cat("Extracting date: ", data_dates[jj], "\n")
  espn_games[[jj]] <- scrape_scoreboard_ids(scoreboard_name =
                                            "major league soccer",
                                            #"fifa world cup",
                                    game_date = data_dates[jj])

  today_ids <- c(498140, 502535, 502534, 502531, 502532,
                 502530, 502529, 502536)
  espn_games[[jj]] <- espn_games[[jj]][!(espn_games[[jj]]$game_id %in%
                                         today_ids),]
  if((espn_games[[jj]] %>% nrow() == 0))
    print("There is not info on this date")
}



# Combine all the games together
game_lineup <- all_games_lineup <- segmentation_info <- NULL
t0 <- proc.time()
for(ii in 103:length(data_dates)){
  cat("Extracting date: ", data_dates[ii], "\n")

  # If the game id exists
  if((espn_games[[ii]] %>% nrow() != 0)){

    for(jj in 1:length(espn_games[[ii]]$game_id)){
      id <- data$game_id[which(data$fixture == paste(espn_games[[ii]]$team_one[jj], "v",
                                             espn_games[[ii]]$team_two[jj]))[1]]

      tmp_lineup <- scrape_lineup(espn_games[[ii]]$game_id[jj])

      if(is.null(tmp_lineup))
        tmp <- data.frame(game_date = data_dates[ii],
                          espn_id = NA, opta_id = id,
                          lineup = NA, time_of_sub_in = NA,
                          time_of_sub_out = NA, team = NA)


      if(!is.null(tmp_lineup)){
        # Add red card info
        game_commentary <- scrape_commentary(espn_games[[ii]]$game_id[jj] %>% as.character())
        tmp_lineup <- add_red_card_info(game_commentary, tmp_lineup)

        tmp <- cbind(data.frame(game_date = rep(data_dates[ii], nrow(tmp_lineup)),
                                espn_id = rep(espn_games[[ii]]$game_id[jj], nrow(tmp_lineup)),
                                opta_id = rep(id, nrow(tmp_lineup))), tmp_lineup)

        segmentation_matrix <- create_segmentation(tmp_lineup)
        tmp2 <- cbind(game_date = rep(data_dates[ii], nrow(segmentation_matrix)),
                      espn_id = rep(espn_games[[ii]]$game_id[jj], nrow(segmentation_matrix)),
                      opta_id = rep(id, nrow(segmentation_matrix)),
                      get_shot_attempt_by_segment(game_commentary, segmentation_matrix))

      }

      game_lineup <- rbind(game_lineup, tmp)
      segmentation_info <- rbind(segmentation_info, tmp2)
      tmp <- tmp2 <- NULL
    }
  } else{
    game_lineup <- data.frame(game_date = data_dates[ii],
                                    espn_id = NA, opta_id = NA,
                                    lineup = NA, time_of_sub_in = NA,
                                    time_of_sub_out = NA, team = NA)
  }
  all_games_lineup <- rbind(all_games_lineup, game_lineup)
  game_lineup <- NULL

}
tf <- proc.time() - t0

any(segmentation_info$tf < segmentation_info$ts)



# Write
f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                 competition, "_lineups.csv")
write.csv(all_games_lineup, file = f_name)

f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                 competition, "_segmentation.csv")
write.csv(segmentation_info, file = f_name)


# f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
#                  competition, "_lineups.csv")
# load(f_name)

years <- 2014
#for(y in 1:length(years)){
  # subset_data <- substr(all_games_lineup$game_date, 1, 4) %>% unique
  f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                   competition, "_", years, "_lineups.csv")
  write.csv(all_games_lineup, f_name)

  f_name <- paste0("~/Dropbox/usa-soccer-hackathon/code/usasoccR/data-raw/",
                   competition, "_", years, "_segmentation.csv")
  write.csv(segmentation_info, f_name)

#  }




