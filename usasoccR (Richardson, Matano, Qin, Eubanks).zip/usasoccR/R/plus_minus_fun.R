#' Accounting for red cards
#'
#' This function adds the info about red card to the game_lineup
#' @param game_commentary from fcscrapR
#' @param game_lineup computed from the package
#' @param type_card is the type of card to consider. It has to be red,
#' left it flexible for testing purposes
add_red_card_info <- function(game_commentary, game_lineup, type_card = "red"){

  wwhich_card <- which(game_commentary$card_type == type_card)

  # Transform the line-up data
  game_lineup$time_of_sub_in <- game_lineup$time_of_sub_in %>% as.character()
  game_lineup$time_of_sub_in[game_lineup$time_of_sub_in == "start"] <- 0

  game_lineup$time_of_sub_out <- game_lineup$time_of_sub_out %>% as.character()
  game_lineup$time_of_sub_out[game_lineup$time_of_sub_out == "end"] <-
    max(game_commentary$match_time_numeric, na.rm = TRUE)

  game_lineup$time_of_sub_in  <- game_lineup$time_of_sub_in %>% as.numeric
  game_lineup$time_of_sub_out <- game_lineup$time_of_sub_out %>% as.numeric


  # If there is at least one red card select the players
  if(length(wwhich_card) > 0){
    players_card <- game_commentary$card_player[wwhich_card]
    minutes_card <- game_commentary$match_time_numeric[wwhich_card]
    game_lineup$time_of_sub_out <- game_lineup$time_of_sub_out %>% as.character()

    for(ii in 1:length(players_card)){
      wwhich <- which(game_lineup$lineup == players_card[ii])
      game_lineup$time_of_sub_out[wwhich] <- minutes_card[ii] %>% as.character()
    }
  }
  return(game_lineup)
}


#' Creating segmentation
#'
#' This function creates segmentation every time a the configuration
#' on the pitch changes
#' @param game_commentary from fcscrapR
#' @param game_lineup computed from the package
create_segmentation <- function(game_lineup){

  # browser()
  # Get the order line up by time_of_sub_out
  ordered_lineup <- game_lineup[order(game_lineup$time_of_sub_out %>% as.numeric(),
                                      decreasing = FALSE),]

  # Create the segmentation matrix
  segments <- c(0, ordered_lineup$time_of_sub_out %>% unique) %>% as.numeric
  segment_matrix <- matrix(NA, ncol = 2, nrow = length(segments) - 1)
  for(j in 1:(length(segments) - 1))
    segment_matrix[j,] <- c(segments[j], segments[j + 1])

  return(segment_matrix)
}


#' Creating the shot attempt by segmentation for both teams
#'
#' This function creates the shot attempt matrix by segmentation for both teams
#' @param game_commentary from fcscrapR
#' @param segmentation_matrix a matrix with each row a segment, each coloumn
#' the start and the end of the segment
get_shot_attempt_by_segment <- function(game_commentary, segmentation_matrix){

  shot_by_segment <- data.frame(ts = segmentation_matrix[,1],
                                tf = segmentation_matrix[,2],
                                home_shot = rep(0, nrow(segmentation_matrix)),
                                away_shot = rep(0, nrow(segmentation_matrix)),
                                home_goal = rep(0, nrow(segmentation_matrix)),
                                away_goal = rep(0, nrow(segmentation_matrix)))

  home_team <- game_commentary$team_one %>% unique
  away_team <- game_commentary$team_two %>% unique

  for(t in 1:nrow(segmentation_matrix)){

    if(shot_by_segment$tf[t] > shot_by_segment$ts[t]){
      wwhich <- which((game_commentary$match_time_numeric < shot_by_segment$tf[t]) &
              (game_commentary$match_time_numeric >= shot_by_segment$ts[t]))
    } else{
      wwhich <- which(game_commentary$match_time_numeric == shot_by_segment$tf[t])
    }

    # If there is any shot in the interval
    if(length(wwhich) > 0){

      # If its after the
      commentary_t <- game_commentary$commentary[wwhich]
      wwhich_shootout <- which(startsWith(commentary_t, "Penalty Shootout begins"))
      if((wwhich_shootout %>% length) > 0)
        wwhich <- wwhich[1:(wwhich_shootout - 1)]


      all_shots_segment_t <- game_commentary$shot_by_team[wwhich]
      all_shots_segment_t <- all_shots_segment_t[!is.na(all_shots_segment_t)]
      all_goals_segment_t <- game_commentary$shot_by_team[wwhich]
      which_goal <- which(game_commentary$shot_result[wwhich] == "goal")


      # Compute all the shots by team
      shot_by_segment$home_shot[t] <- all_shots_segment_t[all_shots_segment_t == home_team] %>%
        length()
      shot_by_segment$away_shot[t] <- all_shots_segment_t[all_shots_segment_t == away_team] %>%
        length()

      shot_by_segment$home_goal[t] <- shot_by_segment$away_goal[t] <- 0
      if((which_goal %>% length) != 0){
        shot_by_segment$home_goal[t] <- which(all_goals_segment_t[which_goal] == home_team) %>% length()
        shot_by_segment$away_goal[t] <- which(all_goals_segment_t[which_goal] == away_team) %>% length()
      }
    }
  }

  return(shot_by_segment)
}



#' This function creates the design matrix for
create_design_matrix <- function(lineups, segments){

  lineups = lineups[!is.na(lineups$espn_id), ]
  lineups$X = NULL

  # segments = read.csv(paste("World_Cup_", year,  "_segmentation.csv", sep = ""))
  segments$X = NULL

  #lineups[lineups$lineup == "Kostas Manolas", ]

  # tot_mins = xtabs("time_of_sub_out - time_of_sub_in ~ lineup", data = lineups)
  # minutes = data.frame(name = sub(" ", "_", names(tot_mins)), minutes = tot_mins)
  # names(minutes) = c("Name", "Name2", "Minutes")
  # write.csv(minutes, paste("World_cup_", year,"_total_minutes.csv", sep = ""))

  #hist(xtabs("time_of_sub_out - time_of_sub_in ~ lineup", data = lineups))


  players = gsub(" ", "_", unique(as.character(lineups$lineup)))
  n_players = length(unique(as.character(lineups$lineup)))
  segments = cbind(segments, matrix(0, nrow(segments), n_players))
  names(segments)[10:ncol(segments)] = players

  # head(segments$espn_id)
  for (i in 1:nrow(lineups)){
    player = gsub(" ", "_", as.character(lineups$lineup)[i])
    game = lineups$espn_id[i]
    time_in = lineups$time_of_sub_in[i]
    time_out = lineups$time_of_sub_out[i]
    segments[segments$espn_id == game & segments$ts >= time_in & segments$tf <= time_out, player] = ifelse(lineups$team[i] == "home", 1, -1)
  }
  return(segments)
}



