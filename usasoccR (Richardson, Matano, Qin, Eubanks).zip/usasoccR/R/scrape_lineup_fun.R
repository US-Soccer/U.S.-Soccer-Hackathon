#' Scraping line up info
#'
#' This function scrapes lineup for a given game on espn
#' @param game_id espn id
#' @return list with the two line ups plus subs info
scrape_lineup <- function(game_id){

  if(length(game_id) > 1) stop("game_id should be length one")

  team_info <- list()
  teams     <- NULL
  scraped   <- TRUE
  n_players <- 11
  game_id   <- as.character(game_id)


  # Compose the url
  url <- paste0("http://www.espn.com/soccer/lineups?gameId=", game_id)

  # All the substitution pattern are "#'-#, but extra time has pattern "90+#'-#
  regular_time_pattern <- expand.grid(1:120, 1:99) %>%
    apply(1, function(x) paste0(x[1], "'-", x[2], ""))
  extra_time_pattern1 <- expand.grid(paste0("45'+", 1:9, "'-"), 1:99) %>%
    apply(1, function(x) paste0(x[1], x[2]))
  extra_time_pattern2 <- expand.grid(paste0("90'+", 1:9, "'-"), 1:99) %>%
    apply(1, function(x) paste0(x[1], x[2]))
  extra_time_pattern3 <- expand.grid(paste0("120'+", 1:9, "'-"), 1:99) %>%
    apply(1, function(x) paste0(x[1], x[2]))
  substitution_pattern <- c(regular_time_pattern, extra_time_pattern1,
                            extra_time_pattern2, extra_time_pattern3)


  for(team_j in 1:2){

    url_nodes <- url %>% xml2::read_html() %>% rvest::html_nodes("table")

    if(length(url_nodes) < 2){
      cat("Game info", game_id, "- there is no line-up available for this game! \n")
      return()
    }

    # Extract the line up from the espn url
    team_lineup <- url_nodes[[team_j]] %>%
      rvest::html_text() %>%
      stringr::str_replace_all(pattern = "\n", replacement = "-") %>%
      stringr::str_replace_all(pattern = "\t", replacement = "")

    team <- stringr::str_extract(team_lineup, pattern = "(?<=--).*(?=No.-Name)") %>%
      stringr::str_replace_all(pattern = "-", replacement = "")
    teams <- c(teams, team)
    team_lineup <- sub('.*\\.-Name', '', team_lineup)

    # PLAYER EXTRACTION DIFFERS BETWEEN GAMES
    player_by_player_data <- strsplit(team_lineup, "-------------------") %>%
      unlist(use.names = FALSE)
    if(!(stringr::str_detect(team_lineup, "Shots") %>% any))
        player_by_player_data <- set_player_by_player_data_other_pattern(team_lineup)


    line_up <- time_of_sub_in <- time_of_sub_out <- c(); count_sub <- 0
    for(ii in 1:n_players){

      player_string_start <- stringr::str_extract(player_by_player_data[ii],
                                                  "\\-*\\d+\\.*\\d*")
      start_string <- paste0(player_string_start, "----")
      end_string <- "--------"

      line_up[ii] <- (qdapRegex::rm_between(player_by_player_data[ii],
                                           start_string, end_string,
                                           extract = TRUE) %>%
                        unlist(use.names = FALSE))[1]
      if(is.na(line_up[ii]))
        line_up[ii] <- (qdapRegex::rm_between(player_by_player_data[ii],
                                             start_string, "------",
                                             extract = TRUE) %>%
                          unlist(use.names = FALSE))[1]
      time_of_sub_in[ii]  <- "start"
      time_of_sub_out[ii] <- "end"


      # IF THE PLAYER WAS SUBSISTITUTED
      is_player_sub_out <- stringr::str_detect(player_by_player_data[ii],
                                               substitution_pattern)
      if(is_player_sub_out %>% any()){
        count_sub <- count_sub + 1
        wwhich <- which(is_player_sub_out == TRUE)

        # There could be multiple strings that match, the longest is the best match
        l <- sapply(as.list(wwhich), function(x)
          stringr::str_length(substitution_pattern[x]))
        wwhich <- wwhich[which(l == max(l))]

        if(length(wwhich) != 1){
          cat("Game info", game_id, "- the game has some weird pattern! \n")
          return()
        }
        # for(k in 1:length(wwhich))
        time_of_sub_in[ii]  <- "start"
        time_of_sub_out[ii] <- stringr::str_extract(substitution_pattern[wwhich],
                                                  "\\-*\\d+\\.*\\d*")
        time_of_sub_in[11 + count_sub] <- time_of_sub_out[ii]
        tmp <- qdapRegex::rm_between(player_by_player_data[ii],
                                    paste0(substitution_pattern[wwhich]),
                                    "-------", extract = TRUE)
        line_up[11 + count_sub] <- (tmp %>% unlist(use.names = FALSE) %>%
                                    stringr::str_split("----") %>%
                                    unlist(use.names = FALSE))[2]


        # IF PLAYER SUB HAS AN EVENT RECORDED IN THE GAME: there is some
        # residual of minutes to be deleted
        residual_pattern_sub <- stringr::str_extract(line_up[11 + count_sub],
                                                 "\\-*\\d+\\.*\\d*")
        if(!is.na(residual_pattern_sub)){
          tmp <- qdapRegex::rm_between(line_up[11 + count_sub], "",
                                       residual_pattern_sub,
                                       extract = TRUE)
          line_up[11 + count_sub] <- (((tmp %>% unlist(use.names = FALSE))[1]) %>%
                                        stringr::str_split("-") %>%
                                        unlist(use.names = FALSE))[1]
          }

      }

      # IF STARTING PLAYER THAN SUB OUT HAS AN EVENT RECORDED IN THE GAME:
      # there is some residual of minutes to be deleted
      residual_pattern <- stringr::str_extract(line_up[ii], "\\-*\\d+\\.*\\d*")
      if(!is.na(residual_pattern)){
        tmp <- qdapRegex::rm_between(line_up[ii], "",
                                     residual_pattern,
                                     extract = TRUE)
        line_up[ii] <- (((tmp %>% unlist(use.names = FALSE))[1]) %>%
                          stringr::str_split("-") %>%
                          unlist(use.names = FALSE))[1]
      }

    }

    # Fill out the time of sub and provide the list
    time_of_sub_out[12:length(line_up)] <- "end"
    team_info[[team_j]] <- data.frame(lineup = line_up, time_of_sub_in = time_of_sub_in,
                                 time_of_sub_out = time_of_sub_out,
                                 team = rep(ifelse(team_j == 1, "home", "away"),
                                            length(line_up)))

  }
  cat("Game info", game_id, "-", teams[1], "-", teams[2], "\n")
  team_info <- Reduce(rbind, team_info)
  return(team_info)
}


#' Divide the scraped line up such that there is a player event per line
#'
#' This function divides the scraped line up such that there is a player
#' event per line
#' @param team_lineup is the scraped lineup using rvest
set_player_by_player_data_other_pattern <- function(team_lineup){

  # Move the space between name and last name to be +
  tmp <- (stringr::str_replace_all(team_lineup, pattern = " ",
                                   replacement = "+") %>%
            strsplit("(\\s)+") %>% unlist(use.names = FALSE))[-1]
  minutes_pattern <- paste0(1:90, "'")

  # If the jersey is not a number but a minute or something else you need
  # incorporate this with the previous one
  wwhich <- NULL
  ii <- 2
  while(ii <= length(tmp)){
    jersey_number <- sub(".*----- *(.*?) *----.*", "\\1", tmp[ii])
    not_player_line <- !grepl("\\d", jersey_number) |
      (tmp[ii] %>% stringr::str_detect(paste0(1:90, "'")) %>% any())
    j <- ii

    while(not_player_line){
      tmp[j - 1] <- paste0(tmp[j-1], tmp[ii])
      wwhich <- c(wwhich, ii)

      ii <- ii + 1
      jersey_number <- sub(".*----- *(.*?) *----.*", "\\1", tmp[ii])
      not_player_line <- !grepl("\\d", jersey_number) |
        (tmp[ii] %>% stringr::str_detect(paste0(1:90, "'")) %>% any())
    }
    ii <- ii + 1
  }
  # Eliminate all the non player line and reconvert + in spaces
  player_by_player_data <- tmp[-unique(wwhich)]
  player_by_player_data <- player_by_player_data %>%
    stringr::str_c(collapse = "*") %>%
    stringr::str_replace_all(pattern = "\\+", replacement = " ") %>%
    strsplit("\\*") %>% unlist(use.names = FALSE)
  return(player_by_player_data)
}


#' Extracting ESPN id from OPTA id
#'
#' This function extracts ESPN id from OPTA, using info about the date of the
#' game. Through fcscrapR it matches all the games recorded by ESPN and
#' happening on the same day, and selects the one that matches the teams
#' @param game_date date of the game in Sys.Date() format
#' @param opta_id the OPTA id correspondent to the game that we want to scrape
#' @return the ESPN id
from_opta_to_espn_id <- function(game_date, opta_id){

  # Extract all games played that day, recorded by ESPN
  all_games_ids <- fcscrapR::scrape_scoreboard_ids(game_date = game_date)

  # Reconstruch the espn id base on the game date
  wwhich_id <- which((all_games_ids$team_one == (game_data$home %>% unique)) |
                       (all_games_ids$team_two == (game_data$away %>% unique)))
  espn_id <- all_games_ids[wwhich_id, "game_id"] %>% as.character()
  return(espn_id)

}
